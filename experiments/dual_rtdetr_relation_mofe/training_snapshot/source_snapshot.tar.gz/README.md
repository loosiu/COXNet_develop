# 관계 기반 양방향 MoFE: 직접 특징 교체 실험

기존 A 및 spatial MoFE는 원래 경로에 보존한다. 이번 모듈은 projected P3에서 SWT의 네 주파수 조합을 유지하며, 각 expert를 Q/K 관계 기반 후보 생성으로 바꾼다. 주 실행 설정은 원본 특징에 더하지 않고 새 특징으로 P3를 교체한다.

```text
RGB/T 독립 backbone → 공통 채널 projection → 원래 RGB/T P3
→ 각 방향의 SWT LL/LH/HL/HH
→ 네 관계 expert: LL–LL / LL–H / H–LL / H–H
→ 위치별 softmax로 완성된 후보 특징을 혼합하여 RGB/T P3 교체
→ 기존 각 HybridEncoder의 AIFI(P5)·FPN·PAN
→ 기존 scale별 RGB/T concat+CSP fusion → 공유 RT-DETR decoder
```

두 방향은 원래 pair를 읽고 파라미터를 공유하지 않는다. 방향별 기존 256→64 projection과 spatial router 초기값, A의 공통 초기 state와 CPU RNG를 보존한다. Expert 연산은 다음과 같다.

1. 수신 모달리티의 해당 band에서 Q, 상대 모달리티의 해당 band에서 K/V를 각각 `1×1 Conv → 3×3 DWConv`로 만든다. H는 기존처럼 `Concat(LH,HL,HH)`다.
2. `C=IFFT(FFT(Q)*conj(FFT(K)))`로 channel별 circular cross-correlation을 구한다. FFT는 FP32로 수행한다.
3. 이미지·channel별 공간 RMS로 C를 정규화하고 `A=sigmoid(Conv3×3(C_norm))`를 얻는다.
4. `U=A*V`와 수신 정보 Q를 concat하고 channel LayerNorm과 1×1 projection으로 256채널의 완성된 후보 `F_hat_i`를 만든다. 원본 256채널 특징을 그대로 더하는 identity skip은 없다.
5. 기존 spatial router가 네 주파수 pair에서 `[B,2,4,H,W]` 가중치를 만들고 expert 축으로만 FP32 softmax를 적용한다.

주 실행 설정의 출력:

`R_new(p)=sum_i w_R_i(p)*F_hat_R_i(p)`

`T_new(p)=sum_i w_T_i(p)*F_hat_T_i(p)`

Direct 모드에는 gamma와 고정 0.5 multiplier가 없으며, 원본에 보완량을 더하는 경로도 없다. 공통 feature projection/backbone/pyramid/decoder의 초기 파라미터는 A와 같지만 새 P3를 넣으므로 초기 예측이 A와 같지는 않다. Padding/invalid cell만 원래 특징을 반환하며, 모든 유효 위치는 새 후보의 혼합으로 교체한다.

DFCA의 Q/K 주파수 상관과 V modulation 원리에 영감을 받았다. RMS normalization, Q와 attended V의 joint projection, SWT 네 pair와 spatial MoE는 이 실험의 적용 선택이다. 원본 DFCA의 학습 가능한 radial FFT band partition이나 SSE는 추가하지 않는다. SWT 분해는 한 번이며 이후 FFT는 correlation 계산용이다. FFT 상관 결과는 이동량(displacement lag)에 대한 지도이며, 이를 학습 가능한 convolution으로 변환하여 V를 조절한다. 각 RGB 위치가 주변 thermal 위치를 직접 검색·집계하는 local token softmax attention이나 기하학적 alignment를 보장하는 모듈은 아니다. S³AM 또는 DFCA 저자 구현의 완전 재현을 주장하지 않는다.

## 설정과 비교

- 주 실행: `configs/rgbtdroneperson_relation_direct_seed0.yaml`.
- 대조 설정: `configs/rgbtdroneperson_relation_residual_seed0.yaml`. 같은 관계 expert와 router를 사용하되 `R+0.5*gamma_R*mixed`, `T+0.5*gamma_T*mixed`로 연결한다. Gamma는 0.1에서 시작하며 residual 모드에서만 optimizer에 등록한다. 이 모드에서는 후보를 보완량으로 학습하므로 별도로 처음부터 학습해야 한다.
- 기존 A와 seed 0, batch 2, workers 4, FP32, 20 epoch, 공개 backbone pretrained, AdamW/EMA, resize, 검출·auxiliary·denoising loss를 동일하게 유지한다. 추가 mask/utility/distillation/teacher loss는 없다.
- 전체 파라미터: direct 85,789,497 / 모듈 934,536. Residual control은 gamma 2개가 추가된다.
- 현재 convolution+residual 모델과는 후보 생성과 출력 연결 두 항목이 바뀐다. 관계 expert residual 대조를 사용하면 후보 생성 변경과 출력 교체를 단계적으로 비교할 수 있다. Residual보다 direct가 반드시 우수하다는 주장은 하지 않는다.

## 검증과 실행

```bash
cd /data/siwoo/DualRTDETR-Relation-MoFE
PYTHON_BIN=/home/viplab/anaconda3/envs/coxmamba/bin/python
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 "$PYTHON_BIN" -m unittest tests.test_relation_mofe tests.test_relation_mofe_integration -v

# 데이터와 공개 backbone weight가 준비된 환경에서 새로 학습한다.
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1 "$PYTHON_BIN" -u tools/train.py \
  --config configs/rgbtdroneperson_relation_direct_seed0.yaml --device cuda:0
```

`tools/relation_mofe_preflight.py`는 실제 batch 2·세 해상도로 세 번의 검출 loss 갱신을 검증한다. Production 학습이나 checkpoint 저장은 수행하지 않는다. Preflight를 GPU1에서 실행할 때는 기존 `tools/gpu1_guard.sh`로 물리 GPU 매핑과 공유 lock을 먼저 확보한다. 본학습은 preflight에서 갱신한 가중치를 사용하지 않고 공개 pretrained에서 다시 시작한다.

2026-10-14 검증 결과: 전체 CPU 테스트 226개 중 225개 통과, CUDA 전용 1개 제외. 실제 물리 GPU1에서 batch 2로 세 번 갱신하여 모듈의 파라미터 텐서 98개 모두에 유한한 nonzero gradient와 값 변경을 확인했고 EMA 평가도 유한하고 반복 가능했다. A의 공통 초기 tensor 1,401개와 CPU RNG가 동일하며 기존 spatial 실험의 소스 125개는 변경되지 않았다. 검증 기록은 `artifacts/full_tests.log`, `artifacts/test_certificate.json`, `artifacts/verification_relation_direct_gpu1.json`에 있다. 20-epoch 본학습과 AP 검증은 아직 수행하지 않았다.

진단에는 router 평균/공간 표준편차/entropy, 관계 attention의 평균/포화 비율, 후보·출력·원본 RMS, 원본 대비 실제 변화량이 포함된다. Direct 모드의 `relative_update`는 `(새 특징−원래 특징)`의 RMS 비율이며 residual 보완량 크기를 뜻하지 않는다. 초기 학습 loss나 attention 가중치만으로 AP 향상을 주장하지 않는다.
