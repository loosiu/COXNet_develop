import unittest
from dyfclt.runtime import load_config, make_dataset, checkpoint_metric


class TrainingProtocolTests(unittest.TestCase):
    def test_launch_config_uses_three_benchmark_classes_and_tiny_ap50(self):
        config = load_config('configs/rgbtdroneperson.yaml')
        self.assertEqual(config['model']['num_classes'], 3)
        self.assertEqual(config['data']['train']['categories'], ['person','rider','crowd'])
        self.assertEqual(config['data']['val']['categories'], ['person','rider','crowd'])
        self.assertEqual(config['evaluation']['protocol'], 'rgbtdroneperson')
        self.assertEqual(checkpoint_metric({'AP':.18,'AP50':.42}, config), .42)

    def test_metric_selection_rejects_missing_configured_key(self):
        with self.assertRaisesRegex(ValueError, 'AP50'):
            checkpoint_metric({'AP':.12}, {'evaluation': {'selection_metric': 'AP50'}})
        self.assertEqual(checkpoint_metric({'AP':.12}, {}), .12)

if __name__ == '__main__':
    unittest.main()
