import unittest

import torch

from dyfclt.model import DyFCLT
from dyfclt.vendor.rtdetr_decoder import RTDETRTransformer


OPTIONS = dict(dim=8, heads=2, evaluator_hidden=8, chunk_size=8)


def detector(frequency=True, denoising=0):
    return DyFCLT(3, hidden_dim=32, num_queries=8, num_decoder_layers=2,
                  num_denoising=denoising, architecture='dual_rtdetr',
                  use_dfca=False, use_sse=False, use_fref=False,
                  frequency_utility=OPTIONS if frequency else None)


class FrequencyIntegrationTests(unittest.TestCase):
    def test_added_module_preserves_all_common_initial_weights(self):
        torch.manual_seed(44); a = detector(False)
        torch.manual_seed(44); d = detector(True)
        d_state = d.state_dict()
        for name, value in a.state_dict().items():
            torch.testing.assert_close(value, d_state[name], rtol=0, atol=0, msg=name)

    def test_zero_gates_reproduce_the_whole_baseline_detector(self):
        torch.manual_seed(32); a = detector(False).eval()
        torch.manual_seed(32); d = detector(True).eval()
        rgb, thermal = torch.randn(1, 3, 64, 96), torch.randn(1, 3, 64, 96)
        with torch.no_grad():
            expected = a(rgb, thermal)
            cache = d.prepare_frequency(rgb, thermal)
            actual = d.replay_frequency(cache, torch.zeros_like(cache['frequency']['w']))
        for key in ['pred_logits', 'pred_boxes']:
            torch.testing.assert_close(actual[key], expected[key], rtol=0, atol=0)

    def test_forced_query_indices_regenerate_changed_content_and_initial_boxes(self):
        decoder = RTDETRTransformer(num_classes=3, hidden_dim=32, num_queries=8,
                                     feat_channels=[32]*3, num_decoder_layers=2, num_denoising=0).eval()
        with torch.no_grad(): decoder.enc_bbox_head.layers[-1].weight.normal_(std=.05)
        feats = [torch.randn(2, 32, h, w) for h, w in [(8, 12), (4, 6), (2, 3)]]
        with torch.no_grad():
            ref = decoder(feats, return_query_metadata=True)
            idx = ref['query_metadata']['topk_indices']
            changed = decoder([x+torch.randn_like(x) for x in feats], forced_indices=idx,
                              return_query_metadata=True)
        torch.testing.assert_close(changed['query_metadata']['topk_indices'], idx, rtol=0, atol=0)
        self.assertFalse(torch.equal(ref['query_metadata']['query_content'], changed['query_metadata']['query_content']))
        self.assertFalse(torch.equal(ref['query_metadata']['initial_boxes'], changed['query_metadata']['initial_boxes']))
        torch.testing.assert_close(ref['query_metadata']['anchor_centers'], changed['query_metadata']['anchor_centers'], rtol=0, atol=0)

    def test_reference_and_forced_noop_replay_are_exact_and_cache_is_reused(self):
        model = detector(True).eval()
        calls = {'rgb': 0, 'thermal': 0, 'attention': 0}
        hooks = []
        def count(key):
            def hook(*args): calls[key] += 1
            return hook
        hooks.append(model.rgb_backbone.register_forward_hook(count('rgb')))
        hooks.append(model.thermal_backbone.register_forward_hook(count('thermal')))
        for direction in [model.encoder.frequency_module.rgb_direction, model.encoder.frequency_module.thermal_direction]:
            for expert in direction.experts:
                hooks.append(expert.attention.register_forward_hook(count('attention')))
        rgb, thermal = torch.randn(1, 3, 64, 96), torch.randn(1, 3, 64, 96)
        with torch.no_grad():
            cache = model.prepare_frequency(rgb, thermal)
            ref = model.replay_frequency(cache, return_probe=True)
            same = model.replay_frequency(cache, forced_indices=ref['query_metadata']['topk_indices'])
        for key in ['pred_logits', 'pred_boxes']:
            torch.testing.assert_close(ref[key], same[key], rtol=0, atol=0)
        self.assertEqual(calls, {'rgb': 1, 'thermal': 1, 'attention': 8})
        for hook in hooks: hook.remove()

    def test_zero_image_valid_masks_suppress_both_residuals(self):
        model = detector(True).eval(); rgb, thermal = [torch.randn(1, 3, 64, 96) for _ in range(2)]
        masks = [torch.zeros(1, 1, 64, 96, dtype=torch.bool) for _ in range(2)]
        with torch.no_grad():
            cache = model.prepare_frequency(rgb, thermal, masks)
            r, t = model.encoder.frequency_module.mix(cache['frequency'])
        torch.testing.assert_close(r, cache['rgb_features'][0], rtol=0, atol=0)
        torch.testing.assert_close(t, cache['thermal_features'][0], rtol=0, atol=0)

    def test_training_aux_preserves_denoising_and_loss_gradient_split(self):
        from dyfclt.losses import build_criterion
        model = detector(True, denoising=4).train()
        targets = [dict(labels=torch.tensor([0]), boxes=torch.tensor([[.5, .5, .05, .05]])) for _ in range(2)]
        outputs = model(torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96), targets,
                        return_frequency_aux=True)
        self.assertIn('dn_aux_outputs', outputs)
        self.assertEqual(outputs['frequency_aux']['a'].shape[:3], (2, 2, 4))
        sum(build_criterion(3, mask_weight=0)(outputs, targets).values()).backward()
        for name, param in model.encoder.frequency_module.named_parameters():
            if '.evaluator.' in name: self.assertIsNone(param.grad, name)
            else: self.assertIsNotNone(param.grad, name)

    def test_forced_indices_reject_duplicate_or_invalid_and_training_probe(self):
        decoder = RTDETRTransformer(num_classes=3, hidden_dim=32, num_queries=8,
                                     feat_channels=[32]*3, num_decoder_layers=1, num_denoising=0).eval()
        feats = [torch.randn(1, 32, h, w) for h, w in [(8, 8), (4, 4), (2, 2)]]
        for indices in [torch.zeros(1, 8, dtype=torch.long), torch.full((1, 8), 999, dtype=torch.long), torch.zeros(1, 8)]:
            with self.assertRaises(ValueError): decoder(feats, forced_indices=indices)
        decoder.train()
        with self.assertRaises(ValueError): decoder(feats, return_query_metadata=True)

    def test_frequency_requires_the_plain_dual_stream_scaffold(self):
        for opts in [dict(architecture='dyfclt'), dict(architecture='dual_rtdetr', use_dfca=True),
                     dict(architecture='dual_rtdetr', use_sse=True)]:
            with self.assertRaises(ValueError):
                DyFCLT(3, hidden_dim=32, num_queries=8, frequency_utility=OPTIONS, **opts)


if __name__ == '__main__': unittest.main()
