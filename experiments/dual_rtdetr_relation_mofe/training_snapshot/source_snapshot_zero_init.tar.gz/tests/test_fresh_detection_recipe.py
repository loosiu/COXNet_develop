import json,unittest,tempfile,sys
from unittest.mock import patch
from pathlib import Path
from tools import train
from dyfclt.runtime import load_config
ROOT=Path(__file__).resolve().parents[1]
class FreshDetectionRecipeTests(unittest.TestCase):
 def test_fresh_sigmoid_gate_is_allowed_by_original_detection_trainer(self):
  self.assertTrue(hasattr(train,'validate_detection_config'),'Original detection trainer must allow the differentiable sigmoid gate')
  cfg=load_config(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml')
  self.assertTrue(train.validate_detection_config(cfg))
 def test_detached_beta_gate_stays_rejected(self):
  self.assertTrue(hasattr(train,'validate_detection_config'))
  cfg=load_config(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml')
  cfg['model']['frequency_utility']['gate_mode']='beta_utility'
  with self.assertRaises(ValueError):train.validate_detection_config(cfg)
 def test_trained_checkpoint_metadata_cannot_masquerade_as_fresh_training(self):
  self.assertTrue(hasattr(train,'validate_detection_config'))
  cfg=load_config(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml')
  cfg['initialization']={'checkpoint':'old_A_best.pth','weights':'ema'}
  with self.assertRaises(ValueError):train.validate_detection_config(cfg)
 def test_auxiliary_utility_is_rejected_by_detection_trainer(self):
  self.assertTrue(hasattr(train,'validate_detection_config'))
  cfg=load_config(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml')
  cfg['utility']={'enabled':True,'loss_weight':.1}
  with self.assertRaises(ValueError):train.validate_detection_config(cfg)
 def test_recipe_matches_saved_original_A_except_module_and_output(self):
  a=json.loads(Path('/data/siwoo/DyFCLT/outputs/rgbtdroneperson_dual_rtdetr_seed0/config.json').read_text())
  d=load_config(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml')
  d['model'].pop('frequency_utility')
  for cfg in [a,d]:cfg['train'].pop('output_dir')
  self.assertEqual(a,d)

 def test_cli_refuses_nonempty_partial_output_before_model_initialization(self):
  with tempfile.TemporaryDirectory() as directory:
   (Path(directory)/'debug.pth').write_text('existing partial experiment')
   argv=['train.py','--config',str(ROOT/'configs/rgbtdroneperson_detection_gate_fresh.yaml'),'--output-dir',directory]
   with patch.object(sys,'argv',argv),patch.object(train,'seed_everything',side_effect=AssertionError('Reached initialization before protecting destination')):
    with self.assertRaises(FileExistsError):train.main()
