import copy
import unittest
from unittest.mock import patch

import torch

from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, build_ema
from dyfclt.frequency_training import training_step
from dyfclt.utility_probe import UtilityTeacher, UtilityProbeSampler, make_utility_labels


class D1TrainingTests(unittest.TestCase):
    def test_readiness_requires_real_single_cell_backward_and_rejects_region_only_signal(self):
        from dyfclt import frequency_training as api
        self.assertTrue(hasattr(api, 'utility_preflight_ready'), 'Readiness must include successful valid-label backward')
        args = dict(probe_images=16, nonneutral_fraction=.125, finite=True, constants_exact=True)
        inactive = dict(applied=True, utility_active=False, evaluator_nonzero_grad=False,
                        evaluator_gradients_finite=True, valid_count=0)
        self.assertFalse(api.utility_preflight_ready(steps=[inactive, inactive], **args))
        active = dict(applied=True, utility_active=True, evaluator_nonzero_grad=True,
                      evaluator_gradients_finite=True, valid_count=1)
        self.assertTrue(api.utility_preflight_ready(steps=[active, inactive], **args))
        self.assertFalse(api.utility_preflight_ready(steps=[active], **args))
        self.assertFalse(api.utility_preflight_ready(steps=[active, inactive], **dict(args, nonneutral_fraction=0.)))
        self.assertFalse(api.utility_preflight_ready(steps=[dict(active, applied=False), inactive], **args))

    def test_real_optimizer_skips_neutral_evaluators_after_a_valid_utility_update(self):
        """Synthetic labels isolate update behavior; this does not prove real probe signal."""
        torch.manual_seed(17)
        model = DyFCLT(2, hidden_dim=32, num_queries=8, num_decoder_layers=1, num_denoising=4,
                       architecture='dual_rtdetr', pretrained=False,
                       frequency_utility=dict(dim=8, heads=2, evaluator_hidden=8, chunk_size=8))
        teacher, ema = UtilityTeacher(model), build_ema(model, {'ema': {'enabled': True}})
        sampler = UtilityProbeSampler(0)
        optimizer = build_optimizer(model, dict(lr=.00025, weight_decay=.01, optimizer_groups='rtdetr'))
        scaler = torch.cuda.amp.GradScaler(enabled=False)
        criterion = build_criterion(2, mask_weight=0)
        targets = [dict(labels=torch.tensor([0]), boxes=torch.tensor([[.5, .5, .1, .1]])) for _ in range(2)]
        batch = (torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96), targets)
        # Preserve all actual probe fields; only supervise known valid/neutral test branches.
        actual = make_utility_labels(teacher.module, *batch, criterion, sampler, check_noop=True)
        valid = copy.deepcopy(actual)
        valid['labels'] = torch.tensor([1., 0.]); valid['neutral'] = torch.tensor([False, False])
        utility = dict(enabled=True, loss_weight=.1, kl_max=.01, kl_ramp_epochs=2)
        with patch('dyfclt.utility_probe.make_utility_labels', return_value=valid):
            first = training_step(model, teacher, ema, sampler, criterion, optimizer, scaler, batch, utility, 0., do_probe=True)
        self.assertTrue(first.get('utility_active'), 'Valid labels must activate utility backward')
        self.assertEqual((first['valid_count'], first['positive_valid_count'], first['negative_valid_count']), (2, 1, 1))
        self.assertEqual(first['positive_fraction_all'], .5); self.assertEqual(first['positive_fraction_valid'], .5)
        params = {n: p for n, p in model.named_parameters() if '.evaluator.' in n}
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in params.values()))
        populated = {n: float(optimizer.state[p]['step']) for n, p in params.items() if p in optimizer.state}
        self.assertTrue(populated, 'First valid utility update must establish actual AdamW state')
        before = {n: p.detach().clone() for n, p in params.items()}
        neutral = copy.deepcopy(actual)
        neutral['labels'] = torch.tensor([0., 0.]); neutral['neutral'] = torch.tensor([True, True])
        with patch('dyfclt.utility_probe.make_utility_labels', return_value=neutral):
            second = training_step(model, teacher, ema, sampler, criterion, optimizer, scaler, batch, utility, 0.1, do_probe=True)
        self.assertFalse(second['utility_active']); self.assertEqual(second['utility_loss'], 0.)
        self.assertEqual(second['valid_count'], 0); self.assertIsNone(second['positive_fraction_valid'])
        self.assertTrue(second['applied']); self.assertGreater(second['detection_loss'], 0.)
        for name, parameter in params.items():
            self.assertIsNone(parameter.grad, name)
            torch.testing.assert_close(parameter, before[name], rtol=0, atol=0)
            if name in populated: self.assertEqual(float(optimizer.state[parameter]['step']), populated[name])
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for n, p in model.named_parameters()
                            if 'frequency_module.' in n and '.evaluator.' not in n))
        self.assertEqual((teacher.updates, ema.updates), (2, 2))
        # Zero utility loss weight also disconnects evaluators despite valid labels.
        with patch('dyfclt.utility_probe.make_utility_labels', return_value=valid):
            third = training_step(model, teacher, ema, sampler, criterion, optimizer, scaler, batch,
                                  dict(utility, loss_weight=0.), .2, do_probe=True)
        self.assertFalse(third['utility_active']); self.assertEqual(third['valid_count'], 2)
        for name, parameter in params.items():
            self.assertIsNone(parameter.grad, name)
            torch.testing.assert_close(parameter, before[name], rtol=0, atol=0)


if __name__ == '__main__': unittest.main()
