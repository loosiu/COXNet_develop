"""Behavioral oracles for the optional bounded-width DFCA projections."""

import math
import unittest

import torch
from torch.nn import functional as F

from dyfclt.frequency import DFCA


def _conv_reference(value, layer):
    return F.conv2d(value, layer.weight.double(), layer.bias.double(),
                    padding=layer.padding, groups=layer.groups)


def _direct_dft(value, inverse=False):
    """Small matrix DFT oracle, independent of production FFT helpers."""
    height, width = value.shape[-2:]
    y = torch.arange(height, dtype=torch.float64)
    x = torch.arange(width, dtype=torch.float64)
    vertical = torch.exp(-2j * math.pi * y[:, None] * y[None, :] / height)
    horizontal = torch.exp(-2j * math.pi * x[:, None] * x[None, :] / width)
    if inverse:
        return torch.einsum('kh,nckl,lw->nchw', vertical.conj(),
                            value.cdouble(), horizontal.conj()) / (height * width)
    return torch.einsum('kh,nchw,lw->nckl', vertical, value.cdouble(), horizontal)


def _equation_reference(module, other, target):
    """Evaluate the published operation with direct DFTs and literal octave edges."""
    query, key, value = (
        _conv_reference(_conv_reference(tensor.double(), branch[0]), branch[1])
        for tensor, branch in ((other, module.query), (target, module.key),
                               (target, module.value))
    )
    height, width = target.shape[-2:]
    fy = torch.tensor([min(y, height - y) / height for y in range(height)])
    fx = torch.tensor([min(x, width - x) / width for x in range(width)])
    radius = (fy[:, None].square() + fx[None, :].square()).sqrt()
    q_spectrum, k_spectrum, v_spectrum = map(_direct_dft, (query, key, value))
    response = torch.zeros_like(query)
    for lower, upper in ((0., .125), (.125, .25), (.25, .5)):
        band = ((radius >= lower) & (radius < upper)).double()
        correlation = _direct_dft(q_spectrum * k_spectrum.conj() * band,
                                  inverse=True).real
        attention = _conv_reference(correlation, module.spatial_modulator).sigmoid()
        response += attention * _direct_dft(v_spectrum * band, inverse=True).real
    centered = response - response.mean(dim=1, keepdim=True)
    normalized = centered / (centered.square().mean(dim=1, keepdim=True) + 1e-5).sqrt()
    normalized = (normalized * module.norm.weight.double()[None, :, None, None]
                  + module.norm.bias.double()[None, :, None, None])
    return _conv_reference(normalized, module.projection).float()


class CompactDFCATests(unittest.TestCase):
    def test_width_48_keeps_256_channel_output_within_four_block_budget(self):
        # Ignoring the bottleneck or retaining a C-by-C gate breaks this budget.
        module = DFCA(256, inner_channels=48)
        self.assertEqual(module.channels, 256)
        self.assertEqual(module.inner_channels, 48)
        self.assertEqual(sum(parameter.numel() for parameter in module.parameters()), 71875)
        self.assertEqual(4 * sum(parameter.numel() for parameter in module.parameters()), 287500)
        with torch.no_grad():
            output = module(torch.randn(2, 256, 7, 9), torch.randn(2, 256, 7, 9))
        self.assertEqual(output.shape, (2, 256, 7, 9))
        self.assertTrue(torch.isfinite(output).all())

    def test_compact_equation_matches_independent_matrix_dft_on_rectangles(self):
        # Detect wrong inner axes, lost conjugation/bands, gate, LN, or recovery.
        torch.manual_seed(113)
        module = DFCA(5, inner_channels=3).eval()
        with torch.no_grad():
            for index, branch in enumerate((module.query, module.key, module.value)):
                branch[0].weight.copy_(torch.arange(15).reshape(3, 5, 1, 1) / 20 - .2 + index / 10)
        for height, width in ((5, 7), (6, 9)):
            with self.subTest(height=height, width=width):
                other, target = torch.zeros(2, 5, height, width), torch.zeros(2, 5, height, width)
                for batch in range(2):
                    for channel in range(5):
                        other[batch, channel, (channel + batch) % height, (channel + 2) % width] = channel + 1
                        target[batch, channel, (channel + 2) % height, (2 * channel + batch) % width] = 2 - channel
                with torch.no_grad():
                    expected = _equation_reference(module, other, target)
                    actual = module(other, target)
                torch.testing.assert_close(actual, expected, atol=2e-5, rtol=2e-5)

    def test_all_compact_parameters_inputs_and_band_boundaries_receive_gradients(self):
        # A detached branch or unused compact parameter must fail this check.
        torch.manual_seed(29)
        module = DFCA(6, inner_channels=4)
        other = torch.randn(2, 6, 9, 11, requires_grad=True)
        target = torch.randn(2, 6, 9, 11, requires_grad=True)
        output = module(other, target)
        weights = torch.linspace(-.7, 1.3, output.numel()).reshape_as(output)
        (output.square().mean() + (output * weights).mean()).backward()
        gradients = [('query_input', other.grad), ('target_input', target.grad)]
        gradients.extend((name, parameter.grad) for name, parameter in module.named_parameters())
        for name, gradient in gradients:
            with self.subTest(name=name):
                self.assertIsNotNone(gradient)
                self.assertTrue(torch.isfinite(gradient).all())
                self.assertGreater(gradient.abs().sum().item(), 0.)

    def test_default_none_and_equal_width_preserve_state_rng_and_exact_output(self):
        # Adding initialization or changing default shapes breaks checkpoint/RNG parity.
        modules, rng_states = [], []
        for kwargs in ({}, {'inner_channels': None}, {'inner_channels': 6}):
            torch.manual_seed(47)
            modules.append(DFCA(6, **kwargs))
            rng_states.append(torch.random.get_rng_state())
        expected_state = modules[0].state_dict()
        other, target = torch.randn(2, 6, 5, 7), torch.randn(2, 6, 5, 7)
        with torch.no_grad():
            expected_output = modules[0](other, target)
            for module, rng_state in zip(modules[1:], rng_states[1:]):
                self.assertEqual(list(module.state_dict()), list(expected_state))
                for name, value in module.state_dict().items():
                    torch.testing.assert_close(value, expected_state[name], atol=0, rtol=0, msg=name)
                torch.testing.assert_close(rng_state, rng_states[0], atol=0, rtol=0)
                module.load_state_dict(expected_state, strict=True)
                torch.testing.assert_close(module(other, target), expected_output, atol=0, rtol=0)

    def test_explicit_width_rejects_invalid_dimensions(self):
        for width in (0, -1, 1.5, '48', True, False):
            with self.subTest(width=width):
                with self.assertRaisesRegex(ValueError, 'inner_channels.*positive integer'):
                    DFCA(6, inner_channels=width)

    def test_compact_width_still_validates_external_input_channels(self):
        # Checking against D instead of C would accept an invalid model boundary.
        module = DFCA(6, inner_channels=4)
        with self.assertRaisesRegex(ValueError, 'input channel count'):
            module(torch.randn(1, 4, 5, 7), torch.randn(1, 4, 5, 7))


if __name__ == '__main__':
    unittest.main()
