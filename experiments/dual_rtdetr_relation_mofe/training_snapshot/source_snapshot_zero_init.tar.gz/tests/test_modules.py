"""Numerical checks for the paper-specific DFCA and SSE operations."""

import unittest

import torch
from torch import nn
from torch.nn import functional as F

from dyfclt.frequency import DFCA, FrequencyBandDecomposition, frequency_correlation
from dyfclt.sse import SSE


class FrequencyTests(unittest.TestCase):
    def test_frequency_correlation_uses_conjugate_key(self):
        query = torch.zeros(1, 1, 7, 9)
        key = torch.zeros_like(query)
        query[..., 2, 3] = 1
        key[..., 4, 5] = 1
        result = frequency_correlation(torch.fft.fft2(query), torch.fft.fft2(key))
        expected = torch.zeros_like(result)
        expected[..., 5, 7] = 1  # (2-4 mod 7, 3-5 mod 9)
        torch.testing.assert_close(result, expected, atol=1e-6, rtol=0)

    def test_octave_bands_cover_only_nyquist_disk(self):
        bands = FrequencyBandDecomposition(num_bands=3)
        torch.testing.assert_close(bands.boundaries(), torch.tensor([0., .125, .25, .5]))
        masks = bands.masks(16, 20)
        self.assertEqual(tuple(masks.shape), (3, 16, 20))
        self.assertEqual(masks[:, 0, 0].tolist(), [1., 0., 0.])
        self.assertEqual(masks[:, 0, 4].tolist(), [0., 1., 0.])  # v=4/20=.2
        self.assertEqual(masks[:, 8, 10].sum().item(), 0.)  # radial corner > .5
        self.assertEqual(masks[:, 8, 0].sum().item(), 0.)  # upper edge is strict

    def test_learned_boundaries_keep_exact_nyquist_endpoint(self):
        bands = FrequencyBandDecomposition(num_bands=3)
        with torch.no_grad():
            bands.band_logits.copy_(torch.tensor([-3.563874, -2.1562569, .12626955]))
        edges = bands.boundaries()
        self.assertEqual(edges[0].item(), 0.0)
        self.assertEqual(edges[-1].item(), 0.5)
        self.assertTrue(bool(torch.all(edges[1:] > edges[:-1])))
        self.assertEqual(bands.masks(16, 20)[:, 8, 0].sum().item(), 0.0)

    def test_hard_band_edges_receive_surrogate_gradients(self):
        bands = FrequencyBandDecomposition(num_bands=3, temperature=.01)
        masks = bands.masks(17, 19)
        weights = torch.arange(3, dtype=masks.dtype).view(3, 1, 1)
        (masks * weights).sum().backward()
        self.assertIsNotNone(bands.band_logits.grad)
        self.assertGreater(bands.band_logits.grad.abs().sum().item(), 1e-5)

    def test_dfca_odd_rectangle_has_finite_inputs_and_band_gradients(self):
        module = DFCA(4, num_bands=3)
        other = torch.randn(2, 4, 9, 11, requires_grad=True)
        target = torch.randn(2, 4, 9, 11, requires_grad=True)
        output = module(other, target)
        self.assertEqual(output.shape, target.shape)
        output.square().mean().backward()
        for grad in (other.grad, target.grad, module.bands.band_logits.grad):
            self.assertIsNotNone(grad)
            self.assertTrue(torch.isfinite(grad).all())
        self.assertGreater(module.bands.band_logits.grad.abs().sum().item(), 0)


class SSETests(unittest.TestCase):
    def test_binary_foreground_preserves_fine_feature_when_background_empty(self):
        module = SSE(1, reduction=1, kernel_size=3, fusion_block=nn.Identity())
        with torch.no_grad():
            module.mask_predictor.weight.zero_()
            module.mask_predictor.bias.fill_(20)
        fine = torch.randn(1, 1, 6, 8)
        coarse = torch.randn(1, 1, 3, 4)
        fused_input, logits = module(fine, coarse)
        torch.testing.assert_close(fused_input[:, 1:], fine, atol=0, rtol=0)
        self.assertEqual(logits.shape, (1, 1, 6, 8))

    def test_guided_upsampling_matches_manual_phase_and_kernel_oracle(self):
        torch.manual_seed(17)
        module = SSE(3, reduction=1, kernel_size=3, fusion_block=nn.Identity())
        with torch.no_grad():
            module.mask_predictor.weight.zero_()
            module.mask_predictor.bias.fill_(20)
        fine = torch.randn(1, 3, 4, 6)
        coarse = torch.arange(18., dtype=torch.float32).view(1, 3, 2, 3)
        fused_input, _ = module(fine, coarse)
        weights = module.kernel_predictor(fine).softmax(dim=1)
        padded = F.pad(coarse, (1, 1, 1, 1))
        expected_guided = torch.empty_like(fine)
        for channel in range(3):
            for fy in range(4):
                for fx in range(6):
                    cy, cx = fy // 2, fx // 2
                    patch = padded[0, channel, cy:cy + 3, cx:cx + 3].reshape(-1)
                    expected_guided[0, channel, fy, fx] = (weights[0, :, fy, fx] * patch).sum()
        expected = expected_guided + F.interpolate(coarse, scale_factor=2, mode="bilinear", align_corners=False)
        torch.testing.assert_close(fused_input[:, :3], expected, atol=1e-6, rtol=1e-6)

    def test_sse_rejects_non_double_resolution(self):
        module = SSE(2, fusion_block=nn.Identity())
        with self.assertRaisesRegex(ValueError, "twice"):
            module(torch.randn(1, 2, 5, 8), torch.randn(1, 2, 3, 4))

    def test_sse_backward_is_finite_for_fine_coarse_and_mask(self):
        module = SSE(4, reduction=2, kernel_size=3, fusion_block=nn.Conv2d(8, 4, 1))
        fine = torch.randn(2, 4, 8, 12, requires_grad=True)
        coarse = torch.randn(2, 4, 4, 6, requires_grad=True)
        output, logits = module(fine, coarse)
        self.assertEqual(output.shape, fine.shape)
        (output.square().mean() + logits.square().mean()).backward()
        for grad in (fine.grad, coarse.grad, module.mask_predictor.weight.grad):
            self.assertIsNotNone(grad)
            self.assertTrue(torch.isfinite(grad).all())


if __name__ == "__main__":
    unittest.main()
