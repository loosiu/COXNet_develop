import importlib
import unittest

import torch

from dyfclt.frequency_utility import FrequencyUtilityEnhancer, LocalFrequencyAttention
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion


class D2GateTests(unittest.TestCase):
    def api(self):
        try: return importlib.import_module('dyfclt.detection_gate')
        except ModuleNotFoundError: self.fail('Detection-trained sigmoid gates are missing')

    def test_sigmoid_heads_are_adaptive_from_start_and_do_not_return_beta_evidence(self):
        module = self.api().DetectionFrequencyEnhancer(8, 4, 2, evaluator_hidden=8, chunk_size=4)
        _, _, aux = module(torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5))
        self.assertEqual(set(aux), {'s', 'w', 'valid_masks'})
        self.assertEqual(aux['w'].shape, (2, 2, 4, 3, 5))
        self.assertTrue(((aux['w'] > 0) & (aux['w'] < 1)).all())
        self.assertLess(abs(aux['w'].mean().item()-.25), .02)
        self.assertTrue((aux['w'].flatten(3).std(-1) > 0).all())
        torch.testing.assert_close(aux['w'], aux['s'].sigmoid(), rtol=1e-6, atol=1e-7)

    def test_expert_candidates_and_non_head_initial_weights_match_old_evidence_module(self):
        torch.manual_seed(44); old = FrequencyUtilityEnhancer(8, 4, 2, evaluator_hidden=8, chunk_size=4)
        torch.manual_seed(44); new = self.api().DetectionFrequencyEnhancer(8, 4, 2, evaluator_hidden=8, chunk_size=4)
        state = new.state_dict()
        for key, value in old.state_dict().items():
            if '.evaluator.head.5.' not in key:
                torch.testing.assert_close(state[key], value, rtol=0, atol=0, msg=key)
        r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        torch.testing.assert_close(new.build_cache(r, t)['candidates'], old.build_cache(r, t)['candidates'], rtol=0, atol=0)

    def test_detection_gate_keeps_all_three_input_gradient_paths_open(self):
        gate = self.api().DetectionGate(4, 8)
        q, context, candidate = [torch.randn(2, 4, 3, 5, requires_grad=True) for _ in range(3)]
        score, weight = gate(q, context, candidate)
        weight.sum().backward()
        for value in (q, context, candidate):
            self.assertIsNotNone(value.grad); self.assertGreater(value.grad.abs().sum().item(), 0.)

    def test_retrieved_context_can_train_q_and_k_without_training_value(self):
        attention = LocalFrequencyAttention(4, 2, 3, 4)
        attention.detach_context = False
        q, k, v = [torch.randn(2, 4, 3, 5, requires_grad=True) for _ in range(3)]
        _, context = attention(q, k, v)
        self.assertTrue(context.requires_grad, 'D2 retrieved key context must retain its graph')
        context.square().mean().backward()
        self.assertGreater(q.grad.abs().sum().item(), 0.)
        self.assertGreater(k.grad.abs().sum().item(), 0.)
        self.assertIsNone(v.grad)

    def test_detection_residual_trains_every_score_head_on_first_batch(self):
        module = self.api().DetectionFrequencyEnhancer(8, 4, 2, evaluator_hidden=8, chunk_size=4)
        r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        out_r, out_t, _ = module(r, t)
        (out_r.square().mean()+out_t.square().mean()).backward()
        for direction in (module.rgb_direction, module.thermal_direction):
            for expert in direction.experts:
                for index in (0, 5):
                    grad = expert.evaluator.head[index].weight.grad
                    self.assertIsNotNone(grad); self.assertTrue(torch.isfinite(grad).all())
                    self.assertGreater(grad.abs().sum().item(), 0.)
        self.assertGreater(module.project_rgb.weight.grad.abs().sum().item(), 0.)

    def test_zero_gates_reproduce_a_and_actual_detector_loss_trains_sigmoid_gate(self):
        self.api()
        options=dict(num_classes=2, hidden_dim=32, num_queries=8, num_decoder_layers=1,
                     num_denoising=4, architecture='dual_rtdetr', pretrained=False)
        torch.manual_seed(9); plain=DyFCLT(**options).eval()
        torch.manual_seed(9); model=DyFCLT(**options, frequency_utility=dict(
            gate_mode='sigmoid_detection', dim=8, heads=2, evaluator_hidden=8, chunk_size=8)).eval()
        r, t = torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96)
        with torch.no_grad():
            cache=model.prepare_frequency(r,t)
            actual=model.replay_frequency(cache, torch.zeros_like(cache['frequency']['w']))
            expected=plain(r,t)
        for key in ('pred_logits','pred_boxes'): torch.testing.assert_close(actual[key],expected[key],rtol=0,atol=0)
        model.train()
        targets=[dict(labels=torch.tensor([0]),boxes=torch.tensor([[.5,.5,.1,.1]])) for _ in range(2)]
        output=model(r,t,targets,return_frequency_aux=True)
        self.assertIn('dn_aux_outputs',output)
        sum(build_criterion(2,mask_weight=0)(output,targets).values()).backward()
        heads=[p for n,p in model.named_parameters() if '.evaluator.head.5.' in n]
        self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in heads))
        self.assertTrue(all(p.grad.abs().sum() > 0 for p in heads))


if __name__ == '__main__': unittest.main()
