import importlib
import unittest

import torch

from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.utility_probe import FrozenDetectionCost
import test_utility_probe as baseline_probe


class D2ObjectSweepTests(unittest.TestCase):
    def api(self):
        try: return importlib.import_module('dyfclt.object_sweep')
        except ModuleNotFoundError: self.fail('Fixed-object gate sweep is missing')

    def test_local_cost_uses_frozen_matched_query_without_whole_image_gt_dilution(self):
        api=self.api(); ref, targets=baseline_probe.UtilityProbeTests.fixture()
        targets[0]['labels']=torch.tensor([0, 1])
        targets[0]['boxes']=torch.tensor([[.5,.5,.2,.2],[.8,.8,.1,.1]])
        frozen=FrozenDetectionCost.from_reference(ref, targets, build_criterion(2,mask_weight=0))
        sites=torch.tensor([[0,0,0,0,2,2],[1,1,2,-1,4,4]])
        context=api.FixedObjectCost(frozen,sites)
        changed={k:v.clone() for k,v in ref.items()}; changed['pred_boxes'][0,0,2:]=.4
        local=context.components(changed); whole=frozen.components(changed)
        self.assertAlmostEqual(local['bbox'][0].item(),2.,places=6)
        self.assertAlmostEqual(local['giou'][0].item(),1.5,places=5)
        self.assertAlmostEqual(whole['bbox'][0].item(),1.,places=6)
        self.assertEqual(local['bbox'][1].item(),0.)
        self.assertEqual(local['giou'][1].item(),0.)
        before=context.components(ref)
        # Move a different query: local target stays fixed, whole image sees it.
        changed={k:v.clone() for k,v in ref.items()}; changed['pred_logits'][0,1] += 3
        torch.testing.assert_close(context.components(changed)['total'],before['total'],rtol=0,atol=0)
        self.assertNotEqual(frozen.cost(changed)[0].item(),frozen.cost(ref)[0].item())

    def test_mismatched_gt_or_background_query_cannot_change_fixed_target_identity(self):
        api=self.api(); ref,targets=baseline_probe.UtilityProbeTests.fixture()
        frozen=FrozenDetectionCost.from_reference(ref,targets,build_criterion(2,mask_weight=0))
        for bad in [torch.tensor([[0,0,1,0,2,2],[1,1,2,-1,4,4]]),
                    torch.tensor([[0,0,0,-1,2,2],[1,1,2,-1,4,4]])]:
            with self.assertRaises(ValueError): api.FixedObjectCost(frozen,bad)

    def test_object_sampler_preserves_gt_query_identity_and_background_reference_index(self):
        api=self.api(); ref,targets=baseline_probe.UtilityProbeTests.fixture()
        ref['query_metadata']=dict(anchor_centers=torch.tensor([[[.5,.5],[.8,.8],[.1,.1]],[[.2,.2],[.4,.4],[.9,.9]]]))
        matching=[(torch.tensor([0]),torch.tensor([0])),(torch.empty(0,dtype=torch.long),torch.empty(0,dtype=torch.long))]
        cache=dict(valid_masks=torch.ones(2,2,5,5,dtype=torch.bool))
        sampler=api.ObjectProbeSampler(seed=0,gt_probability=1.)
        state=sampler.state_dict()
        sites,kinds=sampler.sample(ref,targets,matching,cache)
        self.assertEqual(sites[0,2:4].tolist(),[0,0])
        self.assertEqual(sites[0,4:].tolist(),[2,2])
        self.assertEqual(kinds,['matched_gt','unmatched_background'])
        self.assertEqual(sites[1,2:4].tolist(),[2,-1])
        sampler.load_state_dict(state)
        repeated,_=sampler.sample(ref,targets,matching,cache)
        torch.testing.assert_close(repeated,sites,rtol=0,atol=0)

    def test_sweep_changes_only_one_expert_on_valid_receiver_region(self):
        api=self.api(); reference=torch.full((2,2,4,3,5),.25)
        sites=torch.tensor([[0,0,0,0,0,0],[1,1,2,-1,2,4]])
        masks=torch.ones(2,2,3,5,dtype=torch.bool)
        masks[0,0,1,1]=False; masks[1,1,2,3]=False
        actual=api.object_sweep_gates(reference,sites,2,.75,masks,3)
        expected=reference.clone()
        for y,x in [(0,0),(0,1),(1,0)]:expected[0,0,2,y,x]=.75
        for y,x in [(1,3),(1,4),(2,4)]:expected[1,1,2,y,x]=.75
        torch.testing.assert_close(actual,expected,rtol=0,atol=0)
        self.assertTrue((reference==.25).all())

    def test_actual_detector_sweep_keeps_one_cache_matching_and_queries_for_all_bands(self):
        api=self.api(); torch.manual_seed(31)
        model=DyFCLT(2,hidden_dim=32,num_queries=8,num_decoder_layers=1,num_denoising=0,
            pretrained=False,architecture='dual_rtdetr',frequency_utility=dict(
                gate_mode='sigmoid_detection',dim=8,heads=2,evaluator_hidden=8,chunk_size=8)).eval()
        calls={'rgb':0,'thermal':0,'attention':0};hooks=[]
        def count(key):
            def hook(*args): calls[key]+=1
            return hook
        hooks += [model.rgb_backbone.register_forward_hook(count('rgb')),model.thermal_backbone.register_forward_hook(count('thermal'))]
        for direction in (model.encoder.frequency_module.rgb_direction,model.encoder.frequency_module.thermal_direction):
            for expert in direction.experts:hooks.append(expert.attention.register_forward_hook(count('attention')))
        targets=[dict(labels=torch.tensor([0]),boxes=torch.tensor([[.5,.5,.1,.1]])),
                 dict(labels=torch.empty(0,dtype=torch.long),boxes=torch.empty(0,4))]
        report=api.fixed_object_sweep(model,torch.randn(2,3,64,96),torch.randn(2,3,64,96),targets,
                    build_criterion(2,mask_weight=0),api.ObjectProbeSampler(0),weights=(0.,.25,1.))
        self.assertEqual(calls,{'rgb':1,'thermal':1,'attention':8})
        self.assertEqual(set(report['bands']),{'LL','LH','HL','HH'})
        self.assertTrue(report['cache_unchanged']);self.assertTrue(report['query_indices_fixed'])
        self.assertTrue(report['matching_unchanged']);self.assertEqual(report['object_noop_error'],[0.,0.])
        self.assertEqual(report['image_noop_error'],[0.,0.]);self.assertNotIn('labels',report)
        self.assertTrue(report['diagnostic_only'])
        for band in report['bands'].values():
            self.assertEqual(band['weights'],[0.,.25,1.])
            self.assertEqual(len(band['object_cost']),3)
            self.assertEqual(band['object_utility_from_zero'][0],[0.,0.])
            self.assertTrue(torch.isfinite(torch.tensor(band['object_cost'])).all())
            self.assertGreater(max(band['receiver_p3_max_abs_diff'][-1]),0.)
        for hook in hooks:hook.remove()


if __name__=='__main__':unittest.main()
