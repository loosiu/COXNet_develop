import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
import torch
from tools.pre_pyramid_protocol import check_recipe, predecessor_state, verify_manifest, variant_paths
from dyfclt.runtime import load_config
from dyfclt.frequency_training import sha256, source_manifest

ROOT=Path(__file__).resolve().parents[1]

class PrePyramidProtocolTests(unittest.TestCase):
    def test_new_configs_only_move_insertion_and_output(self):
        for variant in ['B','E']:
            cfg=load_config(variant_paths(variant)['config']);self.assertTrue(check_recipe(variant,cfg))

    def test_reject_recipe_or_position_drift(self):
        c=load_config(variant_paths('B')['config'])
        for fn in [lambda x:x['train'].update(batch_size=8),
                   lambda x:x['model']['frequency_utility'].update(insertion_point='post_encoder')]:
            changed=copy.deepcopy(c);fn(changed)
            with self.assertRaises(ValueError):check_recipe('B',changed)

    def test_invalid_variant_or_gpu_rejected_before_cuda(self):
        for args in [[],['B','0'],['E','1'],['other','1'],['B','1','--amp']]:
            p=subprocess.run(['bash',str(ROOT/'tools/train_pre_pyramid_gpu.sh'),*args],capture_output=True,text=True)
            self.assertEqual(p.returncode,2,p.stderr)

    def test_waiting_and_failed_predecessor(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'controller_pid.txt').write_text(str(os.getpid()))
            self.assertEqual(predecessor_state(p)['state'],'waiting')
            (p/'exit_code.txt').write_text('1');self.assertEqual(predecessor_state(p)['state'],'failed')

    def test_full_matching_checkpoint_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);out=p/'output';out.mkdir();cfg={'train':{'epochs':20,'output_dir':str(out)}}
            (p/'exit_code.txt').write_text('0');(p/'launch.json').write_text(json.dumps({'resolved_config':cfg,'expected_total_updates':49000}))
            checkpoint=dict(epoch=19,global_step=49000,config=cfg,partial_epoch=False)
            torch.save(checkpoint,out/'last.pth');torch.save({},out/'best.pth')
            self.assertEqual(predecessor_state(p)['state'],'succeeded')
            checkpoint['global_step']=48999;torch.save(checkpoint,out/'last.pth')
            self.assertEqual(predecessor_state(p)['state'],'failed')

    def test_changed_frozen_input_or_code_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp)
            for folder in ['dyfclt','tools','configs']:(r/folder).mkdir()
            source=r/'tools/x.py';source.write_text('x=1\n');inp=r/'input.json';inp.write_text('{}')
            m={'source_sha256':source_manifest(r),'frozen_inputs':{str(inp):sha256(inp)}}
            verify_manifest(r,m)
            inp.write_text('{"x":1}')
            with self.assertRaises(ValueError):verify_manifest(r,m)
            inp.write_text('{}');source.write_text('x=2\n')
            with self.assertRaises(ValueError):verify_manifest(r,m)

if __name__=='__main__':unittest.main()
