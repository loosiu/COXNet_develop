import importlib
import math
import unittest

import torch

from dyfclt.frequency_utility import FrequencyUtilityEnhancer
from dyfclt.losses import build_criterion
import test_utility_probe as baseline_probe


class D1UtilityTests(unittest.TestCase):
    def setUp(self):
        self.api = importlib.import_module('dyfclt.utility_probe')

    def test_all_neutral_is_disconnected_zero_including_kl(self):
        module = FrequencyUtilityEnhancer(8, 4, 2, evaluator_hidden=8)
        r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        rout, tout, aux = module(r, t)
        probe = dict(selections=torch.tensor([[0, 0, 0, 1, 1], [1, 1, 2, 2, 3]]),
                     labels=torch.tensor([0., 0.]), neutral=torch.tensor([True, True]))
        loss = self.api.sampled_utility_loss(aux, probe, kl_weight=.01)
        self.assertEqual(loss.item(), 0.)
        self.assertFalse(loss.requires_grad)
        (rout.square().mean()+tout.square().mean()+loss).backward()
        for name, p in module.named_parameters():
            if '.evaluator.' in name: self.assertIsNone(p.grad, name)

    def test_mixed_neutral_positive_negative_only_valid_sites_receive_fit_and_kl(self):
        a = torch.full((3, 2, 4, 2, 2), 2., requires_grad=True)
        b = torch.full_like(a, 2., requires_grad=True)
        probe = dict(selections=torch.tensor([[0, 0, 1, 0, 1], [1, 1, 2, 1, 0], [2, 0, 3, 1, 1]]),
                     labels=torch.tensor([0., 1., 0.]), neutral=torch.tensor([True, False, False]))
        loss = self.api.sampled_utility_loss(dict(a=a, b=b), probe, kl_weight=.01)
        self.assertAlmostEqual(loss.item(), .3+.01*(math.log(2)-.5), places=6)
        loss.backward()
        self.assertEqual(a.grad[0].count_nonzero().item(), 0)
        self.assertEqual(b.grad[0].count_nonzero().item(), 0)
        self.assertEqual(a.grad[1:].count_nonzero().item(), 2)
        self.assertEqual(b.grad[1:].count_nonzero().item(), 2)

    def test_bad_neutral_mask_and_label_lengths_are_rejected(self):
        aux = dict(a=torch.ones(1, 2, 4, 2, 2), b=torch.ones(1, 2, 4, 2, 2))
        for labels, neutral in [(torch.tensor([0.]), torch.tensor([0.])),
                                (torch.tensor([0., 1.]), torch.tensor([True, True]))]:
            with self.assertRaises(ValueError):
                self.api.sampled_utility_loss(aux, dict(selections=torch.tensor([[0, 0, 0, 0, 0]]),
                                                      labels=labels, neutral=neutral))

    def region_api(self):
        self.assertTrue(hasattr(self.api, 'region_coalition_gates'), 'Region diagnostic is missing')
        return self.api.region_coalition_gates

    def test_region_size_one_is_bitwise_identical_to_existing_single_cell(self):
        fn = self.region_api()
        reference = torch.rand(2, 2, 4, 3, 5)
        sites = torch.tensor([[0, 0, 2, 0, 0], [1, 1, 0, 2, 4]])
        before = reference.clone()
        on, off, draw = self.api.coalition_gates(reference, sites, torch.Generator().manual_seed(8))
        region_on, region_off = fn(reference, sites, draw, torch.ones(2, 2, 3, 5, dtype=torch.bool), 1)
        torch.testing.assert_close(region_on, on, rtol=0, atol=0)
        torch.testing.assert_close(region_off, off, rtol=0, atol=0)
        torch.testing.assert_close(reference, before, rtol=0, atol=0)

    def test_region_rejects_fractional_or_unsupported_size_before_slicing(self):
        fn = self.region_api()
        reference = torch.full((1, 2, 4, 3, 3), .25)
        site = torch.tensor([[0, 0, 0, 1, 1]])
        for size in (3.0, True, 2, 0, 7):
            with self.assertRaises(ValueError):
                fn(reference, site, torch.zeros(1, 4), torch.ones(1, 2, 3, 3, dtype=torch.bool), size)

    def test_region_changes_only_selected_masked_direction_band_and_preserves_outside(self):
        fn = self.region_api()
        reference = torch.full((2, 2, 4, 3, 5), .25)
        before = reference.clone()
        sites = torch.tensor([[0, 0, 2, 0, 0], [1, 1, 0, 2, 4]])
        mask = torch.ones(2, 2, 3, 5, dtype=torch.bool)
        mask[0, 0, 1, 1] = False; mask[1, 1, 2, 3] = False
        coalitions = torch.tensor([[0., 1., 0., 1.], [1., 0., 1., 0.]])
        on, off = fn(reference, sites, coalitions, mask, 3)
        expected = torch.zeros_like(reference)
        for y, x in [(0, 0), (0, 1), (1, 0)]: expected[0, 0, 2, y, x] = 1
        for y, x in [(1, 3), (1, 4), (2, 4)]: expected[1, 1, 0, y, x] = 1
        torch.testing.assert_close(on-off, expected, rtol=0, atol=0)
        outside = torch.ones_like(reference, dtype=torch.bool)
        for y, x in [(0, 0), (0, 1), (1, 0)]: outside[0, 0, :, y, x] = False
        for y, x in [(1, 3), (1, 4), (2, 4)]: outside[1, 1, :, y, x] = False
        torch.testing.assert_close(on[outside], reference[outside], rtol=0, atol=0)
        torch.testing.assert_close(off[outside], reference[outside], rtol=0, atol=0)
        self.assertEqual(on[0, 0, 1, 0, 1].item(), 1.)
        self.assertEqual(off[0, 0, 1, 0, 1].item(), 1.)
        torch.testing.assert_close(reference, before, rtol=0, atol=0)

    def test_components_use_original_frozen_normalization_and_cost_coefficients(self):
        outputs, targets = baseline_probe.UtilityProbeTests.fixture()
        frozen = self.api.FrozenDetectionCost.from_reference(outputs, targets, build_criterion(2, mask_weight=0))
        self.assertTrue(hasattr(frozen, 'components'), 'Frozen component diagnostics are missing')
        ref = frozen.components(outputs)
        self.assertEqual(set(ref), {'vfl', 'bbox', 'giou', 'total'})
        changed = {k: v.clone() for k, v in outputs.items()}
        changed['pred_boxes'][0, 0, 2:] = .4
        parts = frozen.components(changed)
        self.assertAlmostEqual(parts['bbox'][0].item(), 2., places=6)
        self.assertAlmostEqual(parts['giou'][0].item(), 1.5, places=5)
        self.assertEqual(parts['bbox'][1].item(), 0.)
        self.assertEqual(parts['giou'][1].item(), 0.)
        torch.testing.assert_close(parts['vfl'], ref['vfl'], rtol=0, atol=0)
        torch.testing.assert_close(parts['total'], parts['vfl']+parts['bbox']+parts['giou'], rtol=0, atol=0)
        torch.testing.assert_close(frozen.cost(changed), parts['total'], rtol=0, atol=0)


if __name__ == '__main__': unittest.main()
