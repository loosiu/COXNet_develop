import importlib
import unittest

import torch

from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.utility_probe import FrozenDetectionCost, coalition_gates


def cloned_tensors(value, prefix=''):
    if torch.is_tensor(value): return {prefix: value.clone()}
    result = {}
    if isinstance(value, dict): entries = value.items()
    elif isinstance(value, (list, tuple)): entries = enumerate(value)
    else: return result
    for key, item in entries: result.update(cloned_tensors(item, prefix+'/'+str(key)))
    return result


class D1DiagnosticTests(unittest.TestCase):
    def model(self):
        return DyFCLT(2, hidden_dim=32, num_queries=8, num_decoder_layers=1,
                      architecture='dual_rtdetr', pretrained=False, num_denoising=0,
                      frequency_utility=dict(dim=8, heads=2, evaluator_hidden=8, chunk_size=8)).eval()

    def test_replay_exposes_actual_p3_and_fused_p3_without_changing_predictions(self):
        model = self.model()
        with torch.no_grad():
            cache = model.prepare_frequency(torch.randn(1, 3, 64, 96), torch.randn(1, 3, 64, 96))
            normal = model.replay_frequency(cache)
            try: measured = model.replay_frequency(cache, return_diagnostics=True)
            except TypeError: self.fail('Replay feature diagnostics are not implemented')
            r, t = model.encoder.frequency_module.mix(cache['frequency'])
        self.assertEqual(set(measured['diagnostic_features']), {'rgb_p3', 'thermal_p3', 'fused_p3'})
        torch.testing.assert_close(measured['diagnostic_features']['rgb_p3'], r, rtol=0, atol=0)
        torch.testing.assert_close(measured['diagnostic_features']['thermal_p3'], t, rtol=0, atol=0)
        for key in ['pred_logits', 'pred_boxes']:
            torch.testing.assert_close(measured[key], normal[key], rtol=0, atol=0)

    def test_regions_reuse_candidates_queries_cost_context_and_preserve_entire_cache(self):
        try: api = importlib.import_module('dyfclt.utility_diagnostics')
        except ModuleNotFoundError: self.fail('Paired region diagnostics are not implemented')
        torch.manual_seed(22); model = self.model()
        calls = {'rgb': 0, 'thermal': 0, 'attention': 0}
        hooks = []
        def count(key):
            def hook(*args): calls[key] += 1
            return hook
        hooks += [model.rgb_backbone.register_forward_hook(count('rgb')),
                  model.thermal_backbone.register_forward_hook(count('thermal'))]
        for direction in [model.encoder.frequency_module.rgb_direction, model.encoder.frequency_module.thermal_direction]:
            for expert in direction.experts: hooks.append(expert.attention.register_forward_hook(count('attention')))
        with torch.no_grad():
            cache = model.prepare_frequency(torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96))
            before = cloned_tensors(cache)
            ref = model.replay_frequency(cache, return_probe=True)
            targets = [dict(labels=torch.tensor([0]), boxes=torch.tensor([[.5, .5, .1, .1]])) for _ in range(2)]
            frozen = FrozenDetectionCost.from_reference(ref, targets, build_criterion(2, mask_weight=0))
            quality, weights = frozen.quality_targets.clone(), frozen.classification_weights.clone()
            sites = torch.tensor([[0, 0, 1, 4, 5], [1, 1, 3, 4, 5]])
            on, off, draw = coalition_gates(cache['frequency']['w'], sites, torch.Generator().manual_seed(5))
            results = api.diagnose_regions(model, cache, ref, frozen, sites, draw, (1, 3, 5), single_gates=(on, off))
            for key, expected in before.items():
                torch.testing.assert_close(cloned_tensors(cache)[key], expected, rtol=0, atol=0, msg=key)
            self.assertTrue(results['cache_unchanged'])
            self.assertEqual(set(results['regions']), {'1', '3', '5'})
            self.assertEqual(results['regions']['1']['intervened_cells'], [1, 1])
            self.assertEqual(results['regions']['3']['intervened_cells'], [9, 9])
            self.assertEqual(results['regions']['5']['intervened_cells'], [25, 25])
            forced = ref['query_metadata']['topk_indices']
            expected_on = frozen.cost(model.replay_frequency(cache, on, forced_indices=forced))
            expected_off = frozen.cost(model.replay_frequency(cache, off, forced_indices=forced))
            torch.testing.assert_close(results['single_on_components']['total'], expected_on, rtol=0, atol=0)
            torch.testing.assert_close(results['single_off_components']['total'], expected_off, rtol=0, atol=0)
            for info in results['regions'].values():
                self.assertGreater(info['rgb_p3_max_abs_diff'][0], 0)
                self.assertEqual(info['thermal_p3_max_abs_diff'][0], 0.)
                self.assertEqual(info['rgb_p3_max_abs_diff'][1], 0.)
                self.assertGreater(info['thermal_p3_max_abs_diff'][1], 0)
                self.assertTrue(all(v > 0 for v in info['selected_candidate_rms']))
                self.assertTrue(all(torch.isfinite(torch.tensor(info[k])).all() for k in
                    ['fused_p3_max_abs_diff','logits_max_abs_diff','boxes_max_abs_diff','delta_vfl','delta_bbox','delta_giou','delta_total']))
            torch.testing.assert_close(frozen.quality_targets, quality, rtol=0, atol=0)
            torch.testing.assert_close(frozen.classification_weights, weights, rtol=0, atol=0)
        self.assertEqual(calls, {'rgb': 1, 'thermal': 1, 'attention': 8})
        for hook in hooks: hook.remove()


if __name__ == '__main__': unittest.main()
