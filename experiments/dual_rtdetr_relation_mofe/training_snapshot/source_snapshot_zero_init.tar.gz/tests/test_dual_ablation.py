import unittest

import torch
from torch import nn
from torch.nn import functional as F

from dyfclt.model import DyFCLT, DualRTDETREncoder
from dyfclt.sse import SSE


class TargetIdentity(nn.Module):
    def forward(self, query_source, target):
        return target


class DualAblationTests(unittest.TestCase):
    @staticmethod
    def features():
        return [torch.randn(2,c,h,w) for c,h,w in ((512,8,12),(1024,4,6),(2048,2,3))]

    def test_disabled_modules_match_original_two_encoder_baseline(self):
        torch.manual_seed(42)
        original=DualRTDETREncoder(hidden_dim=32).eval()
        torch.manual_seed(42)
        configurable=DualRTDETREncoder(hidden_dim=32,use_dfca=False,use_sse=False).eval()
        self.assertEqual(set(original.state_dict()),set(configurable.state_dict()))
        rgb,ir=self.features(),self.features()
        with torch.no_grad():
            expected=[m(torch.cat((r,t),dim=1)) for m,r,t in zip(original.modal_fusion,original.rgb_encoder(rgb),original.thermal_encoder(ir))]
            actual,masks=configurable(rgb,ir)
        self.assertEqual(masks,[])
        for a,b in zip(actual,expected):torch.testing.assert_close(a,b,rtol=0,atol=0)

    def test_identity_dfca_preserves_fpn_lateral_skips_and_pan_outputs(self):
        torch.manual_seed(17);original=DualRTDETREncoder(hidden_dim=32).eval()
        torch.manual_seed(17);variant=DualRTDETREncoder(hidden_dim=32,use_dfca=True,use_sse=False).eval()
        variant.rgb_dfca=nn.ModuleList([TargetIdentity(),TargetIdentity()])
        variant.thermal_dfca=nn.ModuleList([TargetIdentity(),TargetIdentity()])
        variant.load_state_dict(original.state_dict(),strict=True)
        rgb,ir=self.features(),self.features()
        with torch.no_grad():expected,_=original(rgb,ir);actual,masks=variant(rgb,ir)
        self.assertEqual(masks,[])
        for a,b in zip(actual,expected):torch.testing.assert_close(a,b,rtol=0,atol=0)

    def test_sse_reuses_baseline_csp_and_all_active_branches_backpropagate(self):
        for dfca,sse,fref in ((True,False,True),(False,True,True),(True,True,False),(True,True,True)):
            with self.subTest(dfca=dfca,sse=sse,fref=fref):
                torch.manual_seed(11)
                model=DualRTDETREncoder(hidden_dim=32,use_dfca=dfca,use_sse=sse,use_fref=fref)
                outputs,masks=model(self.features(),self.features())
                self.assertEqual([tuple(o.shape) for o in outputs],[(2,32,8,12),(2,32,4,6),(2,32,2,3)])
                self.assertEqual(len(masks),4 if sse else 0)
                loss=sum(o.square().mean() for o in outputs)+sum(m.sigmoid().mean() for m in masks)
                loss.backward()
                for name,parameter in model.named_parameters():
                    self.assertIsNotNone(parameter.grad,name)
                    self.assertTrue(torch.isfinite(parameter.grad).all(),name)
                registered=[p for p in model.state_dict(keep_vars=True).values() if isinstance(p,nn.Parameter)]
                self.assertEqual(len(registered),len(set(map(id,registered))))
                if sse:
                    self.assertFalse(any('fusion_block.' in n for n in model.state_dict()))
                    for module in list(model.rgb_sse)+list(model.thermal_sse):
                        self.assertEqual(module.kernel_predictor is not None,fref)

    def test_common_model_weights_and_decoder_initialization_are_identical(self):
        kwargs=dict(num_classes=3,hidden_dim=32,num_queries=8,num_decoder_layers=1,
                    num_denoising=4,pretrained=False,architecture='dual_rtdetr')
        torch.manual_seed(23);baseline=DyFCLT(**kwargs)
        torch.manual_seed(23);full=DyFCLT(**kwargs,use_dfca=True,use_sse=True)
        full_state=full.state_dict()
        for key,value in baseline.state_dict().items():
            torch.testing.assert_close(value,full_state[key],rtol=0,atol=0,msg=key)
        torch.manual_seed(23);only_sse=DyFCLT(**kwargs,use_sse=True)
        for key,value in only_sse.state_dict().items():
            torch.testing.assert_close(value,full_state[key],rtol=0,atol=0,msg=key)

    def test_ibs_initialization_does_not_shift_when_fref_is_removed(self):
        torch.manual_seed(37)
        full=DualRTDETREncoder(hidden_dim=32,use_dfca=True,use_sse=True,use_fref=True)
        torch.manual_seed(37)
        ibs=DualRTDETREncoder(hidden_dim=32,use_dfca=True,use_sse=True,use_fref=False)
        full_state=full.state_dict()
        for key,value in ibs.state_dict().items():
            torch.testing.assert_close(value,full_state[key],rtol=0,atol=0,msg=key)

    def test_ibs_without_fref_uses_ordinary_fpn_upsampling(self):
        module=SSE(8,fusion_block=nn.Identity(),use_fref=False)
        with torch.no_grad():
            module.mask_predictor.weight.zero_();module.mask_predictor.bias.fill_(100)
        fine=torch.randn(2,8,8,12);coarse=torch.randn(2,8,4,6)
        inputs,mask=module(fine,coarse)
        torch.testing.assert_close(inputs[:,:8],F.interpolate(coarse,scale_factor=2,mode='nearest'))
        torch.testing.assert_close(inputs[:,8:],fine)
        self.assertIsNone(module.kernel_predictor)
        self.assertEqual(mask.shape,(2,1,8,12))

    def test_legacy_architecture_rejects_silent_module_switches(self):
        with self.assertRaisesRegex(ValueError,'dual_rtdetr'):
            DyFCLT(3,use_dfca=False)


if __name__=='__main__':unittest.main()
