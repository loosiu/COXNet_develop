import importlib
import math
import unittest

import torch


class FrequencyUtilityTests(unittest.TestCase):
    def api(self):
        try:
            return importlib.import_module('dyfclt.frequency_utility')
        except ModuleNotFoundError:
            self.fail('The specified frequency utility module is not implemented')

    def module(self):
        torch.manual_seed(13)
        return self.api().FrequencyUtilityEnhancer(channels=8, dim=4, heads=2,
                                                  evaluator_hidden=8, chunk_size=3)

    def test_signed_haar_convention_and_replicate_edges(self):
        x = torch.tensor([[[[1., 2.], [3., 4.]]]])
        bands = self.api().haar_analysis(x)
        expected = [torch.tensor([[[[5., 6.], [7., 8.]]]]),
                    torch.tensor([[[[-1., 0.], [-1., 0.]]]]),
                    torch.tensor([[[[-2., -2.], [0., 0.]]]]), torch.zeros_like(x)]
        for actual, want in zip(bands, expected):
            torch.testing.assert_close(actual, want, rtol=0, atol=0)
        odd = torch.ones(2, 3, 3, 5)
        ll, *details = self.api().haar_analysis(odd)
        torch.testing.assert_close(ll, odd * 2, rtol=0, atol=0)
        for detail in details:
            self.assertEqual(torch.count_nonzero(detail).item(), 0)

    def test_local_attention_matches_independent_multhead_neighbour_calculation(self):
        api = self.api(); torch.manual_seed(21)
        layer = api.LocalFrequencyAttention(dim=4, heads=2, window_size=3, chunk_size=2)
        q, k, v = [torch.randn(1, 4, 2, 3) for _ in range(3)]
        mask = torch.tensor([[[[True, False, True], [True, True, False]]]])
        actual, context = layer(q, k, v, mask)
        want, want_context = torch.zeros_like(v), torch.zeros_like(k)
        for yy in range(2):
            for xx in range(3):
                locations = [(y, x) for y in range(max(0, yy-1), min(2, yy+2))
                             for x in range(max(0, xx-1), min(3, xx+2)) if mask[0, 0, y, x]]
                for head in range(2):
                    channels = slice(head*2, (head+1)*2)
                    keys = torch.stack([k[0, channels, y, x] for y, x in locations])
                    values = torch.stack([v[0, channels, y, x] for y, x in locations])
                    probability = ((keys * q[0, channels, yy, xx]).sum(-1) / math.sqrt(2)).softmax(0)
                    want[0, channels, yy, xx] = (probability[:, None] * values).sum(0)
                    want_context[0, channels, yy, xx] = (probability[:, None] * keys).sum(0)
        torch.testing.assert_close(actual, want, rtol=1e-6, atol=1e-6)
        torch.testing.assert_close(context, want_context, rtol=1e-6, atol=1e-6)

    def test_padding_is_excluded_and_all_invalid_neighbours_are_finite_zero(self):
        layer = self.api().LocalFrequencyAttention(dim=4, heads=2, window_size=7, chunk_size=3)
        q, k = torch.zeros(2, 4, 2, 2), torch.zeros(2, 4, 2, 2)
        v = torch.tensor([1., 2., 3., 4.]).reshape(1, 1, 2, 2).expand(2, 4, 2, 2).clone()
        mask = torch.ones(2, 1, 2, 2, dtype=torch.bool); mask[1] = False
        retrieved, context = layer(q, k, v, mask)
        torch.testing.assert_close(retrieved[0], torch.full_like(retrieved[0], 2.5), rtol=0, atol=0)
        self.assertTrue(torch.isfinite(retrieved).all())
        self.assertEqual(torch.count_nonzero(retrieved[1]).item(), 0)
        self.assertEqual(torch.count_nonzero(context).item(), 0)

    def test_zero_signed_donor_band_cannot_generate_a_bias_message(self):
        module = self.module()
        z = torch.randn(2, 4, 3, 5)
        expert = module.rgb_direction.experts[2]
        output, context = expert(z, z, torch.zeros_like(z), torch.ones(2, 1, 3, 5, dtype=torch.bool))
        self.assertEqual(torch.count_nonzero(output).item(), 0)
        self.assertTrue(torch.isfinite(context).all())

    def test_all_zero_override_is_identity_in_both_directions(self):
        module = self.module()
        r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        cache = module.build_cache(r, t)
        out_r, out_t = module.mix(cache, torch.zeros_like(cache['w']))
        torch.testing.assert_close(out_r, r, rtol=0, atol=0)
        torch.testing.assert_close(out_t, t, rtol=0, atol=0)

    def test_initial_gates_are_adaptive_independent_and_uncertainty_consistent(self):
        module = self.module()
        _, _, aux = module(torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5))
        self.assertEqual(tuple(aux['w'].shape), (2, 2, 4, 3, 5))
        self.assertGreater(aux['w'].flatten(3).std(-1).min().item(), 0)
        self.assertTrue(((aux['w'] >= 0) & (aux['w'] < 1)).all())
        torch.testing.assert_close(aux['w'], aux['p'] - aux['u']/2, rtol=1e-6, atol=1e-6)
        self.assertLess(abs(aux['w'].mean().item() - .25), .05)
        # Independent gates need not sum to one; a softmax would fail here.
        self.assertGreater((aux['w'].sum(2)-1).abs().max().item(), 1e-4)

    def test_detection_gradients_reach_producers_but_not_evidence_evaluators(self):
        module = self.module()
        r = torch.randn(2, 8, 3, 5, requires_grad=True)
        t = torch.randn(2, 8, 3, 5, requires_grad=True)
        out_r, out_t, _ = module(r, t)
        (out_r.square().mean() + out_t.square().mean()).backward()
        for name, p in module.named_parameters():
            if '.evaluator.' in name:
                self.assertIsNone(p.grad, name)
            else:
                self.assertIsNotNone(p.grad, name)
                self.assertTrue(torch.isfinite(p.grad).all(), name)
        self.assertGreater(r.grad.abs().sum().item(), 0)
        self.assertGreater(t.grad.abs().sum().item(), 0)

    def test_utility_gradients_reach_evaluators_only(self):
        module = self.module()
        r = torch.randn(2, 8, 3, 5, requires_grad=True)
        t = torch.randn(2, 8, 3, 5, requires_grad=True)
        _, _, aux = module(r, t)
        (aux['a'].mean() + aux['b'].mean()).backward()
        for name, p in module.named_parameters():
            if '.evaluator.' in name:
                self.assertIsNotNone(p.grad, name)
                self.assertGreater(p.grad.abs().sum().item(), 0, name)
            else:
                self.assertIsNone(p.grad, name)
        self.assertIsNone(r.grad); self.assertIsNone(t.grad)

    def test_thermal_output_uses_original_rgb_even_if_rgb_gates_change(self):
        module = self.module(); r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        cache = module.build_cache(r, t); gates = cache['w'].detach().clone()
        _, expected_t = module.mix(cache, gates)
        gates[:, 0] = 0
        _, actual_t = module.mix(cache, gates)
        torch.testing.assert_close(actual_t, expected_t, rtol=0, atol=0)

    def test_invalid_query_cells_remain_original_and_override_rejects_nan(self):
        module = self.module(); r, t = torch.randn(2, 8, 3, 5), torch.randn(2, 8, 3, 5)
        mask = torch.ones(2, 1, 3, 5, dtype=torch.bool); mask[..., -1] = False
        cache = module.build_cache(r, t, (mask, mask))
        out_r, out_t = module.mix(cache)
        torch.testing.assert_close(out_r[..., -1], r[..., -1], rtol=0, atol=0)
        torch.testing.assert_close(out_t[..., -1], t[..., -1], rtol=0, atol=0)
        bad = cache['w'].detach().clone(); bad[0, 0, 0, 0, 0] = float('nan')
        with self.assertRaises(ValueError): module.mix(cache, bad)


if __name__ == '__main__':
    unittest.main()
