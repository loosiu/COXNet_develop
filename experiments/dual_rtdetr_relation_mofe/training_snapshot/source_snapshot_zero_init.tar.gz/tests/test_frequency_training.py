import copy
import importlib
import json
from pathlib import Path
import tempfile
import unittest

import torch
from torch import nn

from dyfclt.frequency_utility import FrequencyUtilityEnhancer
from dyfclt.training import ModelEMA, build_optimizer


class SmallStudent(nn.Module):
    def __init__(self, frequency=True):
        super().__init__()
        self.common = nn.Linear(3, 2)
        self.encoder = nn.Module()
        if frequency:
            self.encoder.frequency_module = FrequencyUtilityEnhancer(8, 4, 2, evaluator_hidden=8)


class FrequencyTrainingTests(unittest.TestCase):
    def api(self):
        try: return importlib.import_module('dyfclt.frequency_training')
        except ModuleNotFoundError: self.fail('Frequency training helpers are not implemented')

    @staticmethod
    def checkpoint(path, extra=False):
        source = SmallStudent(False)
        raw = {k: torch.ones_like(v) for k, v in source.state_dict().items()}
        ema = {k: torch.full_like(v, 3.) for k, v in source.state_dict().items()}
        if extra: ema['encoder.bad.weight'] = torch.zeros(1)
        torch.save(dict(model=raw, ema=dict(module=ema), config=dict(model=dict(
            architecture='dual_rtdetr', use_dfca=False, use_sse=False)),
            epoch=19, global_step=49000, best_ap=.598, partial_epoch=False,
            category_ids=[0, 1]), path)

    def test_a_initialization_selects_ema_and_only_new_module_can_be_missing(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'a.pth'; self.checkpoint(path)
            student = SmallStudent()
            before = student.encoder.frequency_module.output_rgb.weight.detach().clone()
            info = api.initialize_from_a(student, path, weights='ema')
            torch.testing.assert_close(student.common.weight, torch.full_like(student.common.weight, 3.), rtol=0, atol=0)
            torch.testing.assert_close(student.common.bias, torch.full_like(student.common.bias, 3.), rtol=0, atol=0)
            torch.testing.assert_close(student.encoder.frequency_module.output_rgb.weight, before, rtol=0, atol=0)
            self.assertEqual(info['source_completed_epoch'], 20)
            self.assertEqual(info['selected_weights'], 'ema')
            self.assertTrue(info['shared_states_exact'])

    def test_foreign_extra_keys_and_missing_common_weights_are_rejected(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'a.pth'; self.checkpoint(path, extra=True)
            with self.assertRaises(ValueError): api.initialize_from_a(SmallStudent(), path)
            self.checkpoint(path)
            saved = torch.load(path, weights_only=False); saved['ema']['module'].pop('common.bias'); torch.save(saved, path)
            with self.assertRaises(ValueError): api.initialize_from_a(SmallStudent(), path)

    def test_b_or_partial_checkpoint_cannot_masquerade_as_a(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'a.pth'; self.checkpoint(path)
            saved = torch.load(path, weights_only=False); saved['partial_epoch'] = True; torch.save(saved, path)
            with self.assertRaises(ValueError): api.initialize_from_a(SmallStudent(), path)
            saved['partial_epoch'] = False; saved['config']['model']['fixed_experts'] = {}; torch.save(saved, path)
            with self.assertRaises(ValueError): api.initialize_from_a(SmallStudent(), path)

    def test_budget_matched_control_keeps_initialization_and_training_recipe(self):
        api = self.api()
        root = Path(__file__).resolve().parents[1]
        from dyfclt.runtime import load_config
        control = load_config(root/'configs/rgbtdroneperson_A_continuation.yaml')
        variant = load_config(root/'configs/rgbtdroneperson_frequency_utility.yaml')
        self.assertTrue(api.validate_paired_recipes(control, variant))
        wrong = copy.deepcopy(control); wrong['train']['batch_size'] = 8
        with self.assertRaises(ValueError): api.validate_paired_recipes(wrong, variant)
        wrong = copy.deepcopy(control); wrong['initialization']['weights'] = 'model'
        with self.assertRaises(ValueError): api.validate_paired_recipes(wrong, variant)

    def test_kl_ramp_is_zero_then_half_then_full_over_two_extra_epochs(self):
        api = self.api()
        self.assertEqual(api.kl_coefficient(0), 0)
        self.assertEqual(api.kl_coefficient(1), .005)
        self.assertEqual(api.kl_coefficient(2), .01)
        self.assertEqual(api.kl_coefficient(3), .01)

    def test_evaluation_ema_copies_declared_fixed_alpha_but_averages_parameters(self):
        student = SmallStudent(); ema = ModelEMA(student)
        original = student.common.weight.detach().clone()
        with torch.no_grad():
            ema.module.encoder.frequency_module.residual_scale.fill_(.7)
            student.common.weight.add_(1)
        ema.update(student)
        torch.testing.assert_close(ema.module.encoder.frequency_module.residual_scale,
                                  student.encoder.frequency_module.residual_scale, rtol=0, atol=0)
        self.assertTrue(((ema.module.common.weight-original) > 0).all())
        self.assertTrue(((ema.module.common.weight-original) < 1).all())

    def test_optimizer_contains_all_evaluators_and_producers_before_training(self):
        student = SmallStudent()
        optimizer = build_optimizer(student, dict(lr=.00025, weight_decay=.0001, optimizer_groups='rtdetr'))
        ids = {id(p) for group in optimizer.param_groups for p in group['params']}
        self.assertEqual(ids, {id(p) for p in student.parameters() if p.requires_grad})

    def test_resume_cannot_overwrite_an_unrelated_nonempty_run(self):
        api = self.api()
        config = {'train': {'output_dir': 'old', 'workers': 0}, 'seed': 0}
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); old = root/'old'; old.mkdir()
            (old/'config.json').write_text(json.dumps(config))
            (old/'best.pth').write_bytes(b'protected checkpoint')
            elsewhere = root/'elsewhere'; elsewhere.mkdir()
            checkpoint = elsewhere/'last.pth'
            with self.assertRaises(FileExistsError):
                api.validate_output_destination(old, checkpoint, config)
            with self.assertRaises(FileExistsError): api.validate_output_destination(old)
            self.assertEqual((old/'best.pth').read_bytes(), b'protected checkpoint')
            api.validate_output_destination(old, old/'last.pth', config)
            api.validate_output_destination(root/'new', checkpoint, config)
            wrong = copy.deepcopy(config); wrong['seed'] = 1
            with self.assertRaises(ValueError): api.validate_output_destination(old, old/'last.pth', wrong)

    def test_resume_keeps_original_launch_config_and_source_snapshot(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); output = root/'run'; output.mkdir()
            source = root/'source.py'; source.write_text('original = 1\n')
            manifest = {'source.py': 'test provenance'}
            config = {'seed': 0}; launch = {'explicit_resume': False}
            api.write_launch_provenance(output, root, manifest, config, launch)
            protected = {p.name: p.read_bytes() for p in output.iterdir()}
            source.write_text('changed = 2\n')
            api.write_launch_provenance(output, root, manifest, {'seed': 1}, {'explicit_resume': True})
            for name, contents in protected.items(): self.assertEqual((output/name).read_bytes(), contents)
            history = list(output.glob('resume_launch_*.json'))
            self.assertEqual(len(history), 1)
            self.assertTrue(json.loads(history[0].read_text())['explicit_resume'])
            self.assertEqual(len(list(output.glob('resume_source_snapshot_*.tar.gz'))), 1)

    def test_neutral_signal_report_cannot_authorize_long_training(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'neutral.json'
            path.write_text(json.dumps({'ready_for_long_training': False}))
            with self.assertRaisesRegex(ValueError, 'adequate signal'):
                api.verify_training_certificate(path, {}, folder)

    def test_real_probe_detection_utility_step_updates_both_emas_and_resume_extras(self):
        api = self.api()
        from dyfclt.model import DyFCLT
        from dyfclt.losses import build_criterion
        from dyfclt.utility_probe import UtilityTeacher, UtilityProbeSampler
        from dyfclt.runtime import save_checkpoint
        model = DyFCLT(2, hidden_dim=32, num_queries=8, num_decoder_layers=1,
                       num_denoising=4, architecture='dual_rtdetr', pretrained=False,
                       frequency_utility=dict(dim=8, heads=2, evaluator_hidden=8, chunk_size=8)).train()
        teacher, ema = UtilityTeacher(model), ModelEMA(model)
        sampler = UtilityProbeSampler(0)
        optimizer = build_optimizer(model, dict(lr=.00025, weight_decay=.0001, optimizer_groups='rtdetr'))
        scaler = torch.cuda.amp.GradScaler(enabled=False)
        targets = [dict(labels=torch.tensor([0]), boxes=torch.tensor([[.5, .5, .1, .1]])) for _ in range(2)]
        batch = (torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96), targets)
        utility = dict(enabled=True, loss_weight=.1, kl_max=.01, kl_ramp_epochs=2)
        result = api.training_step(model, teacher, ema, sampler, build_criterion(2, mask_weight=0),
                                   optimizer, scaler, batch, utility, 0., do_probe=True, check_noop=True)
        self.assertTrue(result['applied']); self.assertGreaterEqual(result['utility_loss'], 0)
        self.assertEqual(result['probe']['noop_delta'], [0., 0.])
        self.assertEqual((teacher.updates, ema.updates), (1, 1))
        evaluators = [p for n, p in model.named_parameters() if '.evaluator.' in n]
        if result['utility_active']:
            self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in evaluators))
        else:
            self.assertEqual(result['utility_loss'], 0.)
            self.assertTrue(all(p.grad is None for p in evaluators))
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'saved.pth'
            extra = dict(utility_teacher=teacher.state_dict(), probe_sampler=sampler.state_dict(), attempted_batches=1)
            save_checkpoint(path, model, optimizer, scaler, {'seed': 0}, 0, 1, .5, [0, 1], ema=ema, extra_state=extra)
            saved = torch.load(path, weights_only=False)
            restored = UtilityTeacher(model); restored.load_state_dict(saved['utility_teacher'])
            self.assertEqual(restored.updates, 1)
            for k, v in teacher.module.state_dict().items():
                torch.testing.assert_close(restored.module.state_dict()[k], v, rtol=0, atol=0)
            resumed_sampler = UtilityProbeSampler(99); resumed_sampler.load_state_dict(saved['probe_sampler'])
            torch.testing.assert_close(sampler.generator.get_state(), resumed_sampler.generator.get_state(), rtol=0, atol=0)


if __name__ == '__main__': unittest.main()
