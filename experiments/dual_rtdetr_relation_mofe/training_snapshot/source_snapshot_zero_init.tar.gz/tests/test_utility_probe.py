import importlib
import math
import unittest

import torch

from dyfclt.frequency_utility import FrequencyUtilityEnhancer
from dyfclt.losses import build_criterion
from dyfclt.vendor.rtdetr_decoder import RTDETRTransformer


class UtilityProbeTests(unittest.TestCase):
    def api(self):
        try: return importlib.import_module('dyfclt.utility_probe')
        except ModuleNotFoundError: self.fail('Utility supervision is not implemented')

    @staticmethod
    def fixture():
        outputs = dict(pred_logits=torch.tensor([[[2., -1.], [-.4, .5], [-1., -2.]],
                                                 [[-2., -1.], [0., -.3], [.2, -.7]]]),
                       pred_boxes=torch.tensor([[[.5, .5, .2, .2], [.8, .8, .1, .1], [.2, .2, .1, .1]],
                                                [[.3, .3, .1, .1], [.6, .6, .1, .1], [.7, .7, .2, .2]]]))
        targets = [dict(labels=torch.tensor([0]), boxes=torch.tensor([[.5, .5, .2, .2]])),
                   dict(labels=torch.empty(0, dtype=torch.long), boxes=torch.empty(0, 4))]
        return outputs, targets

    def test_frozen_per_image_reference_cost_matches_baseline_final_losses(self):
        api = self.api(); outputs, targets = self.fixture(); criterion = build_criterion(2, mask_weight=0)
        frozen = api.FrozenDetectionCost.from_reference(outputs, targets, criterion)
        costs = frozen.cost(outputs)
        for i in range(2):
            single = {k: v[i:i+1] for k, v in outputs.items()}
            want = sum(criterion(single, [targets[i]]).values())
            torch.testing.assert_close(costs[i], want, rtol=1e-6, atol=1e-6)
        changed = {k: v.clone() for k, v in outputs.items()}; changed['pred_logits'][1] += 2
        after = frozen.cost(changed)
        self.assertEqual(costs[0].item(), after[0].item())
        self.assertNotEqual(costs[1].item(), after[1].item())

    def test_matching_vfl_quality_and_background_weights_do_not_change_on_replay(self):
        api = self.api(); outputs, targets = self.fixture()
        frozen = api.FrozenDetectionCost.from_reference(outputs, targets, build_criterion(2, mask_weight=0))
        quality = frozen.quality_targets.clone(); weights = frozen.classification_weights.clone()
        changed = dict(pred_logits=-outputs['pred_logits'], pred_boxes=outputs['pred_boxes'].flip(1))
        result = frozen.cost(changed)
        self.assertTrue(torch.isfinite(result).all())
        torch.testing.assert_close(frozen.quality_targets, quality, rtol=0, atol=0)
        torch.testing.assert_close(frozen.classification_weights, weights, rtol=0, atol=0)

    def test_beta_fit_variance_and_adjusted_evidence_kl_match_hand_calculation(self):
        api = self.api(); a = torch.tensor([2., 2.], requires_grad=True); b = a.detach().clone().requires_grad_()
        labels = torch.tensor([0., 1.])
        loss = api.beta_utility_loss(a, b, labels, kl_weight=.01)
        self.assertAlmostEqual(loss.item(), .3 + .01*(math.log(2)-.5), places=6)
        loss.backward(); self.assertTrue(torch.isfinite(a.grad).all()); self.assertTrue(torch.isfinite(b.grad).all())

    def test_coalition_changes_one_cell_and_one_selected_gate_between_on_off(self):
        api = self.api(); reference = torch.full((2, 2, 4, 3, 5), .25)
        selections = torch.tensor([[0, 0, 2, 1, 3], [1, 1, 0, 2, 4]])
        generator = torch.Generator().manual_seed(7)
        on, off, coalitions = api.coalition_gates(reference, selections, generator)
        self.assertEqual(torch.count_nonzero(on-off).item(), 2)
        self.assertEqual((on-off)[0, 0, 2, 1, 3].item(), 1)
        self.assertEqual((on-off)[1, 1, 0, 2, 4].item(), 1)
        outside = torch.ones_like(reference, dtype=torch.bool)
        outside[0, 0, :, 1, 3] = False; outside[1, 1, :, 2, 4] = False
        torch.testing.assert_close(on[outside], reference[outside], rtol=0, atol=0)
        torch.testing.assert_close(off[outside], reference[outside], rtol=0, atol=0)
        self.assertEqual(tuple(coalitions.shape), (2, 4))

    def test_sampled_student_utility_has_no_producer_or_input_gradient(self):
        api = self.api(); module = FrequencyUtilityEnhancer(8, 4, 2, evaluator_hidden=8, chunk_size=4)
        rgb, thermal = [torch.randn(2, 8, 3, 5, requires_grad=True) for _ in range(2)]
        _, _, aux = module(rgb, thermal)
        selections = torch.tensor([[0, 0, 1, 1, 2], [1, 1, 3, 2, 4]])
        loss = api.sampled_utility_loss(aux, dict(selections=selections, labels=torch.tensor([1., 0.]),
                                                neutral=torch.tensor([False, False])), .005)
        loss.backward()
        self.assertIsNone(rgb.grad); self.assertIsNone(thermal.grad)
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0
                            for n, p in module.named_parameters() if '.evaluator.' in n))
        for name, p in module.named_parameters():
            if '.evaluator.' not in name: self.assertIsNone(p.grad, name)

    def test_utility_teacher_skipped_steps_leave_state_and_update_count_unchanged(self):
        api = self.api(); model = FrequencyUtilityEnhancer(8, 4, 2, evaluator_hidden=8)
        teacher = api.UtilityTeacher(model, decay=.99)
        saved = {k: v.clone() for k, v in teacher.module.state_dict().items()}
        with torch.no_grad(): model.project_rgb.weight.add_(1)
        teacher.update(model, applied=False)
        self.assertEqual(teacher.updates, 0)
        for k, v in teacher.module.state_dict().items(): torch.testing.assert_close(v, saved[k], rtol=0, atol=0)
        teacher.update(model)
        torch.testing.assert_close(teacher.module.project_rgb.weight, saved['project_rgb.weight']+.01, rtol=1e-5, atol=1e-6)
        torch.testing.assert_close(teacher.module.residual_scale, model.residual_scale, rtol=0, atol=0)
        self.assertEqual(teacher.updates, 1)
        self.assertFalse(teacher.module.training)
        self.assertTrue(all(not p.requires_grad for p in teacher.module.parameters()))

    def test_background_sites_use_unmatched_anchor_outside_gt_and_sampling_rng_restores(self):
        api = self.api(); outputs, targets = self.fixture()
        # Image0 query1 is unmatched and high-scoring, but its anchor is inside GT.
        outputs['pred_logits'][0, 1, 1] = 4
        outputs['query_metadata'] = dict(anchor_centers=torch.tensor([[[.5, .5], [.5, .5], [.1, .1]],
                                                                     [[.2, .2], [.4, .4], [.9, .9]]]))
        masks = torch.ones(2, 2, 5, 5, dtype=torch.bool)
        cache = dict(valid_masks=masks)
        sampler = api.UtilityProbeSampler(seed=4, gt_probability=0)
        state = sampler.state_dict()
        selections, kinds = sampler.sample(outputs, targets, [(torch.tensor([0]), torch.tensor([0])),
                                                              (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long))], cache)
        self.assertEqual(selections[0, -2:].tolist(), [0, 0])
        self.assertEqual(kinds, ['unmatched_background', 'unmatched_background'])
        sampler.load_state_dict(state)
        again, _ = sampler.sample(outputs, targets, [(torch.tensor([0]), torch.tensor([0])),
                                                     (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long))], cache)
        torch.testing.assert_close(again, selections, rtol=0, atol=0)

    def test_empty_gt_uses_background_and_fully_invalid_image_is_rejected(self):
        api = self.api(); outputs, targets = self.fixture()
        outputs['query_metadata'] = dict(anchor_centers=torch.full((2, 3, 2), .5))
        sampler = api.UtilityProbeSampler(seed=0, gt_probability=1)
        indices = [(torch.tensor([0]), torch.tensor([0])), (torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long))]
        selections, kinds = sampler.sample(outputs, targets, indices, dict(valid_masks=torch.ones(2, 2, 5, 5, dtype=torch.bool)))
        self.assertEqual(kinds[0], 'gt_center'); self.assertEqual(kinds[1], 'unmatched_background')
        with self.assertRaises(ValueError):
            sampler.sample(outputs, targets, indices, dict(valid_masks=torch.zeros(2, 2, 5, 5, dtype=torch.bool)))

    def test_binary_utility_label_uses_per_image_delta_and_positive_tolerance(self):
        api = self.api()
        labels, epsilon = api.utility_targets(torch.tensor([3., 20., 1.]),
                                              torch.tensor([2., 10., 2.]),
                                              torch.tensor([2.001, 9., 2.00001]))
        torch.testing.assert_close(labels, torch.tensor([1., 0., 0.]), rtol=0, atol=0)
        torch.testing.assert_close(epsilon, torch.tensor([.0003, .002, .0001]), rtol=1e-6, atol=0)


if __name__ == '__main__': unittest.main()
