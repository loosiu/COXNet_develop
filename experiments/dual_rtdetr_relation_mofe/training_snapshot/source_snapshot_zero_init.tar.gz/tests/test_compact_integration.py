"""Contracts for supplement-constrained modules on the unchanged dual baseline."""
import unittest

import torch
from torch import nn

from dyfclt.model import DyFCLT, DualRTDETREncoder


def parameters(module):
    return sum(p.numel() for p in module.parameters())


class CompactIntegrationTests(unittest.TestCase):
    def test_module_additions_fit_supplement_budget_without_removing_baseline_weights(self):
        torch.manual_seed(31)
        baseline = DualRTDETREncoder(hidden_dim=256)
        baseline_state = baseline.state_dict()
        for dfca, sse, addition in ((True, False, 287500), (False, True, 239656),
                                    (True, True, 527156)):
            with self.subTest(dfca=dfca, sse=sse):
                torch.manual_seed(31)
                variant = DualRTDETREncoder(hidden_dim=256, use_dfca=dfca, use_sse=sse,
                                           dfca_hidden_dim=48, sse_reduction=32)
                self.assertEqual(parameters(variant) - parameters(baseline), addition)
                state = variant.state_dict()
                for name, expected in baseline_state.items():
                    torch.testing.assert_close(state[name], expected, rtol=0, atol=0, msg=name)
                registered = [p for p in variant.state_dict(keep_vars=True).values()
                              if isinstance(p, nn.Parameter)]
                self.assertEqual(len(registered), len({id(p) for p in registered}))
                del variant

    def test_compact_model_routes_both_modalities_and_scales_into_shared_decoder(self):
        kwargs = dict(num_classes=3, hidden_dim=32, num_queries=8,
                      num_decoder_layers=1, num_denoising=0, pretrained=False,
                      architecture='dual_rtdetr')
        torch.manual_seed(41)
        baseline = DyFCLT(**kwargs)
        torch.manual_seed(41)
        model = DyFCLT(**kwargs, use_dfca=True, use_sse=True,
                       dfca_hidden_dim=8, sse_reduction=8).train()
        state = model.state_dict()
        for name, expected in baseline.state_dict().items():
            torch.testing.assert_close(state[name], expected, rtol=0, atol=0, msg=name)
        del baseline
        for module in list(model.encoder.rgb_dfca) + list(model.encoder.thermal_dfca):
            self.assertEqual(tuple(module.query[0].weight.shape), (8,32,1,1))
            self.assertEqual(tuple(module.projection.weight.shape), (32,8,1,1))
        outputs = model(torch.randn(2,3,64,96), torch.randn(2,3,64,96))
        self.assertEqual(tuple(outputs['pred_logits'].shape), (2,8,3))
        self.assertEqual(tuple(outputs['pred_boxes'].shape), (2,8,4))
        self.assertEqual(len(outputs['mask_logits']), 4)
        loss = outputs['pred_logits'].square().mean() + outputs['pred_boxes'].square().mean()
        loss = loss + sum(mask.square().mean() for mask in outputs['mask_logits'])
        loss.backward()
        for name, parameter in model.encoder.named_parameters():
            if any(key in name for key in ('rgb_dfca.', 'thermal_dfca.', 'rgb_sse.', 'thermal_sse.')):
                self.assertIsNotNone(parameter.grad, name)
                self.assertTrue(torch.isfinite(parameter.grad).all(), name)
        self.assertGreater(model.encoder.rgb_dfca[0].query[0].weight.grad.abs().sum().item(), 0)
        self.assertGreater(model.encoder.thermal_dfca[1].query[0].weight.grad.abs().sum().item(), 0)

    def test_legacy_model_rejects_compact_width_instead_of_ignoring_it(self):
        with self.assertRaisesRegex(ValueError, 'dual_rtdetr'):
            DyFCLT(num_classes=3, dfca_hidden_dim=48)


if __name__ == '__main__':
    unittest.main()
