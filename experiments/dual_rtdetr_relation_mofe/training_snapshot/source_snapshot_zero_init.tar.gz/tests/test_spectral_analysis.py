"""Offline spectral measurements on original paired pixels, independent of models."""

import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from PIL import Image


class SpectralAnalysisTests(unittest.TestCase):
    def setUp(self):
        try:
            self.analysis = importlib.import_module('dyfclt.spectral_analysis')
        except ModuleNotFoundError as error:
            if error.name != 'dyfclt.spectral_analysis':
                raise
            self.fail('Offline spectral analysis is not implemented')

    @staticmethod
    def sinusoid(frequency, amplitude=1., size=64):
        row = amplitude * np.cos(2 * np.pi * frequency * np.arange(size))
        return np.tile(row, (size, 1))

    def test_dc_only_patch_is_skipped_per_channel(self):
        patch = np.empty((9, 13, 3))
        patch[:] = [40., 100., 250.]
        with self.assertRaises(self.analysis.SkippedPatch) as context:
            self.analysis.analyze_patch(patch)
        self.assertEqual(context.exception.reason, 'zero_energy')

    def test_constant_fractional_pixels_do_not_create_roundoff_energy(self):
        with self.assertRaises(self.analysis.SkippedPatch) as context:
            self.analysis.analyze_patch(np.full((9, 13, 3), .1))
        self.assertEqual(context.exception.reason, 'zero_energy')

    def test_known_sinusoids_fall_in_each_octave_band(self):
        for band, frequency in enumerate((1 / 16, 3 / 16, 3 / 8)):
            with self.subTest(frequency=frequency):
                result = self.analysis.analyze_patch(self.sinusoid(frequency))
                self.assertGreater(result['ratios'][band], .999)
                self.assertAlmostEqual(sum(result['ratios']), 1., places=12)

    def test_hann_compensation_preserves_total_power(self):
        patch = np.tile([1., -1., 1., -1.], (4, 1))
        result = self.analysis.analyze_patch(patch)
        self.assertAlmostEqual(sum(result['band_energies']) + result['outside_disk_energy'], 1., places=12)
        self.assertAlmostEqual(result['window_mean_square'], .0791015625, places=12)

    def test_channel_psd_average_does_not_cancel_opposite_channels(self):
        wave = self.sinusoid(3 / 16)
        result = self.analysis.analyze_patch(np.stack((wave, -wave), axis=-1))
        self.assertGreater(result['ratios'][1], .999)

    def test_padding_odd_rectangle_reflects_edges_and_preserves_pixels(self):
        patch = np.arange(15).reshape(3, 5)
        padded = self.analysis.reflection_pad_square_power2(patch)
        expected = np.array([0, 1, 0, 1, 2, 1, 2, 1])[:, None] * 5
        expected = expected + np.array([1, 0, 1, 2, 3, 4, 3, 2])[None, :]
        np.testing.assert_array_equal(padded, expected)
        np.testing.assert_array_equal(padded[2:5, 1:6], patch)

    def test_too_small_or_nonfinite_patches_report_skip_reasons(self):
        for patch, reason in ((np.ones((2, 2)), 'too_small_for_hann'),
                              (np.ones((1, 7)), 'too_small_for_reflection'),
                              (np.full((4, 4), np.nan), 'nonfinite_pixels')):
            with self.subTest(reason=reason):
                with self.assertRaises(self.analysis.SkippedPatch) as context:
                    self.analysis.analyze_patch(patch)
                self.assertEqual(context.exception.reason, reason)

    def test_aggregation_weights_instances_equally_despite_energy(self):
        accumulator = self.analysis.EnergyAccumulator()
        accumulator.add(self.analysis.analyze_patch(self.sinusoid(1 / 16, amplitude=1.)))
        accumulator.add(self.analysis.analyze_patch(self.sinusoid(3 / 8, amplitude=100.)))
        accumulator.skip('zero_energy')
        result = accumulator.summary()
        np.testing.assert_allclose(result['mean_ratios'], [.5, 0., .5], atol=1e-5)
        self.assertEqual(result['attempted'], 3)
        self.assertEqual(result['valid'], 2)
        self.assertEqual(result['skipped_by_reason'], {'zero_energy': 1})

    def test_user_area_bins_are_nonoverlapping_and_upper_exclusive(self):
        bins = self.analysis.validate_scale_bins({'below': [0, 16], 'above': [16, None]})
        self.assertEqual(self.analysis.scale_bin_for_area(15.9, bins), 'below')
        self.assertEqual(self.analysis.scale_bin_for_area(16, bins), 'above')
        for invalid in ({'a': [0, 16], 'b': [15, 20]}, {'a': [-1, 5]},
                        {'a': [5, 5]}, {'a': [0, float('nan')]}, {'a': [0, True]}):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                self.analysis.validate_scale_bins(invalid)

    def make_dataset_fixture(self, root):
        for modality, frequency in (('visible', 1 / 16), ('thermal', 3 / 8)):
            (root / modality).mkdir()
            patch = np.round(128 + self.sinusoid(frequency, amplitude=80, size=32)).astype(np.uint8)
            Image.fromarray(patch).save(root / modality / 'image.png')
        annotations = {
            'images': [{'id': 1, 'file_name': 'thermal/image.png', 'width': 5, 'height': 5}],
            'categories': [{'id': 1, 'name': 'person'}, {'id': 2, 'name': 'rider'},
                           {'id': 3, 'name': 'crowd'}, {'id': 4, 'name': 'uncertain'}],
            'annotations': [
                {'id': 1, 'image_id': 1, 'category_id': 1, 'bbox': [0, 0, 32, 32]},
                {'id': 2, 'image_id': 1, 'category_id': 3, 'bbox': [4, 4, 8, 8]},
                {'id': 3, 'image_id': 1, 'category_id': 2, 'bbox': [0, 0, -1, 8]},
                {'id': 4, 'image_id': 1, 'category_id': 1, 'bbox': [0, 0, 8, 8], 'ignore': 1},
                {'id': 5, 'image_id': 1, 'category_id': 1, 'bbox': [0, 0, 8, 8], 'iscrowd': 1},
                {'id': 6, 'image_id': 1, 'category_id': 4, 'bbox': [0, 0, 8, 8]},
            ],
        }
        ann_file = root / 'annotations.json'
        ann_file.write_text(json.dumps(annotations))
        config = {'data': {'image_size': [4, 4], 'val': {
            'ann_file': str(ann_file), 'image_root': str(root),
            'categories': ['person', 'rider', 'crowd']}}}
        return config

    def test_original_pixels_stale_metadata_filters_and_invalid_boxes(self):
        from dyfclt.runtime import make_dataset
        with tempfile.TemporaryDirectory() as folder:
            config = self.make_dataset_fixture(Path(folder))
            dataset = make_dataset(config, 'val')
            report = self.analysis.analyze_dataset(dataset, scale_bins={'small': [0, 100], 'big': [100, None]})
        self.assertEqual(report['counts']['selected_annotations_available'], 3)
        self.assertEqual(report['counts']['attempted_instances'], 3)
        self.assertEqual(report['counts']['stale_metadata_images'], 1)
        self.assertEqual(report['modalities']['visible']['all']['valid'], 2)
        self.assertEqual(report['modalities']['visible']['all']['skipped_by_reason'], {'invalid_bbox': 1})
        self.assertGreater(report['modalities']['visible']['by_scale']['big']['mean_ratios'][0], .99)
        self.assertGreater(report['modalities']['thermal']['by_scale']['big']['mean_ratios'][2], .99)
        self.assertEqual(report['modalities']['visible']['by_scale']['small']['valid'], 1)

    def test_cli_bounded_run_writes_json_and_plot_without_inventing_scale_bins(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config = self.make_dataset_fixture(root)
            config_file = root / 'config.json'
            config_file.write_text(json.dumps(config))
            output = root / 'output'
            environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='2')
            command = [sys.executable, 'tools/analyze_frequency.py', '--config', str(config_file),
                       '--max-instances', '1', '--output-dir', str(output)]
            result = subprocess.run(command, cwd=Path(__file__).resolve().parents[1], env=environment,
                                    capture_output=True, text=True, timeout=60)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            report = json.loads((output / 'frequency_analysis.json').read_text())
            self.assertEqual(report['counts']['attempted_instances'], 1)
            self.assertEqual(report['counts']['selected_annotations_available'], 3)
            self.assertFalse(report['complete_dataset'])
            self.assertEqual(report['scale_bins'], {})
            self.assertEqual(report['modalities']['visible']['by_scale'], {})
            self.assertGreater((output / 'frequency_bands.png').stat().st_size, 1000)


if __name__ == '__main__':
    unittest.main()
