import unittest

import torch

from dyfclt.losses import build_criterion, rasterize_boxes
from dyfclt.model import DyFCLT, DyFCLTEncoder
from dyfclt.vendor.hybrid_encoder import HybridEncoder


class DetectorIntegrationTests(unittest.TestCase):
    def test_tiny_box_survives_rasterization(self):
        boxes = torch.tensor([[0.51, 0.51, 0.002, 0.002]])
        mask = rasterize_boxes(boxes, (8, 8))
        self.assertEqual(mask.shape, (8, 8))
        self.assertEqual(int(mask.sum()), 1)

    def test_empty_targets_supervise_background_mask(self):
        criterion = build_criterion(1, mask_weight=4)
        logits = torch.zeros(2, 1, 8, 8, requires_grad=True)
        outputs = {
            'pred_logits': torch.zeros(2, 4, 1, requires_grad=True),
            'pred_boxes': torch.full((2, 4, 4), 0.5, requires_grad=True),
            'mask_logits': [logits],
        }
        targets = [
            {'labels': torch.empty(0, dtype=torch.long), 'boxes': torch.empty(0, 4)}
            for _ in range(2)
        ]
        losses = criterion(outputs, targets)
        self.assertIn('loss_mask', losses)
        self.assertTrue(all(torch.isfinite(v).all() for v in losses.values()))
        sum(losses.values()).backward()
        self.assertIsNotNone(logits.grad)
        self.assertGreater(float(logits.grad.abs().sum()), 0)

    def test_perfect_mask_has_finite_fractional_power_gradient(self):
        criterion = build_criterion(1, gamma=0.75)
        logits = torch.full((1, 1, 4, 4), float('-inf'), requires_grad=True)
        outputs = {
            'pred_logits': torch.zeros(1, 2, 1, requires_grad=True),
            'pred_boxes': torch.full((1, 2, 4), 0.5, requires_grad=True),
            'mask_logits': [logits],
        }
        targets = [{'labels': torch.empty(0, dtype=torch.long),
                    'boxes': torch.empty(0, 4)}]
        loss = criterion(outputs, targets)['loss_mask']
        self.assertTrue(torch.isfinite(loss))
        loss.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())

    def test_model_rejects_invalid_image_geometry(self):
        model = DyFCLT(1, hidden_dim=32, num_queries=8, num_decoder_layers=1,
                       num_denoising=0, pretrained=False)
        with self.assertRaisesRegex(ValueError, 'divisible by 32'):
            model(torch.zeros(1, 3, 64, 65), torch.zeros(1, 3, 64, 65))
        with self.assertRaisesRegex(ValueError, '3 channels'):
            model(torch.zeros(1, 1, 64, 64), torch.zeros(1, 1, 64, 64))

    def test_rectangular_position_embedding_matches_row_major_tokens(self):
        height, width, channels = 3, 5, 32
        raw = HybridEncoder.build_2d_sincos_position_embedding(width, height, channels)
        expected = raw.reshape(1, width, height, channels).transpose(1, 2).reshape(1, height * width, channels)
        actual = DyFCLTEncoder.position_embedding(width, height, channels)
        self.assertTrue(torch.equal(actual, expected))
        self.assertFalse(torch.equal(actual, raw))

    def test_model_decoder_and_denoising_backward(self):
        torch.manual_seed(1)
        model = DyFCLT(
            num_classes=1, hidden_dim=32, num_queries=8,
            num_decoder_layers=2, num_denoising=4, pretrained=False,
        )
        model.train()
        rgb = torch.randn(2, 3, 64, 64)
        thermal = torch.randn(2, 3, 64, 64)
        targets = [
            {'labels': torch.tensor([0]), 'boxes': torch.tensor([[0.51, 0.51, 0.08, 0.08]])},
            {'labels': torch.empty(0, dtype=torch.long), 'boxes': torch.empty(0, 4)},
        ]
        outputs = model(rgb, thermal, targets)
        self.assertEqual(outputs['pred_logits'].shape, (2, 8, 1))
        self.assertEqual(outputs['pred_boxes'].shape, (2, 8, 4))
        self.assertEqual(len(outputs['mask_logits']), 4)
        self.assertIn('dn_aux_outputs', outputs)
        losses = build_criterion(1)(outputs, targets)
        self.assertTrue(all(torch.isfinite(v).all() for v in losses.values()))
        sum(losses.values()).backward()
        for group in (model.rgb_backbone, model.thermal_backbone,
                      model.encoder.rgb_dfca, model.encoder.thermal_dfca,
                      model.encoder.rgb_sse, model.encoder.thermal_sse,
                      model.decoder):
            self.assertTrue(any(p.grad is not None and torch.isfinite(p.grad).all()
                                for p in group.parameters()), type(group).__name__)


if __name__ == '__main__':
    unittest.main()
