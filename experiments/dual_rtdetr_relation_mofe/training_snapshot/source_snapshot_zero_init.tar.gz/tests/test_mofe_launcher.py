import os,subprocess,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class MoFELauncherTests(unittest.TestCase):
 def test_production_launch_rejects_recipe_overrides_before_querying_gpu(self):
  with tempfile.TemporaryDirectory() as directory:
   fake=Path(directory)/'nvidia-smi';fake.write_text('#!/bin/sh\necho GPU_GUARD_WAS_REACHED >&2\nexit 47\n');fake.chmod(0o755)
   env=dict(os.environ,PATH=directory+os.pathsep+os.environ['PATH'])
   result=subprocess.run(['bash',str(ROOT/'tools/train_mofe_gpu1.sh'),'--workers','4'],env=env,text=True,capture_output=True)
   self.assertEqual(result.returncode,2,result.stderr)
   self.assertNotIn('GPU_GUARD_WAS_REACHED',result.stderr)
