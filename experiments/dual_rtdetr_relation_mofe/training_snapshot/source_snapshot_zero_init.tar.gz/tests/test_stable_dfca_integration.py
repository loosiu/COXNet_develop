"""Contracts for grouped stable DFCA on the unchanged dual RT-DETR baseline."""

import unittest

import torch

from dyfclt.model import DyFCLT, DualRTDETREncoder


def _parameters(module):
    return sum(parameter.numel() for parameter in module.parameters())


class StableDFCAIntegrationTests(unittest.TestCase):
    def test_four_d64_group4_blocks_add_309260_parameters_preserving_baseline(self):
        # Dense gates, lost baseline layers, and shifted common RNG fail this.
        torch.manual_seed(31)
        baseline = DualRTDETREncoder(hidden_dim=256)
        torch.manual_seed(31)
        stable = DualRTDETREncoder(hidden_dim=256, use_dfca=True,
                                  dfca_hidden_dim=64, dfca_gate_groups=4,
                                  dfca_correlation_normalization='rms',
                                  dfca_correlation_eps=1e-4)
        self.assertEqual(_parameters(stable) - _parameters(baseline), 309260)
        for name, expected in baseline.state_dict().items():
            torch.testing.assert_close(stable.state_dict()[name], expected,
                                       atol=0, rtol=0, msg=name)
        blocks = list(stable.rgb_dfca) + list(stable.thermal_dfca)
        self.assertEqual(len(blocks), 4)
        for block in blocks:
            self.assertEqual(_parameters(block), 77315)
            self.assertEqual(tuple(block.spatial_modulator.weight.shape), (64, 16, 3, 3))

    def test_model_config_routes_four_stable_blocks_and_backpropagates(self):
        torch.manual_seed(41)
        config = dict(num_classes=3, hidden_dim=32, num_queries=8,
                      num_decoder_layers=1, num_denoising=0, pretrained=False,
                      architecture='dual_rtdetr', use_dfca=True, use_sse=False,
                      dfca_hidden_dim=8, dfca_gate_groups=4,
                      dfca_correlation_normalization='rms', dfca_correlation_eps=1e-4)
        model = DyFCLT(**config).train()
        blocks = list(model.encoder.rgb_dfca) + list(model.encoder.thermal_dfca)
        self.assertEqual(len(blocks), 4)
        for block in blocks:
            self.assertEqual(block.spatial_modulator.groups, 4)
            self.assertEqual(block.correlation_normalization, 'rms')
            self.assertEqual(block.correlation_eps, 1e-4)
        outputs = model(torch.randn(2, 3, 64, 96), torch.randn(2, 3, 64, 96))
        self.assertEqual(tuple(outputs['pred_logits'].shape), (2, 8, 3))
        self.assertEqual(tuple(outputs['pred_boxes'].shape), (2, 8, 4))
        self.assertEqual(outputs['mask_logits'], [])
        logits = outputs['pred_logits']
        weights = torch.linspace(-.7, 1.3, logits.numel()).reshape_as(logits)
        loss = logits.square().mean() + (logits * weights).mean()
        loss = loss + outputs['pred_boxes'].square().mean()
        loss.backward()
        for name, parameter in model.encoder.named_parameters():
            if 'rgb_dfca.' in name or 'thermal_dfca.' in name:
                self.assertIsNotNone(parameter.grad, name)
                self.assertTrue(torch.isfinite(parameter.grad).all(), name)
        for block in blocks:
            self.assertGreater(block.query[0].weight.grad.abs().sum().item(), 0.)
            self.assertGreater(block.spatial_modulator.weight.grad.abs().sum().item(), 0.)
            self.assertGreater(block.projection.weight.grad.abs().sum().item(), 0.)

    def test_new_nondefault_options_reject_legacy_and_disabled_dfca(self):
        # Reject silently ignored settings before backbone construction/loading.
        for options in ({'dfca_gate_groups': 4},
                        {'dfca_correlation_normalization': 'rms'},
                        {'dfca_correlation_eps': 1e-6}):
            with self.subTest(legacy=options):
                with self.assertRaisesRegex(ValueError, 'dual_rtdetr'):
                    DyFCLT(num_classes=3, **options)
            with self.subTest(disabled_model=options):
                with self.assertRaisesRegex(ValueError, 'DFCA|dfca'):
                    DyFCLT(num_classes=3, architecture='dual_rtdetr', use_dfca=False,
                           **options)
            with self.subTest(disabled_encoder=options):
                with self.assertRaisesRegex(ValueError, 'DFCA|dfca'):
                    DualRTDETREncoder(hidden_dim=32, use_dfca=False, **options)

    def test_old_sse_only_width_configuration_remains_loadable(self):
        # Existing SSE-only compact configs specify an inactive DFCA width.
        torch.manual_seed(53)
        old = DualRTDETREncoder(hidden_dim=32, use_dfca=False, use_sse=True,
                               dfca_hidden_dim=8, sse_reduction=8)
        torch.manual_seed(53)
        explicit = DualRTDETREncoder(hidden_dim=32, use_dfca=False, use_sse=True,
                                    dfca_hidden_dim=8, sse_reduction=8,
                                    dfca_gate_groups=1,
                                    dfca_correlation_normalization='none',
                                    dfca_correlation_eps=1e-4)
        explicit.load_state_dict(old.state_dict(), strict=True)
        for name, expected in old.state_dict().items():
            torch.testing.assert_close(explicit.state_dict()[name], expected,
                                       atol=0, rtol=0, msg=name)


if __name__ == '__main__':
    unittest.main()
