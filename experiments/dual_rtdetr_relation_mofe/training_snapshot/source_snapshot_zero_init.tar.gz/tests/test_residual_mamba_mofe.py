import unittest
import subprocess
from pathlib import Path
import torch
from dyfclt.residual_mofe import BidirectionalResidualMoFE
from dyfclt.residual_mamba_mofe import ResidualMambaMoFE


class ResidualMambaTests(unittest.TestCase):
    def test_production_launcher_rejects_recipe_overrides_before_gpu_access(self):
        root = Path(__file__).resolve().parents[1]
        result = subprocess.run(['bash', str(root/'tools/train_mamba_residual_gpu0.sh'),
                                 '--batch-size', '8'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)

    def make_pair(self):
        options = dict(channels=8, dim=4, expert_hidden=4, router_hidden=4)
        torch.manual_seed(0)
        base = BidirectionalResidualMoFE(**options)
        rng = torch.get_rng_state().clone()
        torch.manual_seed(0)
        new = ResidualMambaMoFE(**options, state_dim=2)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        return base, new

    def inputs(self):
        torch.manual_seed(7)
        return torch.randn(2, 8, 5, 7), torch.randn(2, 8, 5, 7)

    def test_all_B_parameters_and_initial_outputs_exact_with_padding(self):
        base, new = self.make_pair()
        for name, value in base.state_dict().items():
            self.assertTrue(torch.equal(value, new.state_dict()[name]), name)
        r, t = self.inputs()
        mask = torch.ones(2, 1, 5, 7, dtype=torch.bool)
        mask[:, :, -2:, -3:] = False
        for masks in [None, (mask, mask), (mask, ~mask)]:
            b, n = base(r, t, masks), new(r, t, masks)
            for k in [0, 1]: self.assertTrue(torch.equal(b[k], n[k]))
            self.assertTrue(torch.equal(b[2]['routing_weights'], n[2]['routing_weights']))

    def test_context_output_then_ss2d_learn_and_change_B_result(self):
        base, new = self.make_pair()
        r, t = self.inputs()
        opt = torch.optim.AdamW(new.parameters(), lr=.01, weight_decay=0.)
        original = {k: p.clone().detach() for k, p in new.named_parameters()}
        for step in range(3):
            opt.zero_grad(set_to_none=True)
            ro, to, _ = new(r, t)
            (ro.square().mean() + to.square().mean()).backward()
            named = dict(new.named_parameters())
            for bank in ['rgb_from_thermal', 'thermal_from_rgb']:
                output = named[bank+'.context.modulation.weight']
                scan = named[bank+'.context.scan.in_proj.weight']
                self.assertGreater(output.grad.abs().sum().item(), 0)
                self.assertTrue(torch.isfinite(scan.grad).all())
                if step == 0: self.assertEqual(scan.grad.abs().sum().item(), 0)
                else: self.assertGreater(scan.grad.abs().sum().item(), 0)
            opt.step()
        for bank in ['rgb_from_thermal', 'thermal_from_rgb']:
            name = bank+'.context.scan.in_proj.weight'
            self.assertFalse(torch.equal(original[name], dict(new.named_parameters())[name]))
        self.assertFalse(torch.equal(base(r, t)[0], new(r, t)[0]))

    def test_mask_safety_after_context_activates(self):
        _, new = self.make_pair()
        with torch.no_grad():
            for bank in [new.rgb_from_thermal, new.thermal_from_rgb]:
                bank.context.modulation.weight.normal_(std=.01)
        r, t = self.inputs()
        mask = torch.ones(2, 1, 5, 7, dtype=torch.bool)
        mask[..., -2:] = False
        a = new(r, t, (mask, mask))
        b = new(r.masked_fill(~mask, 999), t.masked_fill(~mask, -999), (mask, mask))
        for idx, source in [(0, r), (1, t)]:
            valid = mask.expand_as(source)
            self.assertTrue(torch.equal(a[idx][valid], b[idx][valid]))
            self.assertTrue(torch.equal(a[idx][~valid], source[~valid]))


if __name__ == '__main__': unittest.main()
