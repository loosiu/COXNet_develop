import copy
import unittest
from pathlib import Path

import torch

from dyfclt import frequency_training as api
from dyfclt.runtime import load_config
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, ModelEMA


class D2TrainingTests(unittest.TestCase):
    def config(self):
        config=load_config(Path(__file__).resolve().parents[1]/'configs/rgbtdroneperson_frequency_utility.yaml')
        config['model']['frequency_utility']['gate_mode']='sigmoid_detection'
        config['utility']['enabled']=False;config['utility']['loss_weight']=0.
        return config

    def test_sigmoid_mode_accepts_detection_only_and_refuses_binary_utility(self):
        config=self.config()
        self.assertFalse(api.validate_config(config))
        wrong=copy.deepcopy(config);wrong['utility']['enabled']=True
        with self.assertRaises(ValueError):api.validate_config(wrong)
        wrong=copy.deepcopy(config);wrong['utility']['loss_weight']=.1
        with self.assertRaises(ValueError):api.validate_config(wrong)

    def test_detection_only_training_step_updates_and_logs_the_frequency_gate(self):
        model=DyFCLT(2,hidden_dim=32,num_queries=8,num_decoder_layers=1,num_denoising=4,
            architecture='dual_rtdetr',pretrained=False,frequency_utility=dict(
                gate_mode='sigmoid_detection',dim=8,heads=2,evaluator_hidden=8,chunk_size=8))
        optimizer=build_optimizer(model,dict(lr=.00025,weight_decay=.0001,optimizer_groups='rtdetr'))
        ema=ModelEMA(model);scaler=torch.cuda.amp.GradScaler(enabled=False)
        targets=[dict(labels=torch.tensor([0]),boxes=torch.tensor([[.5,.5,.1,.1]])) for _ in range(2)]
        batch=torch.randn(2,3,64,96),torch.randn(2,3,64,96),targets
        heads={n:p for n,p in model.named_parameters() if '.evaluator.head.5.' in n}
        before={n:p.detach().clone() for n,p in heads.items()}
        result=api.training_step(model,None,ema,None,build_criterion(2,mask_weight=0),optimizer,scaler,
                                 batch,dict(enabled=False,loss_weight=0.,kl_max=0.),0.)
        self.assertTrue(result['applied']);self.assertFalse(result['utility_active'])
        self.assertEqual(result['utility_loss'],0.);self.assertIsNone(result['probe'])
        self.assertIsNotNone(result['gate_statistics'],'Gate logging must not depend on utility enabled')
        self.assertIn('w_mean',result['gate_statistics']);self.assertIn('s_mean',result['gate_statistics'])
        self.assertNotIn('u_mean',result['gate_statistics'])
        self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in heads.values()))
        self.assertTrue(all(not torch.equal(before[n],p) for n,p in heads.items()))
        self.assertEqual(ema.updates,1)

    def test_paired_cli_config_validation_uses_module_presence(self):
        self.assertTrue(hasattr(api,'validate_training_pair'),'CLI pairing must support utility-disabled frequency models')
        root=Path(__file__).resolve().parents[1]
        variant=load_config(root/'configs/rgbtdroneperson_frequency_utility.yaml')
        control=load_config(root/'configs/rgbtdroneperson_A_continuation.yaml')
        self.assertTrue(api.validate_training_pair(variant,root))
        self.assertTrue(api.validate_training_pair(control,root))


if __name__=='__main__':unittest.main()
