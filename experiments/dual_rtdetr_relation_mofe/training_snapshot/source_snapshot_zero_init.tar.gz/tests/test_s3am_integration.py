import copy,json,unittest
from pathlib import Path
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer,ModelEMA
from dyfclt.runtime import load_config
from dyfclt.frequency_training import gate_statistics
from tools.train import validate_detection_config
ROOT=Path(__file__).resolve().parents[1]
class S3AMIntegrationTests(unittest.TestCase):
 def opts(self):return dict(num_classes=2,hidden_dim=32,num_queries=8,num_decoder_layers=1,num_denoising=4,architecture='dual_rtdetr',pretrained=False)
 def create(self):
  try:return DyFCLT(**self.opts(),frequency_utility=dict(gate_mode='s3am_mofe',dim=8,expert_hidden=8,router_hidden=8))
  except ValueError as e:self.fail('Encoder must register s3am_mofe: '+str(e))
 def test_mode_and_cpu_rng_preserve_all_common_A_initial_states(self):
  torch.manual_seed(0);a=DyFCLT(**self.opts());rng=torch.get_rng_state()
  torch.manual_seed(0);m=self.create();self.assertTrue(torch.equal(rng,torch.get_rng_state()))
  for k,v in a.state_dict().items():self.assertTrue(torch.equal(v,m.state_dict()[k]),k)
  self.assertEqual(m.encoder.frequency_module.gate_mode,'s3am_mofe')
 def test_detection_backward_updates_every_expert_and_router_in_optimizer(self):
  torch.manual_seed(0);m=self.create();opt=build_optimizer(m,dict(lr=.00025,weight_decay=.0001,optimizer_groups='rtdetr'))
  ids={id(p) for g in opt.param_groups for p in g['params']}
  params=dict(m.encoder.frequency_module.named_parameters());before={n:p.detach().clone() for n,p in params.items()}
  self.assertTrue(all(id(p) in ids for p in params.values()))
  gt=[dict(labels=torch.tensor([0]),boxes=torch.tensor([[.5,.5,.2,.2]])) for _ in range(2)]
  out=m(torch.randn(2,3,64,96),torch.randn(2,3,64,96),gt,return_frequency_aux=True)
  losses=build_criterion(2,mask_weight=0)(out,gt);sum(losses.values()).backward();opt.step()
  for n,p in params.items():
   self.assertIsNotNone(p.grad,n);self.assertTrue(torch.isfinite(p.grad).all(),n);self.assertGreater(float(p.grad.abs().sum()),0,n);self.assertFalse(torch.equal(p,before[n]),n)
  stats=gate_statistics(out['frequency_aux']);self.assertIn('routing_entropy',stats);self.assertEqual(len(stats['routing_weight_mean']),4)
 def test_zero_experts_equal_bypassed_A_and_replay_uses_same_predictions(self):
  m=self.create().eval();module=m.encoder.frequency_module
  for expert in module.experts:torch.nn.init.zeros_(expert[-1].weight)
  r,t=torch.randn(2,3,64,96),torch.randn(2,3,64,96)
  with torch.no_grad():
   cache=m.prepare_frequency(r,t);replay=m.replay_frequency(cache);out=m(r,t)
   m.encoder.frequency_module=None;bypass=m(r,t)
  for k in ['pred_logits','pred_boxes']:
   self.assertTrue(torch.equal(out[k],bypass[k]),k);self.assertTrue(torch.equal(out[k],replay[k]),k)
 def test_encoder_only_changes_p3_before_original_fusions(self):
  m=self.create().eval();r,t=torch.randn(2,3,64,96),torch.randn(2,3,64,96)
  with torch.no_grad():
   cache=m.prepare_frequency(r,t);original=m.encoder.fuse_streams(cache['rgb_features'],cache['thermal_features'])
   rf=list(cache['rgb_features']);tf=list(cache['thermal_features']);rf[0],tf[0]=m.encoder.frequency_module.mix(cache['frequency'])
   fused=m.encoder.fuse_streams(rf,tf)
  self.assertFalse(torch.equal(rf[0],cache['rgb_features'][0]));self.assertIs(tf[0],cache['thermal_features'][0])
  for i in [1,2]:self.assertTrue(torch.equal(fused[i],original[i]))
 def test_mofe_recipe_matches_A_and_detection_trainer_accepts_it(self):
  cfg=load_config(ROOT/'configs/rgbtdroneperson_s3am_mofe.yaml')
  try:self.assertTrue(validate_detection_config(cfg))
  except ValueError as e:self.fail('Detection trainer must allow MoFE: '+str(e))
  a=json.loads(Path('/data/siwoo/DyFCLT/outputs/rgbtdroneperson_dual_rtdetr_seed0/config.json').read_text())
  cfg['model'].pop('frequency_utility')
  for c in [a,cfg]:c['train'].pop('output_dir')
  self.assertEqual(cfg,a)
