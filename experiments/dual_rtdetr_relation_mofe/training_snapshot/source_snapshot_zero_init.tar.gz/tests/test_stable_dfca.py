"""Independent numerical contracts for opt-in grouped, RMS-stabilized DFCA."""

import unittest

import torch

from dyfclt.frequency import DFCA
from test_compact_dfca import _conv_reference, _direct_dft, _equation_reference


def _rms_reference(correlation, epsilon):
    """Literal equation in float64, independent of production stabilization."""
    value = correlation.double()
    return value / (value.square().mean(dim=(-2, -1), keepdim=True)
                    + epsilon ** 2).sqrt()


def _stable_equation_reference(module, other, target, epsilon):
    query, key, value = (
        _conv_reference(_conv_reference(tensor.double(), branch[0]), branch[1])
        for tensor, branch in ((other, module.query), (target, module.key),
                               (target, module.value))
    )
    height, width = target.shape[-2:]
    fy = torch.tensor([min(y, height - y) / height for y in range(height)])
    fx = torch.tensor([min(x, width - x) / width for x in range(width)])
    radius = (fy[:, None].square() + fx[None, :].square()).sqrt()
    q_spectrum, k_spectrum, v_spectrum = map(_direct_dft, (query, key, value))
    response = torch.zeros_like(query)
    gate_inputs = []
    for lower, upper in ((0., .125), (.125, .25), (.25, .5)):
        band = ((radius >= lower) & (radius < upper)).double()
        correlation = _direct_dft(q_spectrum * k_spectrum.conj() * band,
                                  inverse=True).real
        normalized = _rms_reference(correlation, epsilon)
        gate_inputs.append(normalized.float())
        attention = _conv_reference(normalized, module.spatial_modulator).sigmoid()
        response += attention * _direct_dft(v_spectrum * band, inverse=True).real
    centered = response - response.mean(dim=1, keepdim=True)
    normalized = centered / (centered.square().mean(dim=1, keepdim=True) + 1e-5).sqrt()
    normalized = (normalized * module.norm.weight.double()[None, :, None, None]
                  + module.norm.bias.double()[None, :, None, None])
    return _conv_reference(normalized, module.projection).float(), gate_inputs


class StableDFCATests(unittest.TestCase):
    def test_explicit_defaults_preserve_state_rng_and_legacy_equation(self):
        # A new parameter, changed initialization, or default RMS breaks parity.
        kwargs = dict(channels=6, inner_channels=4)
        torch.manual_seed(127)
        original = DFCA(**kwargs)
        original_rng = torch.random.get_rng_state()
        torch.manual_seed(127)
        explicit = DFCA(**kwargs, gate_groups=1,
                        correlation_normalization='none', correlation_eps=1e-4)
        torch.testing.assert_close(torch.random.get_rng_state(), original_rng,
                                   atol=0, rtol=0)
        self.assertEqual(list(original.state_dict()), list(explicit.state_dict()))
        for name, expected in original.state_dict().items():
            torch.testing.assert_close(explicit.state_dict()[name], expected,
                                       atol=0, rtol=0, msg=name)
        explicit.load_state_dict(original.state_dict(), strict=True)
        other, target = torch.randn(2, 6, 5, 7), torch.randn(2, 6, 5, 7)
        with torch.no_grad():
            expected = original(other, target)
            torch.testing.assert_close(explicit(other, target), expected, atol=0, rtol=0)
            torch.testing.assert_close(expected, _equation_reference(original, other, target),
                                       atol=3e-5, rtol=3e-5)

    def test_grouped_rms_matches_matrix_dft_and_per_band_hw_oracle(self):
        # Detect wrong RMS axes, placement, centering, epsilon, or grouped gate.
        torch.manual_seed(211)
        epsilon = 1e-4
        module = DFCA(6, inner_channels=4, gate_groups=2,
                      correlation_normalization='rms', correlation_eps=epsilon).eval()
        for height, width in ((5, 7), (6, 9)):
            with self.subTest(height=height, width=width):
                other = torch.randn(2, 6, height, width)
                other[0] *= .03
                other[1] *= 4.
                target = torch.randn_like(other)
                observed = []
                hook = module.spatial_modulator.register_forward_pre_hook(
                    lambda _layer, inputs: observed.append(inputs[0].detach().clone()))
                try:
                    with torch.no_grad():
                        expected, expected_gates = _stable_equation_reference(
                            module, other, target, epsilon)
                        actual = module(other, target)
                finally:
                    hook.remove()
                self.assertEqual(len(observed), 3)
                for band, (actual_gate, expected_gate) in enumerate(zip(observed, expected_gates)):
                    self.assertEqual(actual_gate.dtype, torch.float32)
                    torch.testing.assert_close(actual_gate, expected_gate,
                                               atol=3e-5, rtol=3e-5, msg=f'band {band}')
                torch.testing.assert_close(actual, expected, atol=4e-5, rtol=4e-5)

    def test_rms_preserves_dc_and_separates_images_and_channels(self):
        # A centered or batch/channel-wide normalization cannot match this fixture.
        module = DFCA(4, gate_groups=2, correlation_normalization='rms',
                      correlation_eps=1e-4)
        values = torch.tensor([[2., -3., 0., 1e-5], [-7., .2, 9., -2e-5]])
        correlation = values[:, :, None, None].expand(2, 4, 3, 5).clone()
        normalized = module._normalize_correlation(correlation)
        torch.testing.assert_close(normalized.double(), _rms_reference(correlation, 1e-4),
                                   atol=2e-7, rtol=2e-7)
        self.assertGreater(normalized[0, 0].mean().item(), .99)
        self.assertLess(normalized[0, 1].mean().item(), -.99)
        self.assertEqual(normalized[0, 2].abs().sum().item(), 0.)

    def test_huge_finite_correlations_normalize_without_square_overflow(self):
        # Squaring these finite float32 values directly overflows.
        module = DFCA(4, gate_groups=2, correlation_normalization='rms',
                      correlation_eps=1e-4)
        correlation = torch.linspace(-2e20, 3e20, 120).reshape(2, 4, 3, 5)
        correlation.requires_grad_()
        normalized = module._normalize_correlation(correlation)
        self.assertTrue(torch.isfinite(normalized).all())
        torch.testing.assert_close(normalized.double(), _rms_reference(correlation, 1e-4),
                                   atol=3e-7, rtol=3e-7)
        weights = torch.linspace(-.4, .9, normalized.numel()).reshape_as(normalized)
        (normalized * weights).sum().backward()
        self.assertIsNotNone(correlation.grad)
        self.assertTrue(torch.isfinite(correlation.grad).all())

    def test_zero_and_tiny_correlation_have_finite_nonzero_derivatives(self):
        # sqrt(0) then clamp gives NaN backward despite finite forward output.
        module = DFCA(4, gate_groups=2, correlation_normalization='rms',
                      correlation_eps=1e-4)
        for amplitude in (0., 1e-30, 1e-8):
            with self.subTest(amplitude=amplitude):
                correlation = torch.full((2, 4, 3, 5), amplitude, requires_grad=True)
                normalized = module._normalize_correlation(correlation)
                self.assertTrue(torch.isfinite(normalized).all())
                normalized.sum().backward()
                self.assertTrue(torch.isfinite(correlation.grad).all())
                self.assertGreater(correlation.grad.abs().sum().item(), 0.)
                torch.testing.assert_close(normalized.double(), _rms_reference(correlation, 1e-4),
                                           atol=1e-11, rtol=2e-7)

    def test_empty_bands_and_zero_query_backpropagate_finitely(self):
        torch.manual_seed(37)
        for height, width, zero_query in ((1, 1, False), (3, 5, True)):
            with self.subTest(height=height, width=width, zero_query=zero_query):
                module = DFCA(6, inner_channels=4, gate_groups=2,
                              correlation_normalization='rms', correlation_eps=1e-4)
                if zero_query:
                    with torch.no_grad():
                        for parameter in module.query.parameters():
                            parameter.zero_()
                other = torch.randn(2, 6, height, width, requires_grad=True)
                target = torch.randn_like(other, requires_grad=True)
                output = module(other, target)
                self.assertTrue(torch.isfinite(output).all())
                weights = torch.linspace(-.3, .9, output.numel()).reshape_as(output)
                (output.square().mean() + (output * weights).mean()).backward()
                for name, gradient in [('other', other.grad), ('target', target.grad)] + [
                    (name, parameter.grad) for name, parameter in module.named_parameters()
                ]:
                    self.assertIsNotNone(gradient, name)
                    self.assertTrue(torch.isfinite(gradient).all(), name)

    def test_grouped_rms_inputs_and_all_parameters_receive_finite_gradients(self):
        torch.manual_seed(83)
        module = DFCA(8, inner_channels=8, gate_groups=4,
                      correlation_normalization='rms', correlation_eps=1e-4)
        other = torch.randn(2, 8, 9, 11, requires_grad=True)
        target = torch.randn(2, 8, 9, 11, requires_grad=True)
        output = module(other, target)
        weights = torch.linspace(-.7, 1.3, output.numel()).reshape_as(output)
        (output.square().mean() + (output * weights).mean()).backward()
        for name, gradient in [('other', other.grad), ('target', target.grad)] + [
            (name, parameter.grad) for name, parameter in module.named_parameters()
        ]:
            self.assertIsNotNone(gradient, name)
            self.assertTrue(torch.isfinite(gradient).all(), name)
            self.assertGreater(gradient.abs().sum().item(), 0., name)

    def test_stable_options_reject_invalid_groups_modes_and_epsilon(self):
        for groups in (0, -1, 3, 8, 1.5, '2', True, False):
            with self.subTest(groups=groups):
                with self.assertRaises(ValueError):
                    DFCA(8, inner_channels=4, gate_groups=groups)
        for mode in (None, '', 'RMS', 'layernorm', True):
            with self.subTest(mode=mode):
                with self.assertRaises(ValueError):
                    DFCA(8, correlation_normalization=mode)
        for epsilon in (0., -1e-4, float('nan'), float('inf'), -float('inf'), '1e-4', True, None):
            with self.subTest(epsilon=epsilon):
                with self.assertRaises(ValueError):
                    DFCA(8, correlation_eps=epsilon)
        # Group divisibility follows the internal width, not the external width.
        module = DFCA(6, inner_channels=4, gate_groups=4, correlation_normalization='rms')
        self.assertEqual(module(torch.randn(1, 6, 3, 5), torch.randn(1, 6, 3, 5)).shape,
                         (1, 6, 3, 5))


if __name__ == '__main__':
    unittest.main()
