#!/usr/bin/env bash
# One reproducible seed on physical GPU 1. Does not launch any additional seeds.
set -euo pipefail
cd /data/siwoo/DyFCLT

exec 9>/tmp/dyfclt_gpu1.lock
flock -n 9 || { echo 'DyFCLT GPU 1 lock is already held.' >&2; exit 1; }
# Cooperate with existing experiment launchers on this machine.
exec 8>/tmp/coxnet_oepc_gpu1.lock
flock -n 8 || { echo 'COXNet GPU 1 lock is held.' >&2; exit 1; }
exec 7>/tmp/coxnet_dwt_dfca_gpu1.lock
flock -n 7 || { echo 'DFCA GPU 1 lock is held.' >&2; exit 1; }
exec 6>/tmp/trpc_gpu1.lock
flock -n 6 || { echo 'TRPC GPU 1 lock is held.' >&2; exit 1; }

DYFCLT_GPU_UUID="$(nvidia-smi -i 1 --query-gpu=uuid --format=csv,noheader)"
DYFCLT_GPU_MEMORY="$(nvidia-smi -i 1 --query-gpu=memory.used --format=csv,noheader,nounits)"
if (( DYFCLT_GPU_MEMORY > 1000 )); then
    echo "GPU 1 already uses ${DYFCLT_GPU_MEMORY} MiB; refusing to overlap another experiment." >&2
    exit 1
fi
export DYFCLT_GPU_UUID
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=1
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export PYTHONUNBUFFERED=1

export DYFCLT_CONFIG="${DYFCLT_CONFIG:-configs/rgbtdroneperson.yaml}"
DYFCLT_RUN_DIR="$(/home/viplab/anaconda3/envs/coxmamba/bin/python - <<'PY_CONFIG'
import os, subprocess
from pathlib import Path
import torch
from dyfclt.runtime import load_config
# PyTorch 1.13 miscounts UUID visibility on this host, breaking CUDA RNG seeding.
# PCI ordering exposes one device; verify its physical UUID before proceeding.
if torch.cuda.device_count() != 1:
    raise SystemExit('Expected exactly one visible CUDA device.')
probe = torch.zeros(1, device='cuda:0')
rows = subprocess.check_output(
    ['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader'],
    text=True).splitlines()
actual = [row.split(',')[1].strip() for row in rows
          if int(row.split(',')[0].strip()) == os.getpid()]
if actual != [os.environ['DYFCLT_GPU_UUID']]:
    raise SystemExit('Visible CUDA device does not map to physical GPU 1: ' + repr(actual))
if len(torch.cuda.get_rng_state_all()) != 1:
    raise SystemExit('CUDA RNG state capture failed.')
config = load_config(os.environ['DYFCLT_CONFIG'])
output = Path(config['train']['output_dir']).resolve()
if output.exists() and any(output.iterdir()):
    raise SystemExit('Run directory is not empty; use explicit resume or a new output directory.')
print(output)
PY_CONFIG
)"
export DYFCLT_RUN_DIR
mkdir -p "$DYFCLT_RUN_DIR"
printf '%s\n' "$$" > "$DYFCLT_RUN_DIR/controller.pid"
/home/viplab/anaconda3/envs/coxmamba/bin/python - <<'PY'
import datetime, hashlib, json, os, pathlib, tarfile
from dyfclt.runtime import load_config
root = pathlib.Path('/data/siwoo/DyFCLT')
output = pathlib.Path(os.environ['DYFCLT_RUN_DIR'])
config_path = os.environ['DYFCLT_CONFIG']
config = load_config(config_path)
paths = sorted(p for prefix in ('dyfclt', 'tools', 'configs', 'tests', 'docs', 'third_party')
               for p in (root / prefix).rglob('*')
               if p.is_file() and '__pycache__' not in p.parts)
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with tarfile.open(output/'source_snapshot.tar.gz', 'w:gz') as archive:
    for path in paths:
        archive.add(path, arcname=path.relative_to(root))
meta = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            physical_gpu=1, gpu_uuid=os.environ['DYFCLT_GPU_UUID'],
            cuda_device_order=os.environ['CUDA_DEVICE_ORDER'],
            cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'],
            config=config_path, seed=config.get('seed', 0), resolved_config=config,
            status='paper-based reconstruction; author architecture not exactly identified',
            source_sha256=manifest)
(output/'launch.json').write_text(json.dumps(meta, indent=2))
PY
/home/viplab/anaconda3/envs/coxmamba/bin/python -u tools/train.py \
    --config "$DYFCLT_CONFIG" --device cuda:0 \
    > "$DYFCLT_RUN_DIR/console.log" 2>&1 &
DYFCLT_TRAIN_PID=$!
printf '%s\n' "$DYFCLT_TRAIN_PID" > "$DYFCLT_RUN_DIR/train.pid"
if wait "$DYFCLT_TRAIN_PID"; then
    printf '0\n' > "$DYFCLT_RUN_DIR/exit_code.txt"
else
    DYFCLT_EXIT_CODE=$?
    printf '%s\n' "$DYFCLT_EXIT_CODE" > "$DYFCLT_RUN_DIR/exit_code.txt"
    exit "$DYFCLT_EXIT_CODE"
fi
