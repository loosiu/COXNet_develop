"""Reject stale verification and reused outputs; record the fresh MoFE run once."""
import json,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dyfclt.runtime import load_config
from dyfclt.frequency_training import source_manifest,validate_output_destination,write_launch_provenance,sha256
cfg=load_config(ROOT/'configs/rgbtdroneperson_s3am_mofe.yaml')
a=json.loads(Path('/data/siwoo/DyFCLT/outputs/rgbtdroneperson_dual_rtdetr_seed0/config.json').read_text())
b=json.loads(json.dumps(cfg));b['model'].pop('frequency_utility')
for v in [a,b]:v['train'].pop('output_dir')
if a!=b:raise ValueError('Recipe differs from original A beyond module/output')
proof=json.loads((ROOT/'artifacts/verification.json').read_text())
manifest=source_manifest(ROOT)
if manifest!=proof['source_sha256']:raise ValueError('Source differs from verified snapshot')
if not all(proof[k] for k in ['shared_initial_tensors_bitwise_equal','all_module_parameters_gradient_and_update_verified','ema_eval_finite','cpu_tests_passed']):raise ValueError('Verification is incomplete')
if sha256(ROOT/cfg['model']['pretrained'])!=proof['pretrained_sha256']:raise ValueError('Pretrained backbone changed')
for name in ['train','val']:
 if sha256(cfg['data'][name]['ann_file'])!=proof['input_sha256'][name]:raise ValueError('Annotations changed')
output=ROOT/cfg['train']['output_dir'];validate_output_destination(output)
provenance=ROOT/'artifacts/training_launch_mofe_seed0_gpu1';provenance.mkdir(parents=True,exist_ok=True)
if (provenance/'launch.json').exists():raise FileExistsError('Fresh run already launched; preserve metadata')
launch=dict(started_utc=datetime.now(timezone.utc).isoformat(),mode='fresh_s3am_style_mofe_20_epochs',resolved_config=cfg,
 initialization={k:proof[k] for k in ['shared_initial_tensors_bitwise_equal','shared_tensor_count','pretrained_sha256']},
 trained_A_checkpoint_loaded=False,source_sha256=manifest,input_sha256=proof['input_sha256'],
 physical_gpu=1,device='cuda:0',expected_total_updates=49000,module_parameters=proof['module_parameters'],
 paper_scope='S3AM section II-B eqs2-7 adapted to post-PAN P3; expert/router layers are disclosed choices')
write_launch_provenance(provenance,ROOT,manifest,cfg,launch)
print(json.dumps(launch),flush=True)
