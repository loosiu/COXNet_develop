#!/usr/bin/env python3
"""Offline supplementary section 6.3 frequency analysis of original GT crops.

Uses per-channel PSD averaging, no resize, centered reflection padding to a
square and enclosing power of two, channel mean subtraction, symmetric Hann,
window-power compensation, and fixed radial octave bands through .5 cycles/pixel.
Thermal-reference GT boxes are applied to both aligned modalities. Equal weight
is assigned to each valid instance; constant and undersized crops are skipped
with reasons. The optional bound visits source JSON order, not a random sample.
Size breakdowns require explicit manual area bins; official RGBT-Tiny boundaries
are not supplied or inferred for the configured RGBTDronePerson dataset.
"""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dyfclt.runtime import load_config, make_dataset
from dyfclt.spectral_analysis import analyze_dataset, save_band_plot, validate_scale_bins


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--config', required=True, help='Existing dataset YAML/JSON config; no model is loaded')
    parser.add_argument('--split', default='val', choices=('train', 'val'), help='Dataset split (default: val)')
    parser.add_argument('--max-instances', type=int, help='Optional positive cap on selected annotations attempted, including skips')
    parser.add_argument('--output-dir', required=True, help='Directory for frequency_analysis.json and frequency_bands.png')
    parser.add_argument('--scale-bins', help='Path to JSON name:[lower,upper] map of bbox area in pixels squared; intervals [lower,upper), null upper is unbounded; manual bins only')
    args = parser.parse_args()
    if args.max_instances is not None and args.max_instances < 1:
        parser.error('--max-instances must be positive')
    scale_bins = None
    if args.scale_bins:
        try:
            with Path(args.scale_bins).open() as handle:
                scale_bins = validate_scale_bins(json.load(handle))
        except (OSError, ValueError) as error:
            parser.error(str(error))
    config = load_config(args.config)
    dataset = make_dataset(config, args.split, training=False)
    report = analyze_dataset(dataset, args.max_instances, scale_bins)
    report.update(config=str(Path(args.config).resolve()), split=args.split)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    save_band_plot(report, output / 'frequency_bands.png')
    report_path = output / 'frequency_analysis.json'
    report_path.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'report': str(report_path), 'plot': str(output / 'frequency_bands.png'),
                      'complete_dataset': report['complete_dataset'], 'counts': report['counts']}))


if __name__ == '__main__':
    main()
