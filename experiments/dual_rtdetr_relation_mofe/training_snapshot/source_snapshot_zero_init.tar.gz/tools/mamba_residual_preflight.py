"""Verify B parity then real detection gradients on GPU0; discard all updates."""
import argparse
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.runtime import (load_config, seed_everything, make_dataset, make_loader,
                            move_targets, resize_training_batch, warmup_factor, apply_optimizer_step)
from dyfclt.training import build_optimizer, build_ema, set_learning_rate
from dyfclt.frequency_training import source_manifest, sha256, gate_statistics
from tools.train import validate_detection_config


def fingerprints(model):
    return {k: hashlib.sha256(v.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
            for k, v in model.state_dict().items()}


def check_recipe(cfg):
    bcfg = load_config('/data/siwoo/DualRTDETR-Residual-MoFE/configs/rgbtdroneperson_residual_mofe.yaml')
    common = copy.deepcopy(cfg)
    common['model']['frequency_utility'] = copy.deepcopy(bcfg['model']['frequency_utility'])
    common['train']['output_dir'] = bcfg['train']['output_dir']
    assert common == bcfg, 'Only module and output may differ from B'
    assert validate_detection_config(cfg)
    # Loss, feature connection, data and optimization retain B source verbatim.
    for name in ['dyfclt/residual_mofe.py', 'dyfclt/model.py', 'dyfclt/losses.py',
                 'dyfclt/runtime.py', 'dyfclt/training.py', 'dyfclt/data.py',
                 'dyfclt/frequency_utility.py']:
        assert sha256(ROOT/name) == sha256(Path('/data/siwoo/DualRTDETR-Residual-MoFE')/name), name
    return bcfg


def initial_proof(cfg):
    bcfg = check_recipe(cfg)
    seed_everything(0)
    base = DyFCLT(**bcfg['model'])
    hashes, rng = fingerprints(base), torch.get_rng_state().clone()
    bmodule = copy.deepcopy(base.encoder.frequency_module)
    del base
    gc.collect()
    seed_everything(0)
    model = DyFCLT(**cfg['model'])
    actual = fingerprints(model)
    assert all(actual[name] == value for name, value in hashes.items())
    assert torch.equal(rng, torch.get_rng_state())
    module = model.encoder.frequency_module
    rgb, thermal = torch.randn(2, 256, 5, 7), torch.randn(2, 256, 5, 7)
    with torch.no_grad():
        left, right = bmodule(rgb, thermal), module(rgb, thermal)
    assert torch.equal(left[0], right[0]) and torch.equal(left[1], right[1])
    proof = dict(all_B_initial_tensors_bitwise_equal=True, shared_B_tensor_count=len(hashes),
                 B_module_initial_output_exact=True, torch_cpu_rng_equal=True,
                 recipe_matches_B_except_module_and_output=True, B_initial_sha256=hashes)
    (ROOT/'artifacts/initialization_verification.json').write_text(json.dumps(proof, indent=2))
    del bmodule
    return model, proof


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cpu-only', action='store_true')
    args = parser.parse_args()
    cfg = load_config(ROOT/'configs/rgbtdroneperson_Ev2_seed0.yaml')
    assert (ROOT/'artifacts/full_tests_exit_code.txt').read_text().strip() == '0'
    model, proof = initial_proof(cfg)
    if args.cpu_only:
        print(json.dumps({k:v for k,v in proof.items() if k!='B_initial_sha256'}), flush=True)
        return
    model.cuda().train()
    module = model.encoder.frequency_module
    params = dict(module.named_parameters())
    base_names = [name for name in params if '.context.' not in name]
    context_names = [name for name in params if '.context.' in name]
    before = {name:p.detach().clone() for name,p in params.items()}
    optimizer, ema = build_optimizer(model, cfg['train']), build_ema(model, cfg['train'])
    ids = {id(p) for group in optimizer.param_groups for p in group['params']}
    assert all(id(p) in ids for p in params.values())
    train, val = make_dataset(cfg, 'train', training=True), make_dataset(cfg, 'val')
    assert len(train)==4900 and len(val)==1225 and train.category_ids==val.category_ids==[0,1,2]
    criterion = build_criterion(3, **cfg['loss']).cuda()
    scaler = torch.cuda.amp.GradScaler(enabled=False)
    batches = iter(make_loader(train, batch_size=2, workers=0, training=True))
    steps = []
    torch.cuda.reset_peak_memory_stats()
    for index, size in enumerate([(448,576), (576,704), (512,640)]):
        rgb, thermal, targets = resize_training_batch(*next(batches), [size])
        rgb, thermal, targets = rgb.cuda(), thermal.cuda(), move_targets(targets, 'cuda:0')
        set_learning_rate(optimizer, cfg['train']['lr'], warmup_factor(index,2000,.001))
        optimizer.zero_grad(set_to_none=True)
        started = time.monotonic()
        outputs = model(rgb, thermal, targets, return_frequency_aux=True)
        losses = criterion(outputs, targets)
        assert not any('mask' in k or 'utility' in k or 'kl' in k for k in losses)
        loss = sum(losses.values()); assert torch.isfinite(loss)
        loss.backward()
        gradients = {name:dict(finite=p.grad is not None and bool(torch.isfinite(p.grad).all()),
                               abs_sum=float(p.grad.abs().sum()) if p.grad is not None else None)
                     for name,p in params.items()}
        assert all(row['finite'] for row in gradients.values())
        assert all(gradients[name]['abs_sum']>0 for name in base_names)
        for bank in ['rgb_from_thermal', 'thermal_from_rgb']:
            assert gradients[bank+'.context.modulation.weight']['abs_sum']>0
            scan_grad = gradients[bank+'.context.scan.in_proj.weight']['abs_sum']
            assert scan_grad==0 if index==0 else scan_grad>0
        norm, applied = apply_optimizer_step(model,optimizer,scaler,.1,ema)
        assert applied and torch.isfinite(norm)
        torch.cuda.synchronize()
        row = dict(step=index+1,image_size=list(size),loss=float(loss.detach()),grad_norm=float(norm),
                   seconds=time.monotonic()-started,module_gradients=gradients,
                   gate_statistics=gate_statistics(outputs['frequency_aux']))
        steps.append(row)
        print(json.dumps({k:row[k] for k in ['step','image_size','loss','grad_norm','seconds']}),flush=True)
        del outputs, losses, loss
    changed = {name:not torch.equal(p,before[name]) for name,p in params.items()}
    assert all(changed[name] for name in base_names)
    for bank in ['rgb_from_thermal', 'thermal_from_rgb']:
        assert changed[bank+'.context.modulation.weight']
    # Normal warmup + global clipping can round tiny Mamba changes in FP32.
    # Preserve individual gradient/update evidence rather than claim all changed.
    with torch.no_grad():
        r,t,_ = next(iter(make_loader(val,batch_size=2,workers=0)))
        left, right = ema.module(r.cuda(),t.cuda()), ema.module(r.cuda(),t.cuda())
        assert all(torch.equal(left[k],right[k]) and torch.isfinite(left[k]).all()
                   for k in ['pred_logits','pred_boxes'])
    proof.pop('B_initial_sha256')
    proof.update(cpu_tests_passed=True, optimizer_includes_all_module_parameters=True,
        finite_detection_gradients=True, first_update_activates_SS2D_gradient=True,
        unchanged_B_parameters_updated=True, ema_eval_finite_repeatable=True,
        module_parameter_tensors=len(params), context_parameter_tensors=len(context_names),
        updated_module_parameter_tensors=changed, actual_GPU_steps=steps,
        parameters=sum(p.numel() for p in model.parameters()),
        module_parameters=sum(p.numel() for p in module.parameters()),
        peak_memory_reserved_bytes=torch.cuda.max_memory_reserved(),
        pretrained_sha256=sha256(ROOT/cfg['model']['pretrained']),
        input_sha256={s:sha256(cfg['data'][s]['ann_file']) for s in ['train','val']},
        source_sha256=source_manifest(ROOT), AP_measured=False,
        trained_A_B_E_checkpoint_loaded=False, production_training_launched=False)
    (ROOT/'artifacts/verification.json').write_text(json.dumps(proof,indent=2,allow_nan=False))
    print(json.dumps(dict(verified=True, parameters=proof['parameters'],
                         changed_tensors=sum(changed.values()), total_tensors=len(params))),flush=True)


if __name__=='__main__': main()
