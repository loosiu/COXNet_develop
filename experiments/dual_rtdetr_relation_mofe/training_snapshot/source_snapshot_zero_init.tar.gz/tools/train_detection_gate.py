#!/usr/bin/env python3
"""D2 detection-only training entrypoint; explicit --train or --smoke-steps required."""
from train_frequency_utility import main

if __name__ == '__main__': main()
