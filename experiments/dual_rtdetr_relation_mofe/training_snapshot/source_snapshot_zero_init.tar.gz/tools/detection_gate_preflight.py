#!/usr/bin/env python3
"""Bounded D2 detection-gradient check plus fixed-object weight sweeps; no AP claim."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.frequency_training import (initialize_from_a, validate_config, validate_training_pair,
    source_manifest, sha256, training_step, gate_statistics)
from dyfclt.runtime import (load_config, seed_everything, make_dataset, make_loader, move_targets,
    resize_training_batch, warmup_factor)
from dyfclt.training import build_optimizer, build_ema, set_learning_rate
from dyfclt.utility_probe import UtilityTeacher
from dyfclt.object_sweep import ObjectProbeSampler, fixed_object_sweep


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='configs/rgbtdroneperson_frequency_utility.yaml')
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--backward-steps', type=int, default=2)
    parser.add_argument('--sweep-batches', type=int, default=8)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--output', default='artifacts/preflight/report.json')
    args = parser.parse_args()
    if min(args.backward_steps, args.sweep_batches, args.workers) < 0: parser.error('Counts must be nonnegative')
    output = Path(args.output)
    if output.exists(): raise FileExistsError('Choose a new evidence output path')
    config = load_config(args.config)
    if validate_config(config) or config['model'].get('frequency_utility', {}).get('gate_mode') != 'sigmoid_detection':
        raise ValueError('This preflight requires detection-only D2 sigmoid gates')
    validate_training_pair(config, ROOT)
    seed_everything(config['seed']); device = torch.device(args.device)
    if config['train']['amp'] and device.type != 'cuda': raise ValueError('AMP requires CUDA verification')
    model = DyFCLT(**dict(config['model'], pretrained=False)).to(device)
    initialization = initialize_from_a(model, config['initialization']['checkpoint'], config['initialization']['weights'])
    data = make_dataset(config, 'train', training=True)
    if data.category_ids != initialization['category_ids']: raise ValueError('A/data category mismatch')
    loader = make_loader(data, config['train']['batch_size'], args.workers, training=True)
    criterion = build_criterion(config['model']['num_classes'], **config['loss']).to(device)
    optimizer, ema = build_optimizer(model, config['train']), build_ema(model, config['train'])
    sweep_options = config['object_sweep']
    # This teacher is only a bounded diagnostic instrument; regular D2 training has no utility teacher.
    teacher = UtilityTeacher(model, sweep_options['diagnostic_teacher_decay'])
    sampler = ObjectProbeSampler(config['seed'], sweep_options['gt_probability'])
    optimizer_ids = {id(p) for group in optimizer.param_groups for p in group['params']}
    optimizer_covers_all = optimizer_ids == {id(p) for p in model.parameters() if p.requires_grad}
    assert optimizer_covers_all
    scaler = torch.cuda.amp.GradScaler(enabled=bool(config['train']['amp'] and device.type == 'cuda'))
    initial_gates, zero_identity, sweeps, steps = None, None, [], []
    if device.type == 'cuda': torch.cuda.reset_peak_memory_stats(device)
    for index, (rgb, thermal, targets) in enumerate(loader):
        if index >= max(args.backward_steps, args.sweep_batches): break
        rgb, thermal, targets = resize_training_batch(rgb, thermal, targets, config['train']['resize_sizes'])
        batch = rgb.to(device), thermal.to(device), move_targets(targets, device)
        if index == 0:
            with torch.no_grad():
                cache = teacher.module.prepare_frequency(batch[0], batch[1])
                initial_gates = gate_statistics(cache['frequency'])
                out_r, out_t = teacher.module.encoder.frequency_module.mix(cache['frequency'], torch.zeros_like(cache['frequency']['w']))
                zero_identity = torch.equal(out_r, cache['rgb_features'][0]) and torch.equal(out_t, cache['thermal_features'][0])
                assert zero_identity
                assert 'a' not in cache['frequency'] and 'u' not in cache['frequency']
                del cache, out_r, out_t
        if index < args.sweep_batches:
            sweep = fixed_object_sweep(teacher.module, *batch, criterion, sampler,
                        weights=sweep_options['weights'], region_size=sweep_options['region_size'])
            sweep.update(batch=index+1, teacher_updates=teacher.updates, input_shape=list(rgb.shape))
            sweeps.append(sweep)
        if index < args.backward_steps:
            before = {n:p.detach().clone() for n,p in model.named_parameters() if '.evaluator.' in n}
            factor = warmup_factor(index, config['train']['warmup_steps'], config['train']['warmup_factor'])
            set_learning_rate(optimizer, config['train']['lr'], factor)
            row = training_step(model, teacher, ema, None, criterion, optimizer, scaler, batch,
                                config['utility'], index/len(loader), max_grad_norm=config['train']['clip_grad_norm'])
            assert row['applied'] and not row['utility_active'] and row['utility_loss'] == 0 and row['probe'] is None
            grads = {n:p.grad for n,p in model.named_parameters() if p.grad is not None}
            assert all(torch.isfinite(g).all() for g in grads.values())
            gate_checks = {}
            for direction_name in ('rgb_direction', 'thermal_direction'):
                direction = getattr(model.encoder.frequency_module, direction_name)
                for band, expert in zip(('LL','LH','HL','HH'), direction.experts):
                    first, last = expert.evaluator.head[0].weight, expert.evaluator.head[-1].weight
                    prefix = 'encoder.frequency_module.'+direction_name+'.experts.'+str(('LL','LH','HL','HH').index(band))+'.evaluator.'
                    changed = any(not torch.equal(p, before[n]) for n,p in model.named_parameters() if n.startswith(prefix))
                    check = dict(first_weight_grad_nonzero=bool(first.grad is not None and first.grad.abs().sum()>0),
                                 last_weight_grad_nonzero=bool(last.grad is not None and last.grad.abs().sum()>0), parameters_changed=changed)
                    assert all(check.values()), (direction_name,band,check)
                    gate_checks[direction_name+'/'+band] = check
            row.update(gate_checks=gate_checks, finite_gradients=True,
                producer_nonzero_grad=bool(any(g.abs().sum()>0 for n,g in grads.items() if 'frequency_module.' in n and '.evaluator.' not in n)),
                detection_gate_backward_succeeded=True)
            assert row['producer_nonzero_grad']
            steps.append(row); del before
        print(json.dumps(dict(batch=index+1, sweeps=len(sweeps),optimizer_steps=len(steps)),allow_nan=False),flush=True)
    summary = {}
    for band in ('LL','LH','HL','HH'):
        count = sum(len(sweep['sites']) for sweep in sweeps)
        summary[band] = dict(object_curves=count,
            measurable_object_curves=sum(sum(s['bands'][band]['measurable_object_range']) for s in sweeps),
            measurable_image_curves=sum(sum(s['bands'][band]['measurable_image_range']) for s in sweeps),
            diagnostic_only=True)
    report = dict(verified_utc=datetime.now(timezone.utc).isoformat(),experiment='D2_detection_sigmoid_gate',
        resolved_config=config,source_sha256=source_manifest(ROOT),device=str(device),tested_amp=scaler.is_enabled(),
        input_sha256=dict(train_annotations=sha256(config['data']['train']['ann_file']),val_annotations=sha256(config['data']['val']['ann_file'])),
        initialization=initialization,parameters=sum(p.numel() for p in model.parameters()),
        module_parameters=sum(p.numel() for p in model.encoder.frequency_module.parameters()),optimizer_covers_all_parameters=optimizer_covers_all,
        initial_gates=initial_gates,zero_gate_identity=zero_identity,bounded_optimizer_steps=len(steps),training_steps=steps,
        evaluation_ema_updates=ema.updates,diagnostic_teacher_updates=teacher.updates,
        gate_detection_backward_verified=bool(len(steps)>=2 and all(s['detection_gate_backward_succeeded'] for s in steps)),
        object_sweeps=sweeps,sweep_summary=summary,sweep_objects=sum(len(s['sites']) for s in sweeps),
        binary_utility_used=False,evidence_used=False,object_auxiliary_supervision_used=False,
        full_training_launched=False,AP_measured=False,
        peak_allocated_memory_mib=torch.cuda.max_memory_allocated(device)/(1024**2) if device.type=='cuda' else None)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ['parameters','module_parameters','bounded_optimizer_steps',
        'gate_detection_backward_verified','sweep_objects','sweep_summary','peak_allocated_memory_mib']},indent=2),flush=True)


if __name__=='__main__':main()
