#!/usr/bin/env bash
# Fusion-only dual-stream RT-DETR, seed 0, physical GPU 1.
set -euo pipefail
cd /data/siwoo/DyFCLT
export DYFCLT_CONFIG=configs/rgbtdroneperson_dual_rtdetr.yaml
exec bash tools/train_gpu1_seed0.sh
