#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
(( $# == 0 )) || exit 2
export EFG_GPU_INDEX=0 EFG_RUN_DIR=artifacts/training_launch_E_seed0_gpu0
PYTHON_BIN=/home/viplab/anaconda3/envs/coxmamba/bin/python
source tools/gpu_guard.sh
"$PYTHON_BIN" -u tools/mamba_residual_preflight.py > artifacts/gpu_preflight.log 2>&1
"$PYTHON_BIN" -u tools/prepare_mamba_residual_launch.py
"$PYTHON_BIN" -u tools/train.py --config configs/rgbtdroneperson_Ev2_seed0.yaml --device cuda:0
