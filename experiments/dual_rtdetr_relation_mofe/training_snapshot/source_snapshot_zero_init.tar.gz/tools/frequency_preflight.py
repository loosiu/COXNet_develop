#!/usr/bin/env python3
"""Bounded real-data verification; a failed signal check never launches training."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.frequency_training import (initialize_from_a, sha256, source_manifest, validate_config,
    validate_paired_recipes, training_step, serialize_probe, gate_statistics, utility_preflight_ready)
from dyfclt.utility_probe import UtilityTeacher, UtilityProbeSampler, make_utility_labels
from dyfclt.training import build_optimizer, build_ema, set_learning_rate
from dyfclt.runtime import load_config, seed_everything, make_dataset, make_loader, move_targets, resize_training_batch, warmup_factor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='configs/rgbtdroneperson_frequency_utility.yaml')
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--probe-batches', type=int, default=8)
    parser.add_argument('--backward-steps', type=int, default=2)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--output', default='artifacts/preflight/report.json')
    args = parser.parse_args()
    if min(args.probe_batches, args.backward_steps, args.workers) < 0:
        parser.error('Counts must be nonnegative')
    output = Path(args.output)
    if output.exists(): raise FileExistsError('Preflight evidence already exists; choose a new --output')
    output.parent.mkdir(parents=True, exist_ok=True)
    config = load_config(args.config)
    if not validate_config(config): raise ValueError('This preflight checks the utility-enabled D variant')
    control = load_config(ROOT/'configs/rgbtdroneperson_A_continuation.yaml')
    validate_paired_recipes(control, config)
    seed_everything(config['seed']); device = torch.device(args.device)
    if config['train']['amp'] and device.type != 'cuda':
        raise ValueError('An AMP recipe requires an actual CUDA preflight')
    options = dict(config['model']); options['pretrained'] = False
    student = DyFCLT(**options).to(device)
    initialization = initialize_from_a(student, config['initialization']['checkpoint'], config['initialization']['weights'])
    data = make_dataset(config, 'train', training=True)
    if data.category_ids != initialization['category_ids']:
        raise ValueError('A/data category mapping differs')
    loader = make_loader(data, config['train']['batch_size'], args.workers, training=True)
    criterion = build_criterion(config['model']['num_classes'], **config['loss']).to(device)
    teacher = UtilityTeacher(student, config['utility']['teacher_decay'])
    sampler = UtilityProbeSampler(config['seed'], config['utility']['gt_probability'])
    optimizer = build_optimizer(student, config['train']); ema = build_ema(student, config['train'])
    optimizer_ids = {id(p) for group in optimizer.param_groups for p in group['params']}
    optimizer_covers_all = optimizer_ids == {id(p) for p in student.parameters() if p.requires_grad}
    assert optimizer_covers_all
    scaler = torch.cuda.amp.GradScaler(enabled=bool(config['train']['amp'] and device.type == 'cuda'))
    probes, steps, initial_gates = [], [], None
    region_sizes = tuple(config['utility'].get('diagnostic_region_sizes', (1, 3, 5)))
    evaluator_parameters = {n: p for n, p in student.named_parameters() if '.evaluator.' in n}
    if device.type == 'cuda': torch.cuda.reset_peak_memory_stats(device)
    for index, (rgb, thermal, targets) in enumerate(loader):
        if index >= max(args.probe_batches, args.backward_steps): break
        rgb, thermal, targets = resize_training_batch(rgb, thermal, targets, config['train']['resize_sizes'])
        batch = rgb.to(device), thermal.to(device), move_targets(targets, device)
        if index == 0:
            with torch.no_grad():
                cache = teacher.module.prepare_frequency(batch[0], batch[1])
                initial_gates = gate_statistics(cache['frequency'])
                module = teacher.module.encoder.frequency_module
                r0, t0 = module.mix(cache['frequency'], torch.zeros_like(cache['frequency']['w']))
                assert torch.equal(r0, cache['rgb_features'][0]) and torch.equal(t0, cache['thermal_features'][0])
                zero_gates_identity = True
                del cache, r0, t0
        if index < args.backward_steps:
            before_evaluators = {n: p.detach().clone() for n, p in evaluator_parameters.items()}
            factor = warmup_factor(index, config['train']['warmup_steps'], config['train']['warmup_factor'])
            set_learning_rate(optimizer, config['train']['lr'], factor)
            row = training_step(student, teacher, ema, sampler, criterion, optimizer, scaler, batch, config['utility'],
                                index/len(loader), do_probe=index < args.probe_batches, check_noop=True,
                                max_grad_norm=config['train']['clip_grad_norm'], probe_region_sizes=region_sizes)
            assert row['applied']
            gradients = {n: p.grad for n, p in student.named_parameters() if p.grad is not None}
            assert all(torch.isfinite(g).all() for g in gradients.values())
            row['producer_nonzero_grad'] = any(g.abs().sum() > 0 for n, g in gradients.items()
                                               if 'frequency_module.' in n and '.evaluator.' not in n)
            row['evaluator_nonzero_grad'] = any(g.abs().sum() > 0 for n, g in gradients.items() if '.evaluator.' in n)
            row['producer_nonzero_grad'], row['evaluator_nonzero_grad'] = bool(row['producer_nonzero_grad']), bool(row['evaluator_nonzero_grad'])
            row['evaluator_gradients_all_none'] = all(p.grad is None for p in evaluator_parameters.values())
            row['evaluator_gradients_finite'] = all(p.grad is None or torch.isfinite(p.grad).all().item() for p in evaluator_parameters.values())
            row['evaluator_parameters_unchanged'] = all(torch.equal(p, before_evaluators[n]) for n, p in evaluator_parameters.items())
            assert row['producer_nonzero_grad']
            if row['utility_active']:
                assert row['evaluator_nonzero_grad'] and row['evaluator_gradients_finite']
            else:
                assert row['evaluator_gradients_all_none'] and row['evaluator_parameters_unchanged']
            del before_evaluators
            steps.append(row)
            if row['probe'] is not None: probes.append(row['probe'])
        elif index < args.probe_batches:
            probe = make_utility_labels(teacher.module, *batch, criterion, sampler, check_noop=True,
                                       diagnostic_region_sizes=region_sizes)
            probes.append(serialize_probe(probe))
        print(json.dumps(dict(batch=index+1, input_shape=list(rgb.shape), optimizer_steps=len(steps),
                              probe_images=sum(len(p['labels']) for p in probes)), allow_nan=False), flush=True)
    labels = [v for p in probes for v in p['labels']]
    neutral = [v for p in probes for v in p['neutral']]
    deltas = [v for p in probes for v in p['delta_cost']]
    epsilons = [v for p in probes for v in p['epsilon']]
    noops = [v for p in probes for v in (p['noop_delta'] or [])]
    count = len(labels)
    nonneutral_fraction = 1-sum(neutral)/count if count else None
    # A small readiness check, not a calibrated estimate or evidence of AP improvement.
    finite = all(torch.isfinite(torch.tensor(v)).all().item() for v in [labels, deltas, epsilons, noops])
    constants = all(torch.equal(m.encoder.frequency_module.residual_scale,
                               student.encoder.frequency_module.residual_scale) for m in [teacher.module, ema.module])
    valid_labels = [label for label, is_neutral in zip(labels, neutral) if not is_neutral]
    valid_backward_steps = sum(bool(row['applied'] and row['utility_active'] and row['evaluator_nonzero_grad']
                              and row['evaluator_gradients_finite']) for row in steps)
    region_signal = {}
    for size in region_sizes:
        infos = [p['diagnostic_regions'][str(size)] for p in probes]
        region_neutral = [value for info in infos for value in info['neutral']]
        region_positive = [value for info in infos for value in info['positive_valid']]
        region_signal[str(size)] = dict(images=len(region_neutral), valid_count=len(region_neutral)-sum(region_neutral),
            positive_valid_count=sum(region_positive), negative_valid_count=len(region_neutral)-sum(region_neutral)-sum(region_positive),
            neutral_fraction=sum(region_neutral)/len(region_neutral) if region_neutral else None,
            diagnostic_only=True)
    report = dict(verified_utc=datetime.now(timezone.utc).isoformat(), resolved_config=config,
        device=str(device), tested_amp=scaler.is_enabled(), probe_loader_workers=args.workers, initialization=initialization,
        source_sha256=source_manifest(ROOT),
        input_sha256=dict(train_annotations=sha256(config['data']['train']['ann_file']),
                          val_annotations=sha256(config['data']['val']['ann_file'])),
        parameters=sum(p.numel() for p in student.parameters()),
        module_parameters=sum(p.numel() for p in student.encoder.frequency_module.parameters()),
        optimizer_covers_all_parameters=optimizer_covers_all,
        bounded_optimizer_steps=len(steps), utility_teacher_updates=teacher.updates, evaluation_ema_updates=ema.updates,
        zero_gate_identity=zero_gates_identity if initial_gates else None, initial_gates=initial_gates,
        constants_exact=constants, finite=finite, probes=probes, training_steps=steps,
        experiment='D1_neutral_exclusion_and_region_diagnostics',
        valid_utility_backward_steps=valid_backward_steps, region_signal=region_signal,
        single_cell_signal=dict(images=count, positive_fraction=sum(labels)/count if count else None,
                                positive_fraction_all=sum(labels)/count if count else None,
                                positive_fraction_valid=sum(valid_labels)/len(valid_labels) if valid_labels else None,
                                valid_count=len(valid_labels), positive_valid_count=sum(valid_labels),
                                negative_valid_count=len(valid_labels)-sum(valid_labels),
                                neutral_fraction=sum(neutral)/count if count else None,
                                nonneutral_fraction=nonneutral_fraction, delta_cost=deltas, epsilon=epsilons,
                                maximum_noop_error=max(noops) if noops else None,
                                criterion='at least16images, >=10percent nonneutral SINGLE-CELL, >=2updates, and actual valid-label utility backward'),
        ready_for_long_training=utility_preflight_ready(count, nonneutral_fraction, steps, finite, constants),
        full_training_launched=False, AP_measured=False,
        peak_allocated_memory_mib=torch.cuda.max_memory_allocated(device)/(1024**2) if device.type == 'cuda' else None)
    output.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    print(json.dumps({k: report[k] for k in ['parameters', 'module_parameters', 'single_cell_signal',
                        'bounded_optimizer_steps', 'valid_utility_backward_steps', 'region_signal',
                        'ready_for_long_training', 'peak_allocated_memory_mib']}, indent=2), flush=True)


if __name__ == '__main__': main()
