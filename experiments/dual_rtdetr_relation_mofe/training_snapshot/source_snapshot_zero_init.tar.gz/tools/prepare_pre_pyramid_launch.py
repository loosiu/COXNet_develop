"""Record one immutable fresh production launch after matching GPU preflight."""
from datetime import datetime,timezone
import json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dyfclt.runtime import load_config
from dyfclt.frequency_training import sha256,validate_output_destination,write_launch_provenance
from tools.pre_pyramid_protocol import variant_paths,TARGET_GPU,check_recipe,experiment_manifest,verify_tests,verify_originals

def main(variant):
    paths=variant_paths(variant);cfg=load_config(paths['config']);check_recipe(variant,cfg);verify_tests();verify_originals()
    gpu=TARGET_GPU[variant];proof=json.loads((ROOT/f'artifacts/verification_{variant}_gpu{gpu}.json').read_text())
    assert int(os.environ['EFG_GPU_INDEX'])==gpu and proof['gpu_uuid']==os.environ['EFG_GPU_UUID']
    assert proof['source_sha256']==experiment_manifest(),'Source changed after GPU check'
    for k in ['all_original_initial_tensors_equal','CPU_rng_equal','cpu_tests_passed','all_gradients_finite',
              'all_base_parameters_updated','optimizer_includes_all_module_parameters','EMA_eval_finite_repeatable']:assert proof[k],k
    if variant=='E':assert proof['new_E_initial_output_exact_new_B'] and proof['Mamba_scan_gradients_active_after_first_update']
    assert sha256(ROOT/cfg['model']['pretrained'])==proof['pretrained_sha256']
    for split in ['train','val']:assert sha256(cfg['data'][split]['ann_file'])==proof['input_sha256'][split]
    validate_output_destination(paths['output']);dest=paths['run'];dest.mkdir(parents=True,exist_ok=True)
    assert not (dest/'launch.json').exists(),'Preserve previous production launch'
    launch={'started_utc':datetime.now(timezone.utc).isoformat(),'variant':variant,'revision':'pre_pyramid_v1',
            'mode':'fresh_seed0_projection_P3_MoFE_then_original_AIFI_FPN_PAN',
            'resolved_config':cfg,'expected_total_updates':49000,'physical_gpu':gpu,'gpu_uuid':proof['gpu_uuid'],'device':'cuda:0',
            'source_sha256':proof['source_sha256'],'input_sha256':proof['input_sha256'],'pretrained_sha256':proof['pretrained_sha256'],
            'parameters':proof['parameters'],'module_parameters':proof['module_parameters'],
            'trained_A_or_B_checkpoint_loaded':False,'trained_E_checkpoint_loaded':False,
            'verification':f'artifacts/verification_{variant}_gpu{gpu}.json',
            'mechanism':'Existing bidirectional B/E banks after input projection at P3; original per-stream AIFI/FPN/PAN; original RGB/T concat+CSP fusion and decoder; detection loss only'}
    write_launch_provenance(dest,ROOT,proof['source_sha256'],cfg,launch);print(json.dumps({'launch':str(dest/'launch.json')}),flush=True)

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit(2)
    main(sys.argv[1])
