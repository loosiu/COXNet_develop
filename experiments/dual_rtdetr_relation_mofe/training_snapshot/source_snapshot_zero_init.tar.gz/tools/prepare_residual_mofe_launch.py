"""Require verified code and inputs before recording a fresh immutable launch."""
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dyfclt.runtime import load_config
from dyfclt.frequency_training import source_manifest, sha256, validate_output_destination, write_launch_provenance

cfg = load_config(ROOT / 'configs/rgbtdroneperson_residual_mofe.yaml')
original = json.loads(Path('/data/siwoo/DyFCLT/outputs/rgbtdroneperson_dual_rtdetr_seed0/config.json').read_text())
common = copy.deepcopy(cfg)
common['model'].pop('frequency_utility')
for config in [original, common]: config['train'].pop('output_dir')
assert common == original
proof = json.loads((ROOT / 'artifacts/verification.json').read_text())
manifest = source_manifest(ROOT)
assert manifest == proof['source_sha256'], 'Code changed after GPU verification'
for key in ['shared_initial_tensors_bitwise_equal', 'original_RGB_bank_all_initial_tensors_equal',
            'torch_cpu_rng_equal', 'original_expert_router_source_unchanged', 'direction_parameter_banks_independent',
            'all_module_parameters_gradient_and_update_verified', 'ema_eval_finite', 'ema_eval_repeatable',
            'detection_only_gamma_gradient_verified', 'cpu_tests_passed']:
    assert proof[key], key
assert (ROOT / 'artifacts/full_tests_exit_code.txt').read_text().strip() == '0'
assert sha256(ROOT / cfg['model']['pretrained']) == proof['pretrained_sha256']
for split in ['train', 'val']: assert sha256(cfg['data'][split]['ann_file']) == proof['input_sha256'][split]
validate_output_destination(ROOT / cfg['train']['output_dir'])
dest = ROOT / 'artifacts/training_launch_residual_mofe_seed0_gpu1'
dest.mkdir(parents=True, exist_ok=True)
if (dest / 'launch.json').exists():
    raise FileExistsError('Preserve previous launch; only start this fresh run once')
launch = dict(started_utc=datetime.now(timezone.utc).isoformat(),
    mode='fresh_independent_bidirectional_residual_mofe_20_epochs', resolved_config=cfg,
    trained_A_checkpoint_loaded=False, source_sha256=manifest, input_sha256=proof['input_sha256'],
    initialization={key: proof[key] for key in ['shared_initial_tensors_bitwise_equal', 'shared_tensor_count',
                    'original_RGB_bank_all_initial_tensors_equal', 'pretrained_sha256']},
    expected_total_updates=49000, physical_gpu=1, device='cuda:0',
    parameters=proof['parameters'], module_parameters=proof['module_parameters'],
    mechanism='independent original four-expert banks and image-level softmax; learnable gamma=0.1; simultaneous bidirectional P3 residual before unchanged fusion; detection loss only')
write_launch_provenance(dest, ROOT, manifest, cfg, launch)
print(json.dumps(dict(launch_metadata=str(dest / 'launch.json'), mode=launch['mode'])), flush=True)
