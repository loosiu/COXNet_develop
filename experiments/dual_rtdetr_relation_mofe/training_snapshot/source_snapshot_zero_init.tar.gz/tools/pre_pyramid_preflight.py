"""Prove old-state equality and real detection training at the new boundary."""
import argparse
import copy
import gc
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.runtime import load_config,seed_everything,make_dataset,make_loader,move_targets,resize_training_batch,warmup_factor,apply_optimizer_step
from dyfclt.training import build_optimizer,build_ema,set_learning_rate
from dyfclt.frequency_training import sha256,gate_statistics
from tools.pre_pyramid_protocol import ROOT,ORIGINALS,OLD_OUTPUTS,variant_paths,check_recipe,experiment_manifest,verify_tests,verify_originals

def fingerprints(model):
    return {n:hashlib.sha256(v.detach().cpu().contiguous().numpy().tobytes()).hexdigest() for n,v in model.state_dict().items()}

def original_fingerprints(variant):
    script='''import hashlib,json,torch
from pathlib import Path
from dyfclt.model import DyFCLT
from dyfclt.runtime import seed_everything
c=json.loads(Path("outputs/OUTPUT/config.json").read_text());seed_everything(c['seed']);m=DyFCLT(**c['model'])
print(json.dumps({'hashes':{n:hashlib.sha256(v.detach().cpu().contiguous().numpy().tobytes()).hexdigest() for n,v in m.state_dict().items()},'rng':torch.get_rng_state().tolist()}))
'''.replace('OUTPUT',OLD_OUTPUTS[variant])
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    out=subprocess.check_output([sys.executable,'-c',script],cwd=ORIGINALS[variant],env=env,text=True)
    return json.loads(out.splitlines()[-1])

def initial_proof(variant,cfg):
    check_recipe(variant,cfg);verify_originals();reference=original_fingerprints(variant)
    seed_everything(0);model=DyFCLT(**cfg['model']);hashes=fingerprints(model)
    assert hashes==reference['hashes'],'Moving the module changed initial parameters'
    assert torch.get_rng_state().tolist()==reference['rng'],'Initial RNG changed'
    proof={'variant':variant,'all_original_initial_tensors_equal':True,'shared_tensor_count':len(hashes),
           'CPU_rng_equal':True,'insertion_point':'projected_p3','original_initial_sha256':hashes}
    # Check E vs new B normal detector output at initialization, not only the module.
    if variant=='E':
        bcfg=load_config(variant_paths('B')['config']);seed_everything(0);base=DyFCLT(**bcfg['model']);base.eval();model.eval()
        for name,value in base.state_dict().items():assert torch.equal(value,model.state_dict()[name]),name
        rgb=torch.randn(2,3,128,160);thermal=torch.randn_like(rgb)
        with torch.no_grad():a,b=base(rgb,thermal),model(rgb,thermal)
        assert all(torch.equal(a[k],b[k]) for k in ['pred_logits','pred_boxes'])
        proof['new_E_initial_output_exact_new_B']=True;del base,a,b;gc.collect()
    (ROOT/f'artifacts/initialization_{variant}.json').write_text(json.dumps(proof,indent=2)+'\n')
    return model,proof

def main():
    p=argparse.ArgumentParser();p.add_argument('--variant',choices=['B','E'],required=True);p.add_argument('--cpu-only',action='store_true');args=p.parse_args()
    cfg=load_config(variant_paths(args.variant)['config']);model,proof=initial_proof(args.variant,cfg)
    proof.pop('original_initial_sha256');proof['source_sha256']=experiment_manifest()
    if args.cpu_only:
        (ROOT/f'artifacts/readiness_{args.variant}_cpu.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='source_sha256'}),flush=True);return
    verify_tests();assert torch.cuda.is_available() and torch.cuda.device_count()==1
    model.cuda().train();module=model.encoder.frequency_module;params=dict(module.named_parameters());base_names=[n for n in params if '.context.' not in n]
    before={n:p.detach().clone() for n,p in params.items()};optimizer=build_optimizer(model,cfg['train']);ema=build_ema(model,cfg['train'])
    ids={id(p) for g in optimizer.param_groups for p in g['params']};assert all(id(p) in ids for p in params.values())
    train=make_dataset(cfg,'train',training=True);val=make_dataset(cfg,'val');assert len(train)==4900 and len(val)==1225 and train.category_ids==val.category_ids==[0,1,2]
    criterion=build_criterion(3,**cfg['loss']).cuda();scaler=torch.cuda.amp.GradScaler(enabled=False);batches=iter(make_loader(train,2,0,True));steps=[]
    for index,size in enumerate([(448,576),(576,704),(512,640)]):
        rgb,t,targets=resize_training_batch(*next(batches),[size]);rgb,t,targets=rgb.cuda(),t.cuda(),move_targets(targets,'cuda:0')
        set_learning_rate(optimizer,cfg['train']['lr'],warmup_factor(index,2000,.001));optimizer.zero_grad(set_to_none=True);started=time.monotonic()
        out=model(rgb,t,targets,return_frequency_aux=True);losses=criterion(out,targets);loss=sum(losses.values());assert torch.isfinite(loss)
        assert not any('utility' in n or 'gain' in n or 'mask' in n for n in losses)
        loss.backward();grad={n:{'finite':p.grad is not None and bool(torch.isfinite(p.grad).all()),'abs_sum':float(p.grad.abs().sum()) if p.grad is not None else None} for n,p in params.items()}
        assert all(x['finite'] for x in grad.values());assert all(grad[n]['abs_sum']>0 for n in base_names)
        if args.variant=='E':
            for bank in ['rgb_from_thermal','thermal_from_rgb']:
                assert grad[bank+'.context.modulation.weight']['abs_sum']>0
                v=grad[bank+'.context.scan.in_proj.weight']['abs_sum'];assert v==0 if index==0 else v>0
        norm,applied=apply_optimizer_step(model,optimizer,scaler,.1,ema);assert applied and torch.isfinite(norm);torch.cuda.synchronize()
        row={'step':index+1,'image_size':list(size),'loss':float(loss.detach()),'grad_norm':float(norm),'seconds':time.monotonic()-started,'gradients':grad,'gate_statistics':gate_statistics(out['frequency_aux'])};steps.append(row)
        print(json.dumps({k:row[k] for k in ['step','image_size','loss','grad_norm','seconds']}),flush=True);del out,losses,loss
    changed={n:not torch.equal(p,before[n]) for n,p in params.items()};assert all(changed[n] for n in base_names)
    with torch.no_grad():
        r,t,_=next(iter(make_loader(val,2,0)));left,right=ema.module(r.cuda(),t.cuda()),ema.module(r.cuda(),t.cuda())
        assert all(torch.equal(left[k],right[k]) and torch.isfinite(left[k]).all() for k in ['pred_logits','pred_boxes'])
    proof.update(cpu_tests_passed=True,all_gradients_finite=True,all_base_parameters_updated=True,
                 optimizer_includes_all_module_parameters=True,EMA_eval_finite_repeatable=True,
                 module_tensors=len(params),changed=changed,steps=steps,
                 parameters=sum(p.numel() for p in model.parameters()),module_parameters=sum(p.numel() for p in module.parameters()),
                 physical_gpu=int(os.environ['EFG_GPU_INDEX']),gpu_uuid=os.environ['EFG_GPU_UUID'],
                 pretrained_sha256=sha256(ROOT/cfg['model']['pretrained']),input_sha256={s:sha256(cfg['data'][s]['ann_file']) for s in ['train','val']},
                 trained_A_B_E_checkpoint_loaded=False,AP_measured=False,production_training_launched=False)
    if args.variant=='E':proof['Mamba_scan_gradients_active_after_first_update']=True
    (ROOT/f'artifacts/verification_{args.variant}_gpu{proof["physical_gpu"]}.json').write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'verified':True,'variant':args.variant,'changed_tensors':sum(changed.values()),'total_tensors':len(params)}),flush=True)

if __name__=='__main__':main()
