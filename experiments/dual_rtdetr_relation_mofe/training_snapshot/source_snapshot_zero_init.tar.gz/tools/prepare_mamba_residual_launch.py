"""Freeze verified code/config/inputs before one fresh E-v2 launch."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from dyfclt.runtime import load_config
from dyfclt.frequency_training import source_manifest, sha256, validate_output_destination, write_launch_provenance
from tools.mamba_residual_preflight import check_recipe

cfg=load_config(ROOT/'configs/rgbtdroneperson_Ev2_seed0.yaml')
check_recipe(cfg)
proof=json.loads((ROOT/'artifacts/verification.json').read_text())
assert source_manifest(ROOT)==proof['source_sha256'], 'Source changed after GPU check'
for k in ['all_B_initial_tensors_bitwise_equal','B_module_initial_output_exact','torch_cpu_rng_equal',
          'cpu_tests_passed','optimizer_includes_all_module_parameters','finite_detection_gradients',
          'first_update_activates_SS2D_gradient','unchanged_B_parameters_updated','ema_eval_finite_repeatable']:
    assert proof[k],k
assert (ROOT/'artifacts/full_tests_exit_code.txt').read_text().strip()=='0'
assert sha256(ROOT/cfg['model']['pretrained'])==proof['pretrained_sha256']
for split in ['train','val']: assert sha256(cfg['data'][split]['ann_file'])==proof['input_sha256'][split]
assert os.environ['EFG_GPU_INDEX']=='0'
validate_output_destination(ROOT/cfg['train']['output_dir'])
dest=ROOT/'artifacts/training_launch_E_seed0_gpu0'
assert not (dest/'launch.json').exists(), 'Preserve earlier launch'
controller=dest/'run.sh'
controller_snapshot=dest/'controller_snapshot.sh'
with controller_snapshot.open('x') as handle: handle.write(controller.read_text())
launch=dict(started_utc=datetime.now(timezone.utc).isoformat(),variant='E',revision='E-v2',
    mode='fresh_B_preserving_Mamba_20_epochs',resolved_config=cfg,expected_total_updates=49000,
    trained_A_or_B_checkpoint_loaded=False,trained_E_checkpoint_loaded=False,
    physical_gpu=0,gpu_uuid=os.environ['EFG_GPU_UUID'],device='cuda:0',
    source_sha256=proof['source_sha256'],input_sha256=proof['input_sha256'],
    pretrained_sha256=proof['pretrained_sha256'],parameters=proof['parameters'],
    module_parameters=proof['module_parameters'],verification='artifacts/verification.json',
    controller_sha256=sha256(controller),controller_snapshot=str(controller_snapshot.relative_to(ROOT)),
    mechanism='B banks/router/gamma preserved; identity-initialized SS2D frequency input residual; P3 bidirectional before fusion; ordinary detection loss every batch')
write_launch_provenance(dest,ROOT,proof['source_sha256'],cfg,launch)
print(json.dumps(dict(launch=str(dest/'launch.json'),revision='E-v2')),flush=True)
