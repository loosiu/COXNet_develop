#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
(( $# == 2 )) || exit 2
variant="$1"
gpu="$2"
[[ "$variant:$gpu" == B:1 || "$variant:$gpu" == E:0 ]] || exit 2
export EFG_GPU_INDEX="$gpu" EFG_RUN_DIR="artifacts/training_launch_${variant}_pre_seed0_gpu${gpu}"
PYTHON_BIN=/home/viplab/anaconda3/envs/coxmamba/bin/python
exec 3>"/tmp/pre_pyramid_mofe_gpu${gpu}.lock"
flock -n 3
source tools/gpu_guard.sh
"$PYTHON_BIN" -u tools/pre_pyramid_preflight.py --variant "$variant" > "artifacts/preflight_${variant}_gpu${gpu}.log" 2>&1
"$PYTHON_BIN" -u tools/prepare_pre_pyramid_launch.py "$variant"
"$PYTHON_BIN" -u tools/train.py --config "configs/rgbtdroneperson_${variant}_pre_seed0.yaml" --device cuda:0
