"""Durable source-frozen B-after-F / E-after-G queues; fresh weights only."""
from datetime import datetime,timezone
import fcntl,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tools.pre_pyramid_protocol import variant_paths,TARGET_GPU,verify_manifest,predecessor_state,check_recipe,verify_tests
from dyfclt.runtime import load_config

def main(directory):
    os.chdir(ROOT);dest=Path(directory).resolve();owned=False;active=None
    try:
        with (dest/'controller.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            if (dest/'controller_pid.txt').exists():raise FileExistsError('Queue already owned; preserve state')
            owned=True;m=json.loads((dest/'queue_manifest.json').read_text());v=m['variant'];gpu=TARGET_GPU[v];paths=variant_paths(v)
            if m['physical_gpu']!=gpu:raise ValueError('Wrong authorized GPU')
            old=json.loads((Path(m['predecessor_run'])/'launch.json').read_text())
            if old.get('variant')!=({'B':'F','E':'G'}[v]) or old.get('physical_gpu')!=gpu or old.get('revision')!='v4':
                raise ValueError('Wrong predecessor experiment')
            verify_manifest(ROOT,m);verify_tests();check_recipe(v,load_config(paths['config']))
            (dest/'controller_pid.txt').write_text(str(os.getpid()));state={'variant':v,'physical_gpu':gpu,'state':'waiting_predecessor','predecessor':m['predecessor_run'],'fresh_training':True,'trained_predecessor_checkpoint_loaded':False}
            def write():
                state['observed_utc']=datetime.now(timezone.utc).isoformat();tmp=dest/'status.json.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(dest/'status.json')
            def stop(signum,frame):
                if active is not None:
                    try:os.killpg(active.pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                state['state']='stopped';write();raise SystemExit(128+signum)
            signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop);write()
            while True:
                previous=predecessor_state(m['predecessor_run']);state['predecessor_status']=previous;write()
                if previous['state']=='failed':raise RuntimeError(previous['reason'])
                if previous['state']=='succeeded':break
                time.sleep(20)
            verify_manifest(ROOT,m);verify_tests();check_recipe(v,load_config(paths['config']))
            run=paths['run'];run.mkdir(parents=True,exist_ok=True)
            if any((run/n).exists() for n in ['launch.json','exit_code.txt','child_process_group.txt']):raise FileExistsError('Production run already exists')
            state['state']='preflight_then_training';write()
            with (run/'console.log').open('x') as log:
                active=subprocess.Popen(['bash','tools/train_pre_pyramid_gpu.sh',v,str(gpu)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                (run/'child_process_group.txt').write_text(str(active.pid));(run/'controller_pid.txt').write_text(str(active.pid));state['child_process_group']=active.pid;write()
                code=active.wait();active=None
            (run/'exit_code.txt').write_text(str(code));completion=predecessor_state(run);state['completion']=completion
            if completion['state']!='succeeded':raise RuntimeError(completion.get('reason','Launch did not complete'))
            state['state']='complete';write();(dest/'exit_code.txt').write_text('0')
    except Exception as error:
        if owned:
            (dest/'status.json').write_text(json.dumps({'state':'failed','reason':str(error)},indent=2)+'\n');(dest/'exit_code.txt').write_text('1')
        raise

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit(2)
    main(sys.argv[1])
