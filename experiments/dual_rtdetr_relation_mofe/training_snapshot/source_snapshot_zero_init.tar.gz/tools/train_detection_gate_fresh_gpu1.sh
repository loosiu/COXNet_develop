#!/usr/bin/env bash
# Explicit mode only; preserve other workloads and all established GPU-1 locks.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
PYTHON_BIN="${PYTHON_BIN:-/home/viplab/anaconda3/envs/coxmamba/bin/python}"
exec 9>/tmp/dyfclt_gpu1.lock
flock -n 9
exec 8>/tmp/coxnet_oepc_gpu1.lock
flock -n 8
exec 7>/tmp/coxnet_dwt_dfca_gpu1.lock
flock -n 7
exec 6>/tmp/trpc_gpu1.lock
flock -n 6
exec 5>/tmp/coxnet_icbfc_gpu1.lock
flock -n 5
exec 4>/tmp/yolox_auair_s_1280_gpu1.lock
flock -n 4
FREQUENCY_GPU_UUID="$(nvidia-smi -i 1 --query-gpu=uuid --format=csv,noheader)"
FREQUENCY_GPU_MEMORY="$(nvidia-smi -i 1 --query-gpu=memory.used --format=csv,noheader,nounits)"
FREQUENCY_GPU_JOBS="$(nvidia-smi --query-compute-apps=pid,gpu_uuid --format=csv,noheader)"
if (( FREQUENCY_GPU_MEMORY > 1000 )) || [[ "$FREQUENCY_GPU_JOBS" == *"$FREQUENCY_GPU_UUID"* ]]; then
    echo 'Physical GPU 1 is occupied; refusing overlap.' >&2
    exit 1
fi
export FREQUENCY_GPU_UUID CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/frequency_utility_matplotlib
"$PYTHON_BIN" - <<'PY'
import os,subprocess,torch
assert torch.cuda.device_count()==1
probe=torch.zeros(1,device='cuda:0')
rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).splitlines()
actual=[row.split(',')[1].strip() for row in rows if int(row.split(',')[0])==os.getpid()]
assert actual==[os.environ['FREQUENCY_GPU_UUID']],actual
PY
if (( $# == 0 )); then
    "$PYTHON_BIN" -u artifacts/prepare_fresh_launch.py
fi
"$PYTHON_BIN" -u tools/train.py --config configs/rgbtdroneperson_detection_gate_fresh.yaml --device cuda:0 "$@"
