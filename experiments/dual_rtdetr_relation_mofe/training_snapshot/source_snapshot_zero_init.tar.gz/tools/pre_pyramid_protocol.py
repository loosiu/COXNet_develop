"""Strict recipe/provenance/completion checks for fresh pre-pyramid B/E."""
import copy
import json
import os
from pathlib import Path
import torch
from dyfclt.frequency_training import source_manifest, sha256

ROOT=Path(__file__).resolve().parents[1]
ORIGINALS={'B':Path('/data/siwoo/DualRTDETR-Residual-MoFE'),
           'E':Path('/data/siwoo/DualRTDETR-Residual-Mamba-MoFE')}
OLD_OUTPUTS={'B':'rgbtdroneperson_residual_mofe_seed0','E':'rgbtdroneperson_Ev2_seed0'}
TARGET_GPU={'B':1,'E':0}

def variant_paths(variant):
    if variant not in TARGET_GPU:raise ValueError('Only B/E reruns are authorized')
    return {'config':ROOT/f'configs/rgbtdroneperson_{variant}_pre_seed0.yaml',
            'run':ROOT/f'artifacts/training_launch_{variant}_pre_seed0_gpu{TARGET_GPU[variant]}',
            'output':ROOT/f'outputs/rgbtdroneperson_{variant}_pre_seed0'}

def experiment_manifest(root=ROOT):
    root=Path(root);result=source_manifest(root)
    for p in sorted((root/'tests').rglob('*.py')):result[str(p.relative_to(root))]=sha256(p)
    return result

def check_recipe(variant,cfg):
    variant_paths(variant)
    previous=json.loads((ORIGINALS[variant]/'outputs'/OLD_OUTPUTS[variant]/'config.json').read_text())
    current=copy.deepcopy(cfg)
    if current['model']['frequency_utility'].pop('insertion_point',None)!='projected_p3':
        raise ValueError('MoFE must be inserted at projected P3')
    for x in [current,previous]:x['train'].pop('output_dir',None)
    if current!=previous:raise ValueError('Only insertion position/output may differ from saved original recipe')
    if cfg['train']['output_dir']!=str(variant_paths(variant)['output'].relative_to(ROOT)):
        raise ValueError('Unexpected fresh output destination')
    return True

def verify_manifest(root,manifest):
    if experiment_manifest(root)!=manifest['source_sha256']:raise ValueError('Source changed after verification/enqueue')
    for path,expected in manifest['frozen_inputs'].items():
        if sha256(path)!=expected:raise ValueError('Frozen input changed: '+path)

def frozen_inputs(cfg):
    files=[ROOT/cfg['model']['pretrained'],ROOT/'artifacts/full_tests.log',
           ROOT/'artifacts/full_tests_exit_code.txt',ROOT/'artifacts/test_certificate.json',
           ROOT/'artifacts/original_projects_frozen.json']
    files.extend(Path(cfg['data'][s]['ann_file']) for s in ['train','val'])
    return {str(p):sha256(p) for p in files}

def verify_tests():
    cert=json.loads((ROOT/'artifacts/test_certificate.json').read_text())
    if (ROOT/'artifacts/full_tests_exit_code.txt').read_text().strip()!='0':raise ValueError('CPU tests failed')
    if cert['source_sha256']!=experiment_manifest(ROOT) or cert['log_sha256']!=sha256(ROOT/'artifacts/full_tests.log'):
        raise ValueError('Test certificate is stale')
    return cert

def verify_originals():
    for path,expected in json.loads((ROOT/'artifacts/original_projects_frozen.json').read_text()).items():
        if sha256(path)!=expected:raise ValueError('Original experiment source changed: '+path)

def predecessor_state(run):
    run=Path(run);terminal=run/'exit_code.txt'
    if not terminal.exists():
        pid_path=run/'controller_pid.txt'
        if pid_path.exists():
            try:os.kill(int(pid_path.read_text()),0)
            except ProcessLookupError:return {'state':'failed','reason':'Predecessor controller disappeared without exit status'}
        return {'state':'waiting','reason':'No terminal status'}
    try:
        code=int(terminal.read_text())
        if code!=0:return {'state':'failed','reason':f'Predecessor exit {code}'}
        launch=json.loads((run/'launch.json').read_text());cfg=launch['resolved_config'];out=Path(cfg['train']['output_dir'])
        if not out.is_absolute():out=run.parents[1]/out
        if not all((out/f).is_file() for f in ['last.pth','best.pth']):return {'state':'failed','reason':'Missing completed checkpoints'}
        checkpoint=torch.load(out/'last.pth',map_location='cpu',weights_only=False)
        if (checkpoint.get('partial_epoch') or checkpoint['epoch']+1!=cfg['train']['epochs']
            or checkpoint['global_step']!=launch['expected_total_updates'] or checkpoint['config']!=cfg):
            return {'state':'failed','reason':'Checkpoint does not prove completed requested training'}
        return {'state':'succeeded','completed_epochs':checkpoint['epoch']+1,'global_step':checkpoint['global_step']}
    except (OSError,ValueError,KeyError,RuntimeError) as error:return {'state':'failed','reason':str(error)}
