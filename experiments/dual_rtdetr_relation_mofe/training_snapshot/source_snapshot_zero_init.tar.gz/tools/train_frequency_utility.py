#!/usr/bin/env python3
"""A continuation, detection-only D2 or legacy Beta utility training; explicit bounded smoke."""
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, build_ema, set_learning_rate, optimizer_summary
from dyfclt.frequency_training import (initialize_from_a, training_step, validate_config,
    validate_paired_recipes, source_manifest, verify_training_certificate,
    validate_output_destination, write_launch_provenance, sha256, validate_training_pair)
from dyfclt.utility_probe import UtilityTeacher, UtilityProbeSampler
from dyfclt.runtime import (load_config, seed_everything, make_dataset, make_loader,
    move_targets, warmup_factor, resize_training_batch, load_checkpoint, save_checkpoint,
    checkpoint_metric, evaluate)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='configs/rgbtdroneperson_frequency_utility.yaml')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--resume')
    parser.add_argument('--output-dir')
    parser.add_argument('--workers', type=int)
    parser.add_argument('--smoke-steps', type=int, default=0)
    parser.add_argument('--train', action='store_true')
    parser.add_argument('--certificate', help='Required only for legacy Beta utility training: successful single-cell preflight JSON')
    parser.add_argument('--no-validation', action='store_true')
    args = parser.parse_args()
    if args.train == (args.smoke_steps > 0):
        parser.error('Choose exactly one of --train or --smoke-steps N; smoke does not report performance')
    if args.smoke_steps < 0: parser.error('smoke-steps must be nonnegative')
    config = load_config(args.config)
    enabled = validate_config(config)
    frequency_enabled = config['model'].get('frequency_utility') is not None
    validate_training_pair(config, ROOT)
    # Validate the actual prepared recipe before harmless output/worker overrides.
    certificate = None
    if enabled and args.train:
        if not args.certificate: raise ValueError('Long D training requires --certificate from tools/frequency_preflight.py')
        certificate = verify_training_certificate(args.certificate, config, ROOT)
    if args.workers is not None: config['train']['workers'] = args.workers
    if args.output_dir is not None: config['train']['output_dir'] = args.output_dir
    settings, utility = config['train'], config['utility']
    output = Path(settings['output_dir']).resolve()
    if not args.resume: validate_output_destination(output)
    resume = torch.load(args.resume, map_location='cpu', weights_only=False) if args.resume else None
    if resume is not None:
        if resume.get('partial_epoch'): raise ValueError('Partial smoke checkpoint cannot resume as a completed epoch')
        old = resume['config']
        current, previous = json.loads(json.dumps(config)), json.loads(json.dumps(old))
        for cfg in [current, previous]:
            cfg['train'].pop('output_dir'); cfg['train'].pop('workers')
        if current != previous: raise ValueError('Resume architecture/recipe differs from saved experiment')
        validate_output_destination(output, args.resume, old)
        if resume['epoch']+1 >= settings['epochs']:
            raise ValueError('Resume checkpoint has already exhausted the configured epoch budget')
    seed_everything(config['seed'])
    device = torch.device(args.device)
    train_data, val_data = make_dataset(config, 'train', training=True), make_dataset(config, 'val')
    if train_data.category_ids != val_data.category_ids or len(train_data.category_ids) != config['model']['num_classes']:
        raise ValueError('Model/train/validation category mappings differ')
    train_loader = make_loader(train_data, settings['batch_size'], settings['workers'], training=True)
    val_loader = make_loader(val_data, settings['batch_size'], settings['workers'])
    model_options = dict(config['model']); model_options['pretrained'] = False
    model = DyFCLT(**model_options).to(device)
    initialization = (initialize_from_a(model, config['initialization']['checkpoint'], config['initialization']['weights'])
                      if resume is None else resume['initialization'])
    if initialization['category_ids'] != train_data.category_ids: raise ValueError('A checkpoint category mapping differs')
    if certificate and initialization['checkpoint_sha256'] != certificate['initialization']['checkpoint_sha256']:
        raise ValueError('A checkpoint differs from the preflight certificate')
    criterion = build_criterion(config['model']['num_classes'], **config['loss']).to(device)
    optimizer, ema = build_optimizer(model, settings), build_ema(model, settings)
    teacher = UtilityTeacher(model, utility['teacher_decay']) if enabled else None
    sampler = UtilityProbeSampler(config['seed'], utility['gt_probability']) if enabled else None
    scaler = torch.cuda.amp.GradScaler(enabled=bool(settings['amp'] and device.type == 'cuda'))
    epoch_start, step, attempted, best = 0, 0, 0, -math.inf
    if resume is not None:
        load_checkpoint(resume, model, optimizer, scaler, restore_rng=True, ema=ema)
        if resume['category_ids'] != train_data.category_ids: raise ValueError('Resume category mapping differs')
        if enabled:
            teacher.load_state_dict(resume['utility_teacher']); sampler.load_state_dict(resume['probe_sampler'])
            if teacher.updates != resume['global_step']: raise ValueError('Utility EMA update count differs on resume')
        epoch_start, step, attempted, best = resume['epoch']+1, resume['global_step'], resume['attempted_batches'], resume['best_ap']
    output.mkdir(parents=True, exist_ok=True)
    manifest = source_manifest(ROOT)
    launch = dict(started_utc=datetime.now(timezone.utc).isoformat(), mode='smoke' if args.smoke_steps else 'full_training',
                  resolved_config=config, initialization=initialization, source_sha256=manifest,
                  additional_training_budget=settings['epochs'], utility_teacher_decay=utility['teacher_decay'] if enabled else None,
                  evaluation_ema=settings['ema'], explicit_resume=bool(args.resume), device=str(device),
                  resume_checkpoint=str(Path(args.resume).resolve()) if args.resume else None,
                  resume_checkpoint_sha256=sha256(args.resume) if args.resume else None)
    write_launch_provenance(output, ROOT, manifest, config, launch)
    print(json.dumps(dict(parameters=sum(p.numel() for p in model.parameters()), seed=config['seed'], batch_size=settings['batch_size'],
                          initialization=initialization, optimizer_groups=optimizer_summary(optimizer), output_dir=str(output),
                          mode=launch['mode'], frequency_enabled=frequency_enabled, utility_enabled=enabled)), flush=True)

    def extra():
        result = dict(initialization=initialization, attempted_batches=attempted)
        if enabled: result.update(utility_teacher=teacher.state_dict(), probe_sampler=sampler.state_dict())
        return result

    local_steps, overflows = 0, 0
    for epoch in range(epoch_start, settings['epochs']):
        started = time.monotonic()
        for batch_index, (rgb, thermal, targets) in enumerate(train_loader):
            rgb, thermal, targets = resize_training_batch(rgb, thermal, targets, settings.get('resize_sizes'))
            batch = rgb.to(device), thermal.to(device), move_targets(targets, device)
            factor = warmup_factor(step, settings['warmup_steps'], settings['warmup_factor'])
            set_learning_rate(optimizer, settings['lr'], factor)
            do_probe = enabled and attempted % utility['probe_every'] == 0
            attempted += 1
            record = training_step(model, teacher, ema, sampler, criterion, optimizer, scaler, batch, utility,
                                   epoch+batch_index/len(train_loader), do_probe=do_probe,
                                   check_noop=enabled and step == 0, max_grad_norm=settings['clip_grad_norm'])
            if not record['applied']:
                overflows += 1
                print(json.dumps(dict(amp_overflow=True, attempted_batch=attempted, loss_scale=scaler.get_scale())), flush=True)
                if overflows >= 16: raise FloatingPointError('Repeated AMP overflow; stopped without updating either EMA')
                continue
            overflows = 0
            step += 1; local_steps += 1
            if batch_index % 20 == 0 or do_probe:
                record.update(epoch=epoch+1, step=step, attempted_batches=attempted, lr=settings['lr']*factor,
                              evaluation_ema_updates=ema.updates if ema else None,
                              utility_teacher_updates=teacher.updates if teacher else None)
                line = json.dumps(record, allow_nan=False)
                print(line, flush=True)
                with (output/'train.jsonl').open('a') as handle: handle.write(line+'\n')
            if args.smoke_steps and local_steps >= args.smoke_steps:
                save_checkpoint(output/'debug.pth', model, optimizer, scaler, config, epoch-1, step, best,
                                train_data.category_ids, partial_epoch=True, ema=ema, extra_state=extra())
                print('Bounded smoke complete; debug.pth is a partial epoch and no AP improvement is claimed.', flush=True)
                return
        metrics = (evaluate(ema.module if ema else model, val_loader, device, config['data']['val']['ann_file'],
                            train_data.category_ids, output/'validation', protocol=config['evaluation']['protocol'])
                   if not args.no_validation else None)
        is_best = metrics is not None and checkpoint_metric(metrics, config) > best
        if is_best: best = checkpoint_metric(metrics, config)
        save_checkpoint(output/'last.pth', model, optimizer, scaler, config, epoch, step, best,
                        train_data.category_ids, ema=ema, extra_state=extra())
        if is_best:
            save_checkpoint(output/'best.pth', model, optimizer, scaler, config, epoch, step, best,
                            train_data.category_ids, ema=ema, extra_state=extra())
        print(json.dumps(dict(epoch=epoch+1, seconds=time.monotonic()-started, validation=metrics,
                              evaluation_weights='ema' if ema else 'model', ema_updates=ema.updates if ema else None)), flush=True)


if __name__ == '__main__': main()
