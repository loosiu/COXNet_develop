#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
if (( $# != 0 )); then
    echo 'Fresh verified production recipe accepts no overrides.' >&2
    exit 2
fi
source tools/gpu1_guard.sh
PYTHON_BIN="${PYTHON_BIN:-/home/viplab/anaconda3/envs/coxmamba/bin/python}"
"$PYTHON_BIN" -u tools/prepare_residual_mofe_launch.py
"$PYTHON_BIN" -u tools/train.py --config configs/rgbtdroneperson_residual_mofe.yaml --device cuda:0
