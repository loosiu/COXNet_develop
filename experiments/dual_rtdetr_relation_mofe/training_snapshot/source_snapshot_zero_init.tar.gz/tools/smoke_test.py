#!/usr/bin/env python3
"""One real paired batch, optimizer step, inference, optional partial COCO evaluation."""
import argparse
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, build_ema, set_learning_rate, optimizer_summary
from dyfclt.runtime import load_config, seed_everything, make_dataset, make_loader, move_targets, evaluate, apply_optimizer_step, warmup_factor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default='configs/rgbtdroneperson.yaml')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--batch-size', type=int, default=1)
    parser.add_argument('--no-pretrained', action='store_true')
    parser.add_argument('--amp', action='store_true')
    parser.add_argument('--evaluate', action='store_true')
    parser.add_argument('--output-dir', default='artifacts/smoke')
    args = parser.parse_args()
    torch.set_num_threads(4)
    config = load_config(args.config)
    seed_everything(config.get('seed', 0))
    device = torch.device(args.device)
    kwargs = dict(config['model'])
    if args.no_pretrained:
        kwargs['pretrained'] = False
    model = DyFCLT(**kwargs).to(device).train()
    criterion = build_criterion(config['model']['num_classes'], **config.get('loss', {})).to(device)
    data = make_dataset(config, 'train', training=True)
    rgb, thermal, targets = next(iter(make_loader(data, args.batch_size, 0)))
    targets = move_targets(targets, device)
    optimizer = build_optimizer(model, config['train'])
    ema = build_ema(model, config['train'])
    set_learning_rate(optimizer, config['train']['lr'], warmup_factor(0, config['train']['warmup_steps'], config['train']['warmup_factor']))
    if device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats(device)
    start = time.time()
    amp = args.amp and device.type == 'cuda'
    scaler = torch.cuda.amp.GradScaler(enabled=amp)
    for overflow_retries in range(16):
        optimizer.zero_grad(set_to_none=True)
        with torch.cuda.amp.autocast(enabled=amp):
            outputs = model(rgb.to(device), thermal.to(device), targets)
            losses = criterion(outputs, targets)
            loss = sum(losses.values())
        assert torch.isfinite(loss), 'nonfinite loss'
        scaler.scale(loss).backward()
        grad_norm, applied = apply_optimizer_step(model, optimizer, scaler, config['train']['clip_grad_norm'], ema=ema)
        if applied:
            break
    else:
        raise FloatingPointError('AMP failed to recover after 16 loss-scale reductions')
    bad = [n for n,p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
    assert not bad, f'nonfinite gradients: {bad[:8]}'
    boundary_gradients = {n: float(p.grad.norm()) for n,p in model.named_parameters()
                          if ('increment' in n or 'band_logits' in n) and p.requires_grad and p.grad is not None}
    if model.use_dfca:
        assert boundary_gradients and all(v > 0 for v in boundary_gradients.values()), boundary_gradients
    else:
        assert not boundary_gradients
    assert ('loss_mask' in losses) == model.use_sse
    inference_model = ema.module if ema else model
    inference_model.eval()
    with torch.no_grad():
        prediction = inference_model(rgb.to(device), thermal.to(device))
    assert prediction['pred_logits'].shape == (args.batch_size,config['model']['num_queries'],config['model']['num_classes'])
    assert torch.isfinite(prediction['pred_boxes']).all()
    report = dict(device=str(device), torch=torch.__version__, pretrained=kwargs.get('pretrained'), amp=amp,
                  image_shape=list(rgb.shape), classes=data.category_names,
                  model_config=kwargs, architecture=model.architecture, modules=dict(dfca=model.use_dfca, sse=model.use_sse, fref=model.use_fref), optimizer_groups=optimizer_summary(optimizer),
                  ema_updates=ema.updates if ema else None, evaluation_weights='ema' if ema else 'model',
                  parameters=sum(p.numel() for p in model.parameters()), loss=float(loss.detach()),
                  losses={k:float(v.detach()) for k,v in losses.items()}, gradient_norm=float(grad_norm),
                  boundary_gradients=boundary_gradients, pred_shape=list(prediction['pred_logits'].shape),
                  seconds=time.time()-start, optimizer_steps=1, amp_overflow_retries=overflow_retries, loss_scale=scaler.get_scale(),
                  peak_memory_mib=torch.cuda.max_memory_allocated(device)/2**20 if device.type=='cuda' else None)
    if args.evaluate:
        val = make_dataset(config, 'val')
        report['partial_evaluation'] = evaluate(inference_model, make_loader(val,args.batch_size,0), device,
                    config['data']['val']['ann_file'], val.category_ids, Path(args.output_dir)/'evaluation', max_batches=1,
                    protocol=config.get('evaluation', {}).get('protocol', 'coco'))
    destination = Path(args.output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    main()
