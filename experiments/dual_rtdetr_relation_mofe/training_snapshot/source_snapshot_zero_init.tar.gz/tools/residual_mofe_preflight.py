"""Two real-data GPU steps; production restarts fresh from the matched seed."""
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, build_ema, set_learning_rate
from dyfclt.runtime import (load_config, seed_everything, make_dataset, make_loader, move_targets,
                            resize_training_batch, warmup_factor, apply_optimizer_step)
from dyfclt.frequency_training import source_manifest, sha256, gate_statistics
from tools.train import validate_detection_config


def fingerprints(model):
    return {name: hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
            for name, value in model.state_dict().items()}


def main():
    cfg = load_config(ROOT / 'configs/rgbtdroneperson_residual_mofe.yaml')
    assert validate_detection_config(cfg)
    original = json.loads(Path('/data/siwoo/DyFCLT/outputs/rgbtdroneperson_dual_rtdetr_seed0/config.json').read_text())
    common = copy.deepcopy(cfg)
    common['model'].pop('frequency_utility')
    for config in [original, common]: config['train'].pop('output_dir')
    assert common == original
    assert (ROOT / 'artifacts/full_tests_exit_code.txt').read_text().strip() == '0'
    old_root = Path('/data/siwoo/DualRTDETR-S3AM-MoFE')
    assert sha256(ROOT / 'dyfclt/s3am_mofe.py') == sha256(old_root / 'dyfclt/s3am_mofe.py')
    assert sha256(ROOT / 'dyfclt/frequency_utility.py') == sha256(old_root / 'dyfclt/frequency_utility.py')
    seed_everything(0)
    a = DyFCLT(**original['model'])
    a_hash, a_rng = fingerprints(a), torch.get_rng_state().clone()
    del a
    gc.collect()
    seed_everything(0)
    old_options = copy.deepcopy(cfg['model'])
    old_options['frequency_utility'] = dict(gate_mode='s3am_mofe', dim=64, expert_hidden=64, router_hidden=64)
    old = DyFCLT(**old_options)
    old_hash = fingerprints(old.encoder.frequency_module)
    del old
    gc.collect()
    seed_everything(0)
    model = DyFCLT(**cfg['model'])
    new_hash = fingerprints(model)
    assert all(new_hash[name] == digest for name, digest in a_hash.items())
    assert torch.equal(a_rng, torch.get_rng_state())
    module = model.encoder.frequency_module
    assert fingerprints(module.rgb_from_thermal) == old_hash
    rgb_ids = {id(p) for p in module.rgb_from_thermal.parameters()}
    thermal_ids = {id(p) for p in module.thermal_from_rgb.parameters()}
    assert rgb_ids.isdisjoint(thermal_ids)
    init = dict(shared_tensor_count=len(a_hash), common_A_sha256=a_hash,
                original_mofe_bank_initial_sha256=old_hash, shared_initial_tensors_bitwise_equal=True,
                original_RGB_bank_all_initial_tensors_equal=True, direction_parameter_banks_independent=True,
                torch_cpu_rng_equal=True)
    (ROOT / 'artifacts/initialization_verification.json').write_text(json.dumps(init, indent=2))
    params_count = sum(p.numel() for p in model.parameters())
    module_count = sum(p.numel() for p in module.parameters())
    model.to('cuda:0').train()
    train, val = make_dataset(cfg, 'train', training=True), make_dataset(cfg, 'val')
    assert len(train) == 4900 and len(val) == 1225 and train.category_ids == val.category_ids == [0, 1, 2]
    criterion = build_criterion(3, **cfg['loss']).to('cuda:0')
    optimizer, ema = build_optimizer(model, cfg['train']), build_ema(model, cfg['train'])
    scaler = torch.cuda.amp.GradScaler(enabled=False)
    params = dict(module.named_parameters())
    before = {name: p.detach().clone() for name, p in params.items()}
    ids = {id(p) for group in optimizer.param_groups for p in group['params']}
    assert all(id(p) in ids for p in params.values())
    iterator = iter(make_loader(train, batch_size=2, workers=0, training=True))
    steps = []
    torch.cuda.reset_peak_memory_stats()
    for index, size in enumerate([(448, 576), (576, 704)]):
        rgb, thermal, targets = resize_training_batch(*next(iterator), [size])
        rgb, thermal, targets = rgb.cuda(), thermal.cuda(), move_targets(targets, 'cuda:0')
        set_learning_rate(optimizer, cfg['train']['lr'], warmup_factor(index, 2000, .001))
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        started = time.monotonic()
        outputs = model(rgb, thermal, targets, return_frequency_aux=True)
        losses = criterion(outputs, targets)
        assert not any('kl' in name or 'utility' in name or 'mask' in name for name in losses)
        loss = sum(losses.values())
        assert torch.isfinite(loss)
        loss.backward()
        gradients = {name: dict(finite=p.grad is not None and bool(torch.isfinite(p.grad).all()),
                                nonzero=p.grad is not None and float(p.grad.abs().sum()) > 0,
                                abs_sum=float(p.grad.abs().sum()) if p.grad is not None else None)
                     for name, p in params.items()}
        assert all(row['finite'] and row['nonzero'] for row in gradients.values())
        norm, applied = apply_optimizer_step(model, optimizer, scaler, .1, ema)
        assert applied and torch.isfinite(norm)
        torch.cuda.synchronize()
        steps.append(dict(step=index+1, image_size=list(size), loss=float(loss.detach()),
                          grad_norm=float(norm), seconds=time.monotonic()-started,
                          module_gradients=gradients, loss_terms=list(losses),
                          gamma_after_step=[float(module.gamma_rgb.detach()), float(module.gamma_thermal.detach())],
                          gate_statistics=gate_statistics(outputs['frequency_aux'])))
        print(json.dumps(dict(smoke_step=index+1, loss=float(loss.detach()), seconds=steps[-1]['seconds'])), flush=True)
        del outputs, losses, loss
    changed = {name: not torch.equal(p, before[name]) for name, p in params.items()}
    assert all(changed.values()) and ema.updates == 2
    with torch.no_grad():
        vrgb, vthermal, _ = next(iter(make_loader(val, batch_size=2, workers=0)))
        prediction = ema.module(vrgb.cuda(), vthermal.cuda())
        repeated = ema.module(vrgb.cuda(), vthermal.cuda())
        assert all(torch.equal(prediction[k], repeated[k]) for k in ['pred_logits', 'pred_boxes'])
        assert torch.isfinite(prediction['pred_logits']).all() and torch.isfinite(prediction['pred_boxes']).all()
    proof = dict(shared_initial_tensors_bitwise_equal=True, shared_tensor_count=len(a_hash),
        original_RGB_bank_all_initial_tensors_equal=True, torch_cpu_rng_equal=True,
        original_expert_router_source_unchanged=True, direction_parameter_banks_independent=True,
        all_module_parameters_gradient_and_update_verified=True, module_parameter_tensors=len(params),
        updated_module_parameter_tensors=changed, ema_eval_finite=True, ema_smoke_images=2,
        ema_eval_repeatable=True, detection_only_gamma_gradient_verified=True,
        cpu_tests_passed=True, cpu_tests_log='artifacts/full_tests.log',
        parameters=params_count, module_parameters=module_count, actual_GPU_steps=steps,
        peak_memory_allocated_bytes=torch.cuda.max_memory_allocated(),
        peak_memory_reserved_bytes=torch.cuda.max_memory_reserved(),
        pretrained_sha256=sha256(ROOT / cfg['model']['pretrained']),
        input_sha256={split: sha256(cfg['data'][split]['ann_file']) for split in ['train', 'val']},
        source_sha256=source_manifest(ROOT), production_training_launched=False, AP_measured=False,
        recipe_matches_A_except_module_and_output=True, trained_A_checkpoint_loaded=False,
        residual_scale_initial=.1, gamma_after_two_steps=[float(module.gamma_rgb.detach()), float(module.gamma_thermal.detach())])
    (ROOT / 'artifacts/verification.json').write_text(json.dumps(proof, indent=2, allow_nan=False))
    print(json.dumps({key: proof[key] for key in ['parameters', 'module_parameters', 'module_parameter_tensors',
          'peak_memory_allocated_bytes', 'peak_memory_reserved_bytes', 'gamma_after_two_steps', 'ema_eval_finite']}, indent=2), flush=True)


if __name__ == '__main__': main()
