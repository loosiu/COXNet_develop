#!/usr/bin/env bash
# Source with EFG_GPU_INDEX=0 or 1; locks survive in the training child.
[[ "$EFG_GPU_INDEX" == 0 || "$EFG_GPU_INDEX" == 1 ]] || exit 2
exec 9>"/tmp/dyfclt_gpu${EFG_GPU_INDEX}.lock"
flock -n 9
exec 8>"/tmp/coxnet_oepc_gpu${EFG_GPU_INDEX}.lock"
flock -n 8
exec 7>"/tmp/coxnet_dwt_dfca_gpu${EFG_GPU_INDEX}.lock"
flock -n 7
exec 6>"/tmp/trpc_gpu${EFG_GPU_INDEX}.lock"
flock -n 6
exec 5>"/tmp/coxnet_icbfc_gpu${EFG_GPU_INDEX}.lock"
flock -n 5
exec 4>"/tmp/yolox_auair_s_1280_gpu${EFG_GPU_INDEX}.lock"
flock -n 4
EFG_GPU_UUID="$(nvidia-smi -i "$EFG_GPU_INDEX" --query-gpu=uuid --format=csv,noheader)"
EFG_GPU_MEMORY="$(nvidia-smi -i "$EFG_GPU_INDEX" --query-gpu=memory.used --format=csv,noheader,nounits)"
EFG_GPU_JOBS="$(nvidia-smi --query-compute-apps=pid,gpu_uuid --format=csv,noheader)"
if (( EFG_GPU_MEMORY > 1000 )) || [[ "$EFG_GPU_JOBS" == *"$EFG_GPU_UUID"* ]]; then
    echo "Physical GPU $EFG_GPU_INDEX occupied; refusing overlap." >&2
    exit 1
fi
# PyTorch 1.13's visible-device parser rejects UUID strings; retain numeric
# selection and verify the actual process UUID immediately below.
export EFG_GPU_INDEX EFG_GPU_UUID CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="$EFG_GPU_INDEX"
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/efg_mofe_matplotlib TRANSFORMERS_CACHE=/tmp/efg_mofe_hf_cache
"${PYTHON_BIN:-/home/viplab/anaconda3/envs/coxmamba/bin/python}" - <<'PY_CHECK'
import json,os,subprocess,torch
from pathlib import Path
assert torch.cuda.device_count()==1
probe=torch.zeros(1,device='cuda:0')
rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).splitlines()
actual=[row.split(',')[1].strip() for row in rows if int(row.split(',')[0])==os.getpid()]
assert actual==[os.environ['EFG_GPU_UUID']],actual
dest=Path(os.environ.get('EFG_RUN_DIR','artifacts'))
dest.mkdir(parents=True,exist_ok=True)
(dest/'physical_gpu_mapping.json').write_text(json.dumps(dict(physical_gpu=int(os.environ['EFG_GPU_INDEX']),
    uuid=actual[0],process_device='cuda:0',mapping_verified=True),indent=2))
PY_CHECK
