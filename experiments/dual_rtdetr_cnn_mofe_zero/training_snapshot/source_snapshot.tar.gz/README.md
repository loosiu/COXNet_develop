# Dual-stream RT-DETR + CNN spatial MoFE, gamma 0 초기화

현재 주 실험은 SWT의 네 CNN expert와 위치별 router를 사용하고 양방향 residual로 원래 특징을 보완한다. MoFE에는 추가 Q/K/V, FFT correlation, cross-attention을 넣지 않는다. RT-DETR의 기존 attention 및 detection loss는 유지한다. 관계 기반 및 이전 spatial 실험은 원래 경로에 보존한다.

```text
RGB/T 독립 backbone → 각 HybridEncoder의 공통 채널 projection
→ 원래 RGB/T projected P3
→ 각 방향의 stride-one Haar/SWT: LL, LH, HL, HH
→ Low=LL, High=Concat(LH,HL,HH)
→ 네 CNN expert: LL–LL / LL–High / High–LL / High–High
→ 위치별 네 expert softmax 혼합
→ R_out=R+gamma_R*Delta_R, T_out=T+gamma_T*Delta_T
→ 기존 AIFI(P5)·FPN·PAN → scale별 RGB/T concat+CSP fusion → 공유 decoder
```

두 방향의 bank는 독립적인 파라미터를 갖고, 강화 전 원래 RGB/T 쌍을 각각 읽는다. 각 bank의 256→64 projection 뒤에 SWT를 수행한다. Expert는 주파수 pair를 concat한 뒤 `1×1 Conv → GELU → 3×3 depthwise Conv → GELU → 1×1 Conv`로 256채널의 보완량을 만든다. 내부 차원은 64다.

Router는 `1×1 Conv → GELU → 1×1 Conv`이며 이미지별 pooling을 사용하지 않는다. 가중치는 `[B,2,4,H,W]`이며 expert 축에서 FP32 softmax를 적용한다. 모든 expert를 계산하는 dense mixture다.

`gamma_R`, `gamma_T`는 독립적인 학습 가능한 scalar이며 **초기값은 0**이다. 고정 multiplier는 1.0이다. 초기 특징과 예측은 baseline과 동일하다. 첫 backward에서는 두 gamma에 탐지 gradient가 전달되고 나머지 모듈 parameter의 탐지 gradient는 0이다. Gamma가 갱신된 다음 step부터 CNN expert와 router에도 탐지 gradient가 전달된다. 별도 epoch 준비 단계나 추가 loss를 사용하지 않는다. Gamma는 부호와 크기를 제한하지 않는다.

## 학습 설정

주 설정: `configs/rgbtdroneperson_cnn_mofe_zero_seed0.yaml`.

A와 seed 0, batch 2, workers 4, FP32, 20 epoch / 49,000 updates, 공개 PResNet50-vd pretrained, AdamW LR 2.5e-4 / backbone LR 배율 .1 / weight decay 1e-4, 2,000-step warmup, gradient clip .1, EMA .9999 / warmups 2,000을 동일하게 유지한다. Train resize는 448×576 / 512×640 / 576×704, eval은 512×640이다. Thermal-reference person/rider/crowd 3개 class, train 4,900 / val 1,225장을 사용한다.

Detection loss는 VFL 1 + L1 5 + GIoU 2 및 기존 auxiliary/denoising loss다. 추가 mask/utility/evidence/teacher/distillation loss는 없다. 학습한 A/B checkpoint를 초기값으로 로드하지 않는다.

## 검증과 실행

```bash
cd /data/siwoo/DualRTDETR-CNN-MoFE-Zero
PYTHON_BIN=/home/viplab/anaconda3/envs/coxmamba/bin/python
OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 "$PYTHON_BIN" -m unittest tests.test_cnn_zero_mofe -v

CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1 "$PYTHON_BIN" -u tools/train.py \
  --config configs/rgbtdroneperson_cnn_mofe_zero_seed0.yaml --device cuda:0
```

`tools/cnn_mofe_zero_preflight.py`는 물리 GPU1의 실제 batch 2·세 해상도로 세 번의 검출 loss 갱신을 검증한다. GPU guard로 공유 lock과 매핑을 확인한 뒤 실행한다. 검증에서 사용한 가중치를 저장하거나 본학습에 재사용하지 않는다. 본학습은 위 설정의 공개 pretrained에서 새로 시작한다.

기존 CNN module/model/학습/평가 코드는 그대로 재사용하고 주 설정만 기존 `spatial_mofe`를 선택한다. 관계 기반 파일이 보존되어 있어도 현재 설정의 active model에 관계 expert가 등록되거나 실행되는 것은 아니다. S³AM에서 영감을 받은 detection 적용이며 원본 S³AM 전체 구현과 동일하다고 주장하지 않는다.

모듈의 구조와 gradient 검증은 AP 향상의 근거가 아니다. 20-epoch 본학습과 AP 검증은 아직 수행하지 않았다.
