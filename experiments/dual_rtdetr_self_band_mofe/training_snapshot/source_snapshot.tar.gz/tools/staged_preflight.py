"""Disposable GPU0 detection updates; production always reinitializes from seed0."""
import copy
import gc
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import torch
from dyfclt.model import DyFCLT
from dyfclt.losses import build_criterion
from dyfclt.training import build_optimizer, build_ema, set_learning_rate
from dyfclt.runtime import (load_config, seed_everything, make_dataset, make_loader,
                           move_targets, resize_training_batch, warmup_factor, apply_optimizer_step)
from dyfclt.frequency_training import sha256, source_manifest, gate_statistics
from tools.staged_queue import GpuLocks, probe_cuda_mapping
from tools.train import validate_detection_config

GPU0_UUID = 'GPU-13eb8897-9466-51a2-84eb-e2d28ce8deba'


def main():
    actual = subprocess.check_output(['nvidia-smi', '-i', '0', '--query-gpu=uuid', '--format=csv,noheader'], text=True).strip()
    if actual != GPU0_UUID:
        raise RuntimeError('Physical GPU0 UUID changed')
    locks = GpuLocks(sorted(Path('/tmp').glob('*_gpu0.lock')))
    if not locks.acquire():
        raise RuntimeError('GPU0 resource lock is held')
    try:
        jobs = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader'], text=True)
        if GPU0_UUID in jobs:
            raise RuntimeError('GPU0 is occupied; preserve existing processes')
        if os.environ.get('CUDA_VISIBLE_DEVICES') != '0' or os.environ.get('CUDA_DEVICE_ORDER') != 'PCI_BUS_ID':
            raise RuntimeError('Preflight must map physical GPU0 to cuda:0')
        mapping_probe = probe_cuda_mapping(os.environ, GPU0_UUID)
        torch.set_num_threads(4)
        device = torch.device('cuda:0')
        plan = json.loads((ROOT/'artifacts/experiment_plan.json').read_text())
        cfg1 = load_config(ROOT/plan['stages'][0]['config'])
        a_cfg = copy.deepcopy(cfg1)
        a_cfg['model'].pop('frequency_utility')
        seed_everything(0)
        a = DyFCLT(**a_cfg['model'])
        shared_initial = {name: value.clone() for name, value in a.state_dict().items()}
        a_rng = torch.get_rng_state().clone()
        del a;gc.collect()
        proof = dict(checked_at_utc=datetime.now(timezone.utc).isoformat(), physical_gpu=0,
                     gpu_uuid=GPU0_UUID, pid=os.getpid(), stages=[], shared_initial_tensors=len(shared_initial),
                     trained_checkpoint_loaded=False, updated_weights_saved=False,
                     source_sha256=source_manifest(ROOT), locks=[str(p) for p in locks.paths])
        proof['mapping_probe'] = mapping_probe
        for entry in plan['stages']:
            cfg = load_config(ROOT/entry['config']);validate_detection_config(cfg)
            seed_everything(0)
            model = DyFCLT(**cfg['model'])
            assert torch.equal(torch.get_rng_state(), a_rng), 'Module shifted shared CPU RNG'
            state = model.state_dict()
            assert all(torch.equal(state[name], value) for name, value in shared_initial.items()), 'Shared A initialization differs'
            del state
            model.to(device)
            jobs = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader'], text=True)
            mapping = [line.split(',')[1].strip() for line in jobs.splitlines() if int(line.split(',')[0]) == os.getpid()]
            assert mapping == [GPU0_UUID], mapping
            module = model.encoder.frequency_module
            parameters = sum(p.numel() for p in model.parameters())
            module_parameters = sum(p.numel() for p in module.parameters())
            criterion = build_criterion(cfg['model']['num_classes'], **cfg.get('loss', {})).to(device)
            settings = cfg['train']
            optimizer = build_optimizer(model, settings)
            ids = {id(p) for group in optimizer.param_groups for p in group['params']}
            assert all(id(p) in ids for p in module.parameters())
            ema = build_ema(model, settings)
            scaler = torch.cuda.amp.GradScaler(enabled=False)
            train = make_dataset(cfg, 'train', training=True);val = make_dataset(cfg, 'val')
            assert len(train) == 4900 and len(val) == 1225
            assert train.category_ids == val.category_ids == [0, 1, 2]
            batch = next(iter(make_loader(train, 2, 0, True)))
            rgb, thermal, targets = batch
            rgb, thermal = rgb.to(device), thermal.to(device)
            model.eval()
            with torch.no_grad():
                initial = model(rgb, thermal, return_frequency_aux=True)
                assert float(module.gamma_rgb) == float(module.gamma_thermal) == 0
                if entry['stage'] == 3:
                    assert torch.equal(initial['frequency_aux']['injection_strength'], torch.ones_like(initial['frequency_aux']['injection_strength']))
                model.encoder.frequency_module = None
                baseline = model(rgb, thermal)
                model.encoder.frequency_module = module
                for key in ('pred_logits', 'pred_boxes'):
                    assert torch.equal(initial[key], baseline[key]), 'Initial prediction not exactly baseline: ' + key
            del initial,baseline
            record = dict(stage=entry['stage'], config=entry['config'], parameters=parameters,
                          module_parameters=module_parameters, module_parameter_tensors=len(list(module.parameters())),
                          shared_A_initialization_exact=True, CPU_rng_equal=True, initial_prediction_equals_bypass=True,
                          optimizer_includes_all_module_parameters=True, updates=[], categories=train.category_ids,
                          train_images=len(train), val_images=len(val), actual_physical_mapping=mapping)
            gamma_initial = [module.gamma_rgb.detach().clone(), module.gamma_thermal.detach().clone()]
            module_initial = {name:parameter.detach().clone() for name,parameter in module.named_parameters()}
            observed_nonzero = set()
            model.train()
            for step in range(5):
                # Cover all production resolutions while keeping the paired batch fixed.
                image_size = settings['resize_sizes'][step % len(settings['resize_sizes'])]
                r,t,y = resize_training_batch(rgb,thermal,copy.deepcopy(targets),[image_size])
                y = move_targets(y,device)
                factor = warmup_factor(step, settings['warmup_steps'], settings['warmup_factor'])
                set_learning_rate(optimizer, settings['lr'], factor)
                optimizer.zero_grad(set_to_none=True)
                outputs = model(r,t,y,return_frequency_aux=True)
                losses = criterion(outputs,y);loss=sum(losses.values())
                assert bool(torch.isfinite(loss))
                scaler.scale(loss).backward()
                gradients = {}
                for name,parameter in module.named_parameters():
                    assert parameter.grad is not None and bool(torch.isfinite(parameter.grad).all()), name
                    gradients[name] = float(parameter.grad.abs().max())
                    if gradients[name] > 0:
                        observed_nonzero.add(name)
                if step == 0:
                    assert {name for name,value in gradients.items() if value > 0} == {'gamma_rgb','gamma_thermal'}
                norm,applied = apply_optimizer_step(model,optimizer,scaler,settings['clip_grad_norm'],ema=ema)
                assert applied and bool(torch.isfinite(norm))
                update = dict(step=step+1, loss=float(loss.detach()), grad_norm=float(norm), image_size=image_size,
                              nonzero_module_gradient_tensors=sum(value > 0 for value in gradients.values()),
                              gamma=[float(module.gamma_rgb),float(module.gamma_thermal)],
                              statistics=gate_statistics(outputs['frequency_aux']))
                record['updates'].append(update)
                print(json.dumps(dict(stage=entry['stage'],**update)),flush=True)
                del outputs,loss,losses
            assert observed_nonzero == {name for name,_ in module.named_parameters()}, sorted({name for name,_ in module.named_parameters()}-observed_nonzero)
            assert all(not torch.equal(before,after.detach()) for before,after in zip(gamma_initial,(module.gamma_rgb,module.gamma_thermal)))
            assert ema.updates == 5
            changed = [name for name,parameter in module.named_parameters()
                       if not torch.equal(module_initial[name],parameter.detach())]
            assert any('.experts.' in name for name in changed), 'No expert parameter changed'
            if entry['stage']==3:
                assert any(name.startswith('beta_rgb.2.') for name in changed)
                assert any(name.startswith('beta_thermal.2.') for name in changed)
            ema.module.eval()
            with torch.no_grad():
                first = ema.module(rgb,thermal);second = ema.module(rgb,thermal)
                assert all(torch.equal(first[k],second[k]) and bool(torch.isfinite(first[k]).all()) for k in ('pred_logits','pred_boxes'))
            record.update(all_module_gradients_finite_and_eventually_nonzero=True,gamma_parameters_updated=True,
                          ema_updates=ema.updates,EMA_eval_finite_repeatable=True,
                          parameter_tensors_updated=changed,
                          note='Very small warmup updates can round to zero for beta first-layer weights even with nonzero gradients.')
            proof['stages'].append(record)
            del first,second,model,module,optimizer,ema,criterion,scaler,train,val,batch,rgb,thermal,targets,module_initial
            gc.collect();torch.cuda.empty_cache()
        proof['input_sha256'] = {str((ROOT/cfg1['model']['pretrained']).resolve()): sha256(ROOT/cfg1['model']['pretrained'])}
        for split in ('train','val'):
            path=cfg1['data'][split]['ann_file'];proof['input_sha256'][path]=sha256(path)
        original = json.loads((ROOT/'artifacts/original_active_source_sha256.json').read_text())
        assert all(sha256(path)==digest for path,digest in original.items()), 'Original active code changed'
        proof.update(original_active_source_unchanged=True,ready=True)
        (ROOT/'artifacts/gpu_preflight.json').write_text(json.dumps(proof,indent=2)+'\n')
        print(json.dumps(dict(preflight_passed=True,proof='artifacts/gpu_preflight.json')),flush=True)
    finally:
        locks.release()


if __name__ == '__main__':
    main()
