import copy
import json
from pathlib import Path
import unittest

import torch

from dyfclt.spatial_mofe import SpatialResidualMoFE
from dyfclt.runtime import load_config

try:
    from dyfclt.staged_mofe import DonorConditionedExpert, DonorResidualMoFE, DonorStrengthResidualMoFE
except ImportError:
    DonorConditionedExpert = DonorResidualMoFE = DonorStrengthResidualMoFE = None


ROOT = Path(__file__).resolve().parents[1]


class StagedMoFETests(unittest.TestCase):
    def require_classes(self):
        self.assertIsNotNone(DonorConditionedExpert, 'receiver-conditioned donor expert is not implemented')
        self.assertIsNotNone(DonorResidualMoFE)
        self.assertIsNotNone(DonorStrengthResidualMoFE)

    def test_three_configs_change_only_the_authorized_variables(self):
        base = load_config(ROOT/'configs/rgbtdroneperson_cnn_mofe_zero_seed0.yaml')
        plan = json.loads((ROOT/'artifacts/experiment_plan.json').read_text())
        for entry in plan['stages']:
            current = load_config(ROOT/entry['config'])
            expected = copy.deepcopy(base)
            expected['model']['frequency_utility']['insertion_point'] = 'post_encoder'
            expected['model']['frequency_utility']['gate_mode'] = entry['mode']
            expected['train']['output_dir'] = entry['output_dir']
            self.assertEqual(current, expected)

    def test_zero_donor_cannot_generate_a_receiver_only_residual(self):
        self.require_classes()
        for receiver_channels in (4, 12):
            for donor_channels in (4, 12):
                expert = DonorConditionedExpert(receiver_channels, donor_channels, 5, 8)
                receiver = torch.randn(2, receiver_channels, 5, 7)
                zero = torch.zeros(2, donor_channels, 5, 7)
                self.assertTrue(torch.equal(expert(torch.cat((receiver, zero), 1)), torch.zeros(2, 8, 5, 7)))

    def test_receiver_controls_a_nonzero_donor_through_the_gate(self):
        self.require_classes()
        torch.manual_seed(17)
        expert = DonorConditionedExpert(4, 12, 5, 8)
        receiver = torch.randn(2, 4, 5, 7, requires_grad=True)
        donor = torch.randn(2, 12, 5, 7, requires_grad=True)
        output = expert(torch.cat((receiver, donor), 1))
        output.square().mean().backward()
        self.assertGreater(float(receiver.grad.abs().sum()), 0)
        self.assertGreater(float(donor.grad.abs().sum()), 0)

    def test_replacing_experts_preserves_existing_projection_router_initialization(self):
        self.require_classes()
        options = dict(channels=8, dim=4, expert_hidden=5, router_hidden=6, residual_scale=0., residual_multiplier=1.)
        torch.manual_seed(0); plain = SpatialResidualMoFE(**options); rng = torch.get_rng_state()
        torch.manual_seed(0); donor = DonorResidualMoFE(**options)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        for name, value in plain.state_dict().items():
            if '.experts.' not in name:
                self.assertTrue(torch.equal(value, donor.state_dict()[name]), name)

    def test_beta_one_preserves_stage_two_even_with_nonzero_gamma(self):
        self.require_classes()
        options = dict(channels=8, dim=4, expert_hidden=5, router_hidden=6, residual_scale=.23, residual_multiplier=1.)
        torch.manual_seed(0); base = DonorResidualMoFE(**options); rng = torch.get_rng_state()
        torch.manual_seed(0); strength = DonorStrengthResidualMoFE(**options)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        for name, value in base.state_dict().items():
            self.assertTrue(torch.equal(value, strength.state_dict()[name]), name)
        r, t = torch.randn(2, 8, 5, 7), torch.randn(2, 8, 5, 7)
        a = base(r, t); b = strength(r, t)
        self.assertTrue(torch.equal(a[0], b[0]) and torch.equal(a[1], b[1]))
        self.assertTrue(torch.equal(b[2]['injection_strength'], torch.ones(2, 2, 5, 7)))

    def test_two_directions_read_original_pair_and_beta_can_turn_down_a_region(self):
        self.require_classes()
        module = DonorStrengthResidualMoFE(channels=8, dim=4, expert_hidden=5, router_hidden=6,
                                          residual_scale=.2, residual_multiplier=1.)
        r, t = torch.zeros(2, 8, 5, 7), torch.randn(2, 8, 5, 7)
        ro, to, aux = module(r, t)
        self.assertTrue(torch.equal(to, t), 'Thermal may only receive the original zero RGB donor')
        self.assertGreater(float(ro.abs().sum()), 0)
        self.assertTrue(torch.allclose(aux['routing_weights'].sum(2), torch.ones(2, 2, 5, 7)))
        with torch.no_grad():
            module.beta_rgb[-1].bias.fill_(-20.)
        muted = module(r, t)
        self.assertLess(float((muted[0]-r).abs().sum()), float((ro-r).abs().sum())*1e-6)
        self.assertTrue(((muted[2]['injection_strength'] >= 0) & (muted[2]['injection_strength'] <= 2)).all())

    def test_gamma_zero_and_beta_gradients_follow_the_expected_initialization(self):
        self.require_classes()
        module = DonorStrengthResidualMoFE(channels=8, dim=4, expert_hidden=5, router_hidden=6,
                                          residual_scale=0., residual_multiplier=1.)
        optimizer = torch.optim.SGD(module.parameters(), lr=.2)
        r, t = torch.randn(2, 8, 5, 7), torch.randn(2, 8, 5, 7)
        target = torch.randn_like(r)
        for step in range(4):
            optimizer.zero_grad(); ro, to, aux = module(r, t)
            ((ro-target).square().mean() + (to-target).square().mean()).backward()
            if step == 0:
                self.assertTrue(torch.equal(ro, r) and torch.equal(to, t))
                for name, parameter in module.named_parameters():
                    self.assertIsNotNone(parameter.grad)
                    self.assertEqual(float(parameter.grad.abs().sum()) > 0, name in ('gamma_rgb', 'gamma_thermal'), name)
            optimizer.step()
        self.assertGreater(float(module.beta_rgb[0].weight.grad.abs().sum()), 0)
        self.assertGreater(float(module.rgb_from_thermal.experts[0].value[0].weight.grad.abs().sum()), 0)


if __name__ == '__main__':
    unittest.main()
