# 위치별 양방향 MoFE 실험

기존 B-pre/E-pre와 실험 A는 별도 경로에 그대로 보존한다. 이 실험은 B-pre의 네 주파수 expert를 유지하고, 이미지별 router의 전역 평균 pooling만 제거해 P3 위치마다 네 expert를 softmax로 혼합한다. 추가 고정 multiplier는 0.5다.

```text
RGB/T 독립 backbone → 각 HybridEncoder의 공통 채널 projection
→ P3의 양방향 spatial MoFE → 기존 AIFI(P5)·FPN·PAN
→ 각 scale의 RGB/T concat+CSP fusion → 공유 RT-DETR decoder
```

SWT는 stride 1 Haar 분석이며 H=Concat(LH,HL,HH)이다. 네 expert 입력은 LL–LL, LL–H, H–LL, H–H의 concat이다. Expert는 기존 1×1 Conv → GELU → 3×3 DWConv → GELU → 1×1 Conv를 유지한다. 이 세부 expert 연산과 차원은 우리 적용 선택이며 S³AM 저자 구현과 동일하다고 주장하지 않는다. QKV attention을 추가하지 않는다. 강화가 끝난 RGB/T를 연결하는 것은 이후 기존 detector fusion이다.

각 방향은 원래 RGB/T를 입력으로 계산하며, routing weight shape은 `[B,2,4,H,W]`이다. Expert 축에서만 softmax를 적용하며 모든 후보를 계산하는 dense mixture다.

`R'=R+0.5*gamma_R*sum_i(w_R_i*Delta_R_i)`

`T'=T+0.5*gamma_T*sum_i(w_T_i*Delta_T_i)`

Gamma는 기존과 같이 학습 가능한 scalar이며 0.1로 초기화한다. 초기 유효 계수는 0.05이고, 고정 multiplier가 최종 residual RMS까지 제한하지는 않는다. Gamma와 expert 크기가 증가할 수 있어 `relative_update`, `effective_residual_scale`, 후보 RMS를 기록한다. 평균 가중치, 이미지 내부 공간 표준편차와 entropy도 기록한다.

학습은 A와 같은 seed 0, batch 2, workers 4, FP32, 20 epoch, AdamW, EMA, 검출 loss+기존 auxiliary/denoising loss다. 공개 backbone pretrained만 로드하며 학습된 A/B/E checkpoint와 preflight에서 갱신한 가중치는 사용하지 않는다. 데이터는 train 4,900장, val 1,225장, person/rider/crowd 3개 class다.

GPU1 실행: `bash tools/train_spatial_mofe_gpu1.sh`. 공유 GPU lock, 물리 GPU mapping, 실제 batch 2의 세 해상도 검증과 source/config hash 검사를 먼저 수행한다. 별도 출력은 `outputs/rgbtdroneperson_spatial_mofe_seed0`, 로그는 `artifacts/training_launch_spatial_mofe_seed0_gpu1/train.log`에 저장한다.

이 실험은 B-pre와 비교할 때 router와 residual multiplier 두 항목이 바뀐다. 개별 원인을 분리하려면 같은 multiplier를 적용한 전역 router 대조가 추가로 필요하다. 기존 frozen B-pre의 0.5 validation 진단 결과는 이 새 모델의 학습 성능으로 간주하지 않는다.

참고: [S³AM](https://arxiv.org/html/2608.17475v1), [RSFNet](https://arxiv.org/html/2306.10364).
